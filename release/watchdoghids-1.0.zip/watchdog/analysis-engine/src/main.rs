//! Main module for the analysis engine
//!
//! This module provides the main entry point for the analysis engine.
//! It initializes the environment, sets up logging, and starts the analysis engine.
//!
//! # Dependencies
//!
//! - `dotenv` for loading environment variables.
//! - `tokio` for async runtime.
//! - `analysis_engine` for the analysis engine implementation.

pub mod db;
mod models;
pub mod webhook;

use analysis_engine::run_analysis_engine;
use dotenv::dotenv;

/// Main function
///
/// # Returns
///
/// A `Result` indicating success or an error
#[tokio::main]
async fn main() {
    dotenv().ok();

    run_analysis_engine().await;
}
