//! API Module
//!
//! This module provides functionality to interact with various APIs.
//! It allows checking if an IP address is malicious and retrieving threat information.
//!
//! # Features
//!
//! - Check if an IP address is malicious
//! - Retrieve threat information for an IP address
//! - Convert category codes to human-readable names
//!
//! # Dependencies
//!
//! - `reqwest` for HTTP requests.
//! - `serde` for JSON parsing.
//! - `std::net::IpAddr` for IP address handling.
//! - `crate::models` for data models.

pub mod abuseipdb;
pub mod virustotal;

use crate::cache::IpCache;
use crate::models::IpThreatInfo;
use std::net::IpAddr;

/// Represents the type of API to use
///
/// # Variants
///
/// * `AbuseIpDb(abuseipdb::AbuseIpDbApi)` - The AbuseIPDB API.
/// * `VirusTotal(virustotal::VirusTotalApi)` - The VirusTotal API.
#[derive(Debug)]
pub enum ApiType {
    AbuseIpDb(abuseipdb::AbuseIpDbApi),
    VirusTotal(virustotal::VirusTotalApi),
}

/// Clones the API type
///
/// # Returns
///
/// A new `ApiType` with the same API type.
impl Clone for ApiType {
    fn clone(&self) -> Self {
        match self {
            Self::AbuseIpDb(a) => Self::AbuseIpDb(a.clone()),
            Self::VirusTotal(a) => Self::VirusTotal(a.clone()),
        }
    }
}

/// Checks an IP address against the configured API
///
/// # Arguments
///
/// * `ip` - The IP address to check.
///
///  # Returns
///
/// A `Result` containing the `IpThreatInfo` record if the IP address is found in the API, otherwise an `ApiError`.
impl ApiType {
    pub async fn check_ip(&self, ip: IpAddr) -> Result<IpThreatInfo, ApiError> {
        match self {
            Self::AbuseIpDb(api) => api.check_ip(ip).await,
            Self::VirusTotal(api) => api.check_ip(ip).await,
        }
    }

    pub async fn init_with_cache(
        api_type: &str,
        api_key: &str,
        cache_dir: &str,
    ) -> Result<Self, ApiError> {
        match api_type {
            "abuseipdb" => {
                let cache = IpCache::new(cache_dir, "abuseipdb")
                    .await
                    .map_err(|e| ApiError::CacheError(e.to_string()))?;
                Ok(Self::AbuseIpDb(abuseipdb::AbuseIpDbApi::new_with_cache(
                    api_key, cache,
                )?))
            }
            "virustotal" => {
                let cache = IpCache::new(cache_dir, "virustotal")
                    .await
                    .map_err(|e| ApiError::CacheError(e.to_string()))?;
                Ok(Self::VirusTotal(virustotal::VirusTotalApi::new_with_cache(
                    api_key, cache,
                )?))
            }
            _ => Err(ApiError::InvalidApiType),
        }
    }
}

/// Represents errors that may occur when interacting with an API
///
/// # Variants
///
/// * `RequestFailed(String)` - Indicates that the API request failed due to a network error or invalid request.
/// * `AuthenticationError(String)` - Indicates that the API request failed due to an authentication error.
/// * `RateLimitExceeded` - Indicates that the API request failed due to a rate limit being exceeded.
/// * `NetworkError(String)` - Indicates that the API request failed due to a network error.
/// * `InvalidResponse(String)` - Indicates that the API request failed due to an invalid response.
/// * `CacheError(String)` - Indicates that there was an error initializing the cache.
/// * `InvalidApiType` - Indicates that the provided API type is invalid.
#[derive(Debug)]
pub enum ApiError {
    RequestFailed(String),
    AuthenticationError(String),
    RateLimitExceeded,
    NetworkError(String),
    InvalidResponse(String),
    CacheError(String),
    InvalidApiType,
}
