//! VirusTotal API Module
//!
//! This module provides functionality to interact with the VirusTotal API.
//! It allows checking if an IP address is malicious and retrieving threat information.
//!
//! # Features
//!
//! - Check if an IP address is malicious
//! - Retrieve threat information for an IP address
//! - Support for batch IP checking
//!
//! # Dependencies
//!
//! - `reqwest` for HTTP requests
//! - `serde` for JSON parsing
//! - `std::net::IpAddr` for IP address handling

use super::ApiError;
use crate::cache::IpCache;
use crate::models::{IpThreatInfo, VirusTotalResponse};
use reqwest::Client;
use std::env;
use std::net::IpAddr;
use std::time::Duration;

#[derive(Clone, Debug)]
pub struct VirusTotalApi {
    client: Client,
    api_key: String,
    cache: IpCache,
}

impl VirusTotalApi {
    /// Creates a new instance of the VirusTotalApi.
    ///
    /// # Returns   
    ///
    /// * `Ok(VirusTotalApi)` - If the API key is valid and the client is built successfully.
    /// * `Err(ApiError)` - If there is an error during the API call or cache access.
    pub async fn new() -> Result<Self, ApiError> {
        let api_key = env::var("VIRUSTOTAL_API_KEY")
            .map_err(|_| ApiError::AuthenticationError("VIRUSTOTAL_API_KEY not set".to_string()))?;

        let client = Client::builder()
            .timeout(Duration::from_secs(10))
            .build()
            .map_err(|e| ApiError::NetworkError(e.to_string()))?;

        let cache_dir =
            env::var("CACHE_DIR").unwrap_or_else(|_| "/var/cache/threat_intel".to_string());
        let cache = IpCache::new(&cache_dir, "virustotal")
            .await
            .map_err(|e| ApiError::CacheError(e.to_string()))?;

        Ok(Self {
            client,
            api_key,
            cache,
        })
    }

    /// Creates a new instance of the VirusTotalApi with a custom cache.
    ///
    /// # Arguments
    ///
    /// * `api_key` - The API key for VirusTotal.
    /// * `cache` - The cache to use for storing IP threat information.
    ///
    /// # Returns
    ///
    /// * `Ok(VirusTotalApi)` - If the API key is valid and the client is built successfully.
    /// * `Err(ApiError)` - If there is an error during the API call or cache access.
    pub fn new_with_cache(api_key: &str, cache: IpCache) -> Result<Self, ApiError> {
        let client = Client::builder()
            .timeout(Duration::from_secs(10))
            .build()
            .map_err(|e| ApiError::NetworkError(e.to_string()))?;

        Ok(Self {
            client,
            api_key: api_key.to_string(),
            cache,
        })
    }

    /// Checks if an IP address is malicious using the VirusTotal API.
    ///
    ///  # Arguments
    ///
    /// * `ip` - The IP address to check.
    ///
    /// # Returns
    ///
    /// * `Ok(IpThreatInfo)` - If the IP address is found in the cache or API response.
    ///
    /// * `Err(ApiError)` - If there is an error during the API call or cache access.
    pub async fn check_ip(&self, ip: IpAddr) -> Result<IpThreatInfo, ApiError> {
        // Check cache first
        if let Some(cached_info) = self.cache.get(&ip).await {
            return Ok(cached_info);
        }

        // If not in cache, call API
        let threat_info = self.call_api(ip).await?;

        // Store in cache
        self.cache
            .set(threat_info.clone())
            .await
            .map_err(|e| ApiError::CacheError(e.to_string()))?;

        Ok(threat_info)
    }

    /// Calls the VirusTotal API to check if an IP address is malicious.
    ///
    /// # Arguments
    ///
    /// * `ip` - The IP address to check.
    ///
    /// # Returns
    ///
    /// * `Ok(IpThreatInfo)` - If the API call is successful.
    /// * `Err(ApiError)` - If there is an error during the API call.
    async fn call_api(&self, ip: IpAddr) -> Result<IpThreatInfo, ApiError> {
        let url = format!("https://www.virustotal.com/api/v3/ip_addresses/{}", ip);

        let response = self
            .client
            .get(&url)
            .header("x-apikey", &self.api_key)
            .send()
            .await
            .map_err(|e| ApiError::NetworkError(e.to_string()))?;

        if !response.status().is_success() {
            let status = response.status();
            let text = response.text().await.unwrap_or_default();
            return match status.as_u16() {
                429 => Err(ApiError::RateLimitExceeded),
                401 => Err(ApiError::AuthenticationError("Invalid API key".to_string())),
                _ => Err(ApiError::RequestFailed(format!(
                    "HTTP {}: {}",
                    status, text
                ))),
            };
        }

        let vt_response = response
            .json::<VirusTotalResponse>()
            .await
            .map_err(|e| ApiError::InvalidResponse(e.to_string()))?;

        let stats = &vt_response.data.attributes.last_analysis_stats;
        let total_detections = stats.malicious + stats.suspicious;
        let total_engines = total_detections + stats.harmless;

        let confidence_score = if total_engines >= 3 { 100 } else { 0 };

        // Collect categories from analysis results
        let categories: Vec<String> = vt_response
            .data
            .attributes
            .last_analysis_results
            .iter()
            .filter(|(_, result)| result.category == "malicious" || result.category == "suspicious")
            .map(|(engine, result)| format!("{}: {}", engine, result.result))
            .collect();

        Ok(IpThreatInfo {
            ip,
            is_malicious: confidence_score >= 80,
            confidence_score,
            categories,
            total_reports: total_detections,
            country_code: Some(vt_response.data.attributes.country.clone()),
            country_name: None,
            isp: None,
            domain: None,
            usage_type: None,
            last_reported_at: Some(
                vt_response
                    .data
                    .attributes
                    .last_modification_date
                    .to_string(),
            ),
            source: "VirusTotal".to_string(),
        })
    }
}
