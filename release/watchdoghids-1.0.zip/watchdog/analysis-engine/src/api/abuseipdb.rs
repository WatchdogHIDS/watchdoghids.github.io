//! AbuseIPDB API Module
//!
//! This module provides functionality to interact with the AbuseIPDB API.
//! It allows checking if an IP address is malicious and retrieving threat information.
//!
//! # Features
//!
//! - Check if an IP address is malicious
//! - Retrieve threat information for an IP address
//! - Convert category codes to human-readable names
//!
//! # Dependencies
//!
//! - `reqwest` for HTTP requests.
//! - `serde` for JSON parsing.
//! - `std::net::IpAddr` for IP address handling.

use crate::cache::IpCache;
use crate::models::{AbuseIpDbResponse, IpThreatInfo};

use super::ApiError;
use reqwest::Client;
use serde_json;
use std::env;
use std::net::IpAddr;
use std::time::Duration;

#[derive(Clone, Debug)]
pub struct AbuseIpDbApi {
    client: Client,
    api_key: String,
    cache: IpCache,
}

/// Implementation of the AbuseIPDB API
///
/// This implementation uses the AbuseIPDB API to check if an IP address is malicious.
/// It requires an API key to be set in the environment variable
/// `ABUSEIPDB_API_KEY`.
impl AbuseIpDbApi {
    /// Creates a new instance of the AbuseIpDbApi.
    ///
    /// # Returns
    ///
    /// A new instance of AbuseIpDbApi, or an error if the API key is not set or the client fails to build.
    pub async fn new() -> Result<Self, ApiError> {
        let api_key = env::var("ABUSEIPDB_API_KEY")
            .map_err(|_| ApiError::AuthenticationError("ABUSEIPDB_API_KEY not set".to_string()))?;

        let client = Client::builder()
            .timeout(Duration::from_secs(10))
            .build()
            .map_err(|e| ApiError::NetworkError(e.to_string()))?;

        let cache_dir =
            env::var("CACHE_DIR").unwrap_or_else(|_| "/var/cache/threat_intel".to_string());
        let cache = IpCache::new(&cache_dir, "abuseipdb")
            .await
            .map_err(|e| ApiError::CacheError(e.to_string()))?;

        Ok(Self {
            client,
            api_key,
            cache,
        })
    }

    pub fn new_with_cache(api_key: &str, cache: IpCache) -> Result<Self, ApiError> {
        let client = Client::builder()
            .timeout(Duration::from_secs(10))
            .build()
            .map_err(|e| ApiError::NetworkError(e.to_string()))?;

        Ok(Self {
            client,
            api_key: api_key.to_string(),
            cache,
        })
    }

    /// Checks if an IP address is malicious using the AbuseIPDB API.
    ///
    /// # Arguments
    ///
    /// * `ip` - The IP address to check
    ///
    /// # Returns
    ///
    /// A Result containing the threat information for the IP address, or an error if the request fails.
    pub async fn check_ip(&self, ip: IpAddr) -> Result<IpThreatInfo, ApiError> {
        // Check cache first
        if let Some(cached_info) = self.cache.get(&ip).await {
            return Ok(cached_info);
        }

        // If not in cache, call API
        let threat_info = self.call_api(ip).await?;

        // Store in cache
        self.cache
            .set(threat_info.clone())
            .await
            .map_err(|e| ApiError::CacheError(e.to_string()))?;

        Ok(threat_info)
    }

    async fn call_api(&self, ip: IpAddr) -> Result<IpThreatInfo, ApiError> {
        let url = "https://api.abuseipdb.com/api/v2/check";

        let response = self
            .client
            .get(url)
            .query(&[
                ("ipAddress", ip.to_string()),
                ("maxAgeInDays", "90".to_string()),
                ("verbose", "".to_string()),
            ])
            .header("Key", &self.api_key)
            .header("Accept", "application/json")
            .send()
            .await
            .map_err(|e| ApiError::NetworkError(e.to_string()))?;

        let status = response.status();
        if !status.is_success() {
            let text = response.text().await.unwrap_or_default();
            return match status.as_u16() {
                429 => Err(ApiError::RateLimitExceeded),
                401 => Err(ApiError::AuthenticationError("Invalid API key".to_string())),
                _ => Err(ApiError::RequestFailed(format!(
                    "HTTP {}: {}",
                    status, text
                ))),
            };
        }

        let response_text = response
            .text()
            .await
            .map_err(|e| ApiError::InvalidResponse(e.to_string()))?;

        // Parse the JSON response
        let api_response = serde_json::from_str::<AbuseIpDbResponse>(&response_text)
            .map_err(|e| ApiError::InvalidResponse(e.to_string()))?;

        let categories: Vec<String> = if api_response.data.categories.is_empty() {
            Vec::new()
        } else {
            api_response
                .data
                .categories
                .iter()
                .map(|&cat| self.category_code_to_name(cat))
                .collect()
        };

        let is_malicious = api_response.data.abuse_confidence_score >= 80;

        let threat_info = IpThreatInfo {
            ip,
            is_malicious,
            confidence_score: api_response.data.abuse_confidence_score,
            categories,
            total_reports: api_response.data.total_reports,
            country_code: api_response.data.country_code.clone(),
            country_name: api_response.data.country_name.clone(),
            isp: api_response.data.isp.clone(),
            domain: api_response.data.domain.clone(),
            usage_type: api_response.data.usage_type.clone(),
            last_reported_at: api_response.data.last_reported_at.clone(),
            source: "AbuseIPDB".to_string(),
        };

        Ok(threat_info)
    }

    /// Converts an AbuseIPDB category code to a human-readable name.
    ///
    /// # Arguments
    ///
    /// * `code` - The category code to convert
    ///
    /// # Returns
    ///
    /// A human-readable name for the category
    fn category_code_to_name(&self, code: u32) -> String {
        match code {
            3 => "Fraud Orders".to_string(),
            4 => "DDoS Attack".to_string(),
            9 => "Open Proxy".to_string(),
            10 => "Web Spam".to_string(),
            11 => "Email Spam".to_string(),
            14 => "Port Scan".to_string(),
            18 => "Brute-Force".to_string(),
            19 => "Bad Web Bot".to_string(),
            20 => "Exploited Host".to_string(),
            21 => "Web App Attack".to_string(),
            22 => "SSH".to_string(),
            23 => "IoT Targeted".to_string(),
            _ => format!("Category {}", code),
        }
    }
}
