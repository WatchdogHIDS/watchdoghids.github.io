//! Cache Module
//!
//! Provides functionality for caching IP threat information to avoid
//! unnecessary API calls. Uses file-based storage for persistence
//! across program restarts.

use std::collections::HashMap;
use std::fs::{self, File};
use std::io::{self, BufReader, BufWriter};
use std::net::IpAddr;
use std::path::PathBuf;
use std::sync::Arc;
use time::{Duration, OffsetDateTime};
use tokio::sync::RwLock;

use crate::models::{CacheEntry, CacheFile, IpThreatInfo};

const CACHE_VERSION: u8 = 1;
const CACHE_EXPIRY_HOURS: i64 = 24;

#[derive(Clone)]
pub struct IpCache {
    cache: Arc<RwLock<HashMap<IpAddr, CacheEntry>>>,
    cache_file: PathBuf,
}
impl std::fmt::Debug for IpCache {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("IpCache")
            .field("cache_file", &self.cache_file)
            .finish()
    }
}

impl IpCache {
    /// Creates a new IP cache instance
    ///
    /// # Arguments
    ///
    /// * `cache_dir` - Directory where the cache file will be stored
    /// * `source` - Source of the cache (e.g., "virustotal" or "abuseipdb")
    pub async fn new(cache_dir: &str, source: &str) -> io::Result<Self> {
        let cache_file = PathBuf::from(cache_dir).join(format!("{}_cache.json", source));
        let cache = Arc::new(RwLock::new(HashMap::new()));

        let instance = Self { cache, cache_file };

        instance.load_cache().await?;
        Ok(instance)
    }

    /// Gets threat info for an IP from cache if available and not expired
    pub async fn get(&self, ip: &IpAddr) -> Option<IpThreatInfo> {
        let cache = self.cache.read().await;

        if let Some(entry) = cache.get(ip) {
            let now = OffsetDateTime::now_utc().unix_timestamp();
            let age = now - entry.cached_at;

            if age < Duration::hours(CACHE_EXPIRY_HOURS).whole_seconds() {
                return Some(entry.threat_info.clone());
            }
        }
        None
    }

    /// Stores threat info in the cache and persists to disk
    pub async fn set(&self, threat_info: IpThreatInfo) -> io::Result<()> {
        let entry = CacheEntry {
            threat_info: threat_info.clone(),
            cached_at: OffsetDateTime::now_utc().unix_timestamp(),
        };

        let mut cache = self.cache.write().await;
        cache.insert(threat_info.ip, entry);

        self.save_cache().await
    }

    /// Loads the cache from disk
    async fn load_cache(&self) -> io::Result<()> {
        if !self.cache_file.exists() {
            return Ok(());
        }

        match File::open(&self.cache_file) {
            Ok(file) => {
                let reader = BufReader::new(file);

                match serde_json::from_reader::<_, CacheFile>(reader) {
                    Ok(cache_file) => {
                        if cache_file.version != CACHE_VERSION {
                            return Ok(());
                        }

                        let mut cache = self.cache.write().await;

                        for (ip_str, entry) in cache_file.entries {
                            if let Ok(ip) = ip_str.parse::<IpAddr>() {
                                cache.insert(ip, entry);
                            }
                        }

                        Ok(())
                    }
                    Err(_) => Ok(()),
                }
            }
            Err(_) => Ok(()),
        }
    }

    /// Saves the cache to disk
    async fn save_cache(&self) -> io::Result<()> {
        // Create directory if it doesn't exist
        if let Some(dir) = self.cache_file.parent() {
            fs::create_dir_all(dir)?;
        }

        // Spawn a task to save the cache asynchronously to avoid blocking the main thread
        let cache_file_path = self.cache_file.clone();
        let cache_clone = self.cache.clone();

        // Spawn a task to save the cache in the background
        tokio::spawn(async move {
            let cache = cache_clone.read().await;

            let cache_file = CacheFile {
                version: CACHE_VERSION,
                entries: cache
                    .iter()
                    .map(|(ip, entry)| (ip.to_string(), entry.clone()))
                    .collect(),
            };

            if let Ok(file) = File::create(&cache_file_path) {
                let writer = BufWriter::new(file);
                let _ = serde_json::to_writer_pretty(writer, &cache_file);
            }
        });
        Ok(())
    }
}
