//! Network Traffic Analysis Engine
//!
//! Provides a framework for analyzing network traffic patterns and detecting anomalies.
//! The engine runs periodic analyses using configurable analyzers and stores results
//! in a MySQL database.
//!
//! # Architecture
//!
//! - Database connection management (`db` module)
//! - Pluggable analyzer system (`analyzers` module)
//! - Data models for traffic and events (`models` module)
//! - API integration (`api` module)
//! - Webhook server (`webhook` module)
//!
//! # Dependencies
//!
//! - `sqlx` for database interactions.
//! - `dashmap` for shared cache management.
//! - `tokio` for async runtime.
//! - `futures` for future operations.
//! - `dotenv` for loading environment variables.
//!
//! # Example
//!
//! ```no_run
//! use analysis_engine::run_analysis_engine;
//!
//! #[tokio::main]
//! async fn main() {
//!     run_analysis_engine().await;
//! }
//! ```

pub mod analyzers;
pub mod api;
pub mod cache;
pub mod crypto;
pub mod db;
pub mod models;
pub mod webhook;

use crate::db::connect_to_db_with_retry;
use crate::models::UserAnomalyConfig;
use crate::webhook::ApiKeyNotification;
use dashmap::DashMap;
use sqlx::MySqlPool;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::broadcast;
use tokio::time::interval;

// Apis
use crate::api::ApiType;

//use crate::analyzers::Analyzer;
use crate::analyzers::bandwidth::BandwidthAnalyzer;
use crate::analyzers::file_integrity::FileIntegrityAnalyzer;
use crate::analyzers::procinfo::ProcinfoAnalyzer;
use crate::analyzers::protocol::ProtocolAnalyzer;
use crate::analyzers::resource::ResourceAnalyzer;
use crate::analyzers::suspicious_ip::SuspiciousIpAnalyzer;
use crate::analyzers::traffic::TrafficAnalyzer;
use crate::analyzers::user_login::UserLoginAnalyzer;
use crate::analyzers::AnalyzerType;

// interval duration in seconds
const ANALYSIS_INTERVAL_SECS: u64 = 30;

/// Runs the main analysis engine loop.
///
/// # Operation
///
/// 1. Establishes database connection with retry mechanism
/// 2. Initializes configured analyzers
/// 3. Runs analysis every 30 seconds
/// 4. Handles and logs any errors during analysis
///
/// # Error Handling
///
/// - Database connection failures are logged and cause early return
/// - Individual analyzer failures are logged but don't stop the engine
///
/// # Examples
///
/// ```no_run
/// use analysis_engine::run_analysis_engine;
///
/// #[tokio::main]
/// async fn main() {
///     run_analysis_engine().await;
/// }
/// ```
pub async fn run_analysis_engine() {
    println!("Analysis engine is running...");
    let mut tick_interval = interval(Duration::from_secs(ANALYSIS_INTERVAL_SECS));

    // Connect to the database
    let pool = match connect_to_db_with_retry().await {
        Ok(pool) => pool,
        Err(e) => {
            eprintln!("Failed to connect to database: {:?}", e);
            return;
        }
    };

    // Initialize the config cache
    let config_cache = Arc::new(DashMap::new());
    initialize_config_cache(&pool, config_cache.clone()).await;

    // Create a broadcast channel for API key updates
    let (api_key_tx, api_key_rx) = broadcast::channel::<ApiKeyNotification>(16);

    // Initialize cache for APIs
    println!("Setting cache directory to /var/cache/threat_intel");
    let cache_dir =
        std::env::var("CACHE_DIR").unwrap_or_else(|_| "/var/cache/threat_intel".to_string());

    // Get the AGE identity key for decryption
    let age_identity = std::env::var("AGE_IDENTITY").unwrap_or_else(|_| {
        println!("AGE_IDENTITY not set in environment variables");
        return "".to_string();
    });

    // Get encrypted API keys from database
    let mut api_keys = std::collections::HashMap::new();
    match db::get_external_keys(&pool, None).await {
        Ok(keys) => {
            for key in keys {
                if !key.status {
                    continue;
                }

                match crypto::decrypt_age_data(&key.enc_key, &age_identity) {
                    Ok(decrypted_key) => {
                        println!("Successfully decrypted key for: {}", key.description);
                        api_keys.insert(key.description.to_lowercase(), decrypted_key);
                    }
                    Err(e) => {
                        eprintln!("Failed to decrypt key {}: {:?}", key.description, e);
                    }
                }
            }
        }
        Err(e) => {
            eprintln!("Failed to retrieve API keys from database: {:?}", e);
        }
    }

    // Initialize APIs with decrypted keys
    let mut api_instances = Vec::new();

    // Add AbuseIPDB API if key is available
    if let Some(abuseipdb_key) = api_keys.get("abuseipdb") {
        match ApiType::init_with_cache("abuseipdb", abuseipdb_key, &cache_dir).await {
            Ok(api) => {
                println!("Successfully initialized AbuseIPDB API");
                api_instances.push(api);
            }
            Err(e) => {
                eprintln!("Failed to initialize AbuseIPDB API: {:?}", e);
            }
        }
    } else {
        println!("No AbuseIPDB API key found in database");
    }

    // Add VirusTotal API if key is available
    if let Some(virustotal_key) = api_keys.get("virustotal") {
        match ApiType::init_with_cache("virustotal", virustotal_key, &cache_dir).await {
            Ok(api) => {
                println!("Successfully initialized VirusTotal API");
                api_instances.push(api);
            }
            Err(e) => {
                eprintln!("Failed to initialize VirusTotal API: {:?}", e);
            }
        }
    } else {
        println!("No VirusTotal API key found in database");
    }

    // Check if we have any API instances
    let have_apis = !api_instances.is_empty();
    let api_count = api_instances.len();

    // Create a thread safe container for APIs that can be updated
    let apis_container = Arc::new(DashMap::new());
    apis_container.insert("current".to_string(), Arc::new(api_instances));

    // shared analyzers vector
    let analyzers = Arc::new(DashMap::new());
    let mut initial_analyzers = vec![
        AnalyzerType::Traffic(TrafficAnalyzer::new(config_cache.clone())),
        AnalyzerType::Protocol(ProtocolAnalyzer::new(config_cache.clone())),
        AnalyzerType::Bandwidth(BandwidthAnalyzer::new(config_cache.clone())),
        AnalyzerType::Procinfo(ProcinfoAnalyzer::new(config_cache.clone())),
        AnalyzerType::Resource(ResourceAnalyzer::new(config_cache.clone())),
        AnalyzerType::UserLogin(UserLoginAnalyzer::new(config_cache.clone())),
        AnalyzerType::FileIntegrity(FileIntegrityAnalyzer::new(config_cache.clone())),
    ];

    // Add SuspiciousIpAnalyzer if APIs are available at the start
    if have_apis {
        println!("Adding SuspiciousIpAnalyzer with {} API(s)", api_count);
        let current_apis = apis_container.get("current").unwrap().clone();
        let analyzer = Arc::new(SuspiciousIpAnalyzer::new(current_apis, 80));
        initial_analyzers.push(AnalyzerType::SuspiciousIp((*analyzer).clone()));
    }

    analyzers.insert("current".to_string(), initial_analyzers);

    let analyzers_for_updates = analyzers.clone();

    // Clone values for the webhook server
    let webhook_config_cache = config_cache.clone();
    let webhook_pool = pool.clone();
    let webhook_tx = api_key_tx.clone();

    // Start the webhook server
    tokio::spawn(async move {
        webhook::start_webhook_server(webhook_config_cache, webhook_pool, webhook_tx).await;
    });

    // Spawn a task to handle API key updates
    let api_key_pool = pool.clone();
    let api_key_identity = std::env::var("AGE_IDENTITY").unwrap_or_else(|_| {
        println!("AGE_IDENTITY not set in environment variables");
        "".to_string()
    });
    let api_key_cache_dir =
        std::env::var("CACHE_DIR").unwrap_or_else(|_| "/var/cache/threat_intel".to_string());
    let apis_for_updates = apis_container.clone();
    let mut api_key_rx = api_key_rx;

    tokio::spawn(async move {
        println!("API key update listener started");
        while let Ok(notification) = api_key_rx.recv().await {
            println!("Received API key update notification: {:?}", notification);

            // Get the key ID from the notification
            let key_id = match notification {
                ApiKeyNotification::UpdateKey(id) => {
                    println!("Processing update for key ID: {}", id);
                    Some(id)
                }
            };

            match db::get_external_keys(&api_key_pool, key_id).await {
                Ok(keys) => {
                    if keys.is_empty() {
                        println!("No API keys found to update");
                        continue;
                    }

                    println!("Found {} API key(s) to update", keys.len());

                    // Collect decrypted keys
                    let mut decrypted_keys = std::collections::HashMap::new();

                    // Process each key
                    println!("Decrypting API keys...");
                    for key in keys {
                        if !key.status {
                            println!("Skipping inactive key ID {} ({})", key.id, key.description);
                            continue;
                        }

                        println!("Processing key ID {} ({})", key.id, key.description);
                        match crypto::decrypt_age_data(&key.enc_key, &api_key_identity) {
                            Ok(decrypted_key) => {
                                println!("Successfully decrypted key for: {}", key.description);
                                decrypted_keys
                                    .insert(key.description.to_lowercase(), decrypted_key);
                            }
                            Err(e) => {
                                eprintln!("Failed to decrypt key {}: {:?}", key.description, e);
                            }
                        }
                    }

                    if decrypted_keys.is_empty() {
                        println!("No keys were successfully decrypted");
                        continue;
                    }

                    println!("Successfully decrypted {} API key(s)", decrypted_keys.len());

                    // Initialize new API instances
                    let mut new_api_instances = Vec::new();
                    println!("Initializing API instances with updated keys...");

                    // Add AbuseIPDB API if key is available
                    if let Some(abuseipdb_key) = decrypted_keys.get("abuseipdb") {
                        println!("Initializing AbuseIPDB API...");
                        match ApiType::init_with_cache(
                            "abuseipdb",
                            abuseipdb_key,
                            &api_key_cache_dir,
                        )
                        .await
                        {
                            Ok(api) => {
                                println!("Successfully initialized AbuseIPDB API");
                                new_api_instances.push(api);
                            }
                            Err(e) => {
                                eprintln!("Failed to initialize AbuseIPDB API: {:?}", e);
                            }
                        }
                    } else {
                        println!("No AbuseIPDB API key found in updated keys");
                    }

                    // Add VirusTotal API if key is available
                    if let Some(virustotal_key) = decrypted_keys.get("virustotal") {
                        println!("Initializing VirusTotal API...");
                        match ApiType::init_with_cache(
                            "virustotal",
                            virustotal_key,
                            &api_key_cache_dir,
                        )
                        .await
                        {
                            Ok(api) => {
                                println!("Successfully initialized VirusTotal API");
                                new_api_instances.push(api);
                            }
                            Err(e) => {
                                eprintln!("Failed to initialize VirusTotal API: {:?}", e);
                            }
                        }
                    } else {
                        println!("No VirusTotal API key found in updated keys");
                    }

                    // Update the shared API container
                    if !new_api_instances.is_empty() {
                        println!(
                            "Updating API container with {} new API instance(s)",
                            new_api_instances.len()
                        );
                        let new_apis = Arc::new(new_api_instances);
                        apis_for_updates.insert("current".to_string(), new_apis.clone());

                        // Get current analyzers
                        let mut current_analyzers = analyzers_for_updates
                            .get_mut("current")
                            .expect("Analyzers should exist")
                            .value()
                            .clone();

                        // Check if SuspiciousIpAnalyzer exists
                        let has_suspicious_ip = current_analyzers
                            .iter()
                            .any(|a| matches!(a, AnalyzerType::SuspiciousIp(_)));

                        if !has_suspicious_ip {
                            println!("Creating new SuspiciousIpAnalyzer with updated APIs");
                            let new_analyzer = Arc::new(SuspiciousIpAnalyzer::new(new_apis, 80));
                            current_analyzers
                                .push(AnalyzerType::SuspiciousIp((*new_analyzer).clone()));
                            analyzers_for_updates.insert("current".to_string(), current_analyzers);
                            println!("SuspiciousIpAnalyzer added to analyzer list");
                        } else {
                            println!("SuspiciousIpAnalyzer already exists, updating with new APIs");
                        }

                        println!("API container and analyzers updated successfully");
                    } else {
                        println!("No APIs were successfully initialized, no updates applied");
                    }
                }
                Err(e) => {
                    eprintln!("Failed to fetch API keys for update: {:?}", e);
                }
            }
        }
    });

    // Run the analysis engine loop
    loop {
        tick_interval.tick().await;
        println!("Running analysis...");
        if let Some(current_analyzers) = analyzers.get("current") {
            let analyzers = current_analyzers.value().clone();
            let pool = pool.clone();

            // Create a vector to hold all analyzer tasks
            let mut analyzer_tasks = Vec::new();

            // Spawn a task for each analyzer
            for analyzer in analyzers {
                let pool = pool.clone();
                let task = tokio::spawn(async move {
                    if let Err(e) = analyzer.run(&pool).await {
                        eprintln!("Error running analyzer: {:?}", e);
                    }
                });
                analyzer_tasks.push(task);
            }

            futures::future::join_all(analyzer_tasks).await;
            println!("Analysis complete");
        }
    }
}

/// Initializes the config cache
///
/// # Arguments
///
/// * `pool` - The database pool.
/// * `cache` - The config cache.
async fn initialize_config_cache(
    pool: &MySqlPool,
    cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
) {
    match db::get_all_user_configs(pool).await {
        Ok(configs) => {
            for config in configs {
                cache
                    .entry(config.endpoint_id as u64)
                    .or_insert_with(Vec::new)
                    .push(config);
            }
        }
        Err(e) => eprintln!("Failed to initialize config cache: {:?}", e),
    }
}
