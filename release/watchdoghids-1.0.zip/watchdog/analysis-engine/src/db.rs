//! Database interaction module for network traffic and anomaly analysis.
//!
//! This module provides functionality to:
//! - Establish and manage database connections
//! - Insert and retrieve network traffic data
//! - Handle network anomaly events
//! - Retrieve encrypted API keys
//!
//! # Database Tables
//!
//! The module interacts with several tables:
//! - `endpoint_network_traffic`: Stores network traffic data per endpoint
//! - `network_anomaly_events`: Stores detected network anomalies and their status
//! - `external_keys`: Stores encrypted API keys for external services
//!
//! # Dependencies
//!
//! - `sqlx` for database interactions.
//! - `crate::models` for data models.
//!
//! # Examples
//!
//!
//! ```ignore
//! use analysis_engine::db;
//!
//! #[tokio::main]
//! async fn main() -> Result<(), sqlx::Error> {
//!     let pool = db::connect_to_db().await?;
//!     // Get last 30 minutes of traffic
//!     let recent = db::get_recent_traffic(&pool, 30).await?;
//!     Ok(())
//! }
//! ```
//!
//! # Environment Variables
//!
//! - `DATABASE_URL`: Required. MySQL connection string in the format:
//!   `mysql://user:password@host:port/database`
use crate::models::*;
use sqlx::{MySqlPool, Row};

/// Attempts to establish a single try database connection.
///
/// # Returns
///
/// Returns a `Result` containing either:
/// - `MySqlPool`: Successfully established connection pool
/// - `sqlx::Error`: Connection error details
///
/// # Errors
///
/// Will return an error if:
/// - DATABASE_URL environment variable is not set
/// - Connection cannot be established
///
/// # Examples
///
/// ```ignore
/// let pool = connect_to_db().await?;
/// ```
#[allow(dead_code)]
pub async fn connect_to_db() -> Result<MySqlPool, sqlx::Error> {
    let database_url = std::env::var("DATABASE_URL")
        .map_err(|_| sqlx::Error::Configuration(Box::new(std::env::VarError::NotPresent)))?;

    MySqlPool::connect(&database_url).await
}

/// Establishes database connection with retry mechanism.
///
/// Attempts to connect up to MAX_RETRIES times with DELAY_RETRY duration between attempts.
///
/// # Constants
///
/// - `MAX_RETRIES`: Maximum connection attempts (default: 5)
/// - `DELAY_RETRY`: Delay between retries (default: 5 seconds)
///
/// # Returns
///
/// Returns a `Result` containing either:
/// - `MySqlPool`: Successfully established connection pool
/// - `sqlx::Error`: Final connection error after all retries
///
/// # Errors
///
/// Will return an error if:
/// - DATABASE_URL environment variable is not set
/// - Connection cannot be established after MAX_RETRIES attempts
///
/// # Examples
///
/// ```ignore
/// let pool = connect_to_db_with_retry().await?;
/// ```
#[allow(dead_code)]
pub async fn connect_to_db_with_retry() -> Result<MySqlPool, sqlx::Error> {
    // we could add a config for these values(and otehrs) and default to these
    let mut retry_count: u64 = 0;
    loop {
        if retry_count % 5 == 0 && retry_count != 0 {
            println!("\x1b[31m!!! Many connection failures have occured, please verify database. !!!\x1b[0m")
        }
        match connect_to_db().await {
            Ok(pool) => return Ok(pool),
            Err(e) => {
                println!(
                    "Failed to connect to the database (attempt {}): {}",
                    retry_count + 1,
                    e
                );
                retry_count += 1;
            }
        }
    }
}

/// Stores a network anomaly event in the database.
///
/// # Arguments
///
/// * `pool` - Active database connection pool
/// * `data` - Network anomaly event to store
///
/// # Returns
///
/// Returns `Ok(())` on successful insertion, or `sqlx::Error` on failure.
///
/// # Examples
///
/// ```ignore
/// let event = NetworkAnomalyEvent {
///     endpoint_id: 1,
///     severity_level: Some("HIGH".to_string()),
///     // ... other fields
/// };
/// insert_network_anomaly_event(&pool, &event).await?;
/// ```
#[allow(dead_code)]
pub async fn insert_network_anomaly_event(
    pool: &MySqlPool,
    data: &NetworkAnomalyEvent,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        r#"
        INSERT INTO network_anomaly_events (
            endpoint_id,
            host_ip,
            bandwidth_usage,
            time_window_start,
            time_window_end,
            alert_description,
            severity_level,
            created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        "#,
    )
    .bind(data.endpoint_id)
    .bind(&data.host_ip)
    .bind(data.bandwidth_usage.to_string())
    .bind(data.time_window_start)
    .bind(data.time_window_end)
    .bind(data.alert_description.as_deref().unwrap_or_default())
    .bind(&data.severity_level)
    .bind(data.created_at)
    .execute(pool)
    .await
    .map_err(|e| {
        println!("Error insterting network anomoly: {:?}", e);
        e
    })?;
    Ok(())
}

/// Retrieves network traffic data from recent time window.
///
/// # Arguments
///
/// * `pool` - Active database connection pool
/// * `window_minutes` - Number of minutes to look back from current time
///
/// # Returns
///
/// Returns a `Result` containing either:
/// * `Vec<EndpointNetworkTraffic>` - Collection of traffic records
/// * `sqlx::Error` - Database error details
///
/// # Examples
///
/// ```ignore
/// // Get last 30 minutes of traffic
/// let recent = get_recent_traffic(&pool, time::int32).await?;
/// ```
#[allow(dead_code)]
pub async fn get_recent_traffic(
    pool: &MySqlPool,
    window_seconds: u64,
) -> Result<Vec<EndpointNetworkTraffic>, sqlx::Error> {
    sqlx::query_as::<_, EndpointNetworkTraffic>(
        r#"
        SELECT
            endpoint_id,
            record_timestamp,
            internal_ip,
            external_ip,
            destination_port,
            protocol,
            connection_state,
            packets,
            bytes
        FROM endpoint_network_traffic
        WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
        "#,
    )
    .bind(window_seconds)
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching recent traffic: {:?}", e);
        e
    })
}

/// Retrieves network traffic data from a specific time window in the past.
///
/// # Arguments
///
/// * `pool` - Active database connection pool
/// * `window_minutes` - Size of the time window in minutes
/// * `offset_minutes` - Minutes to offset from current time
///
/// # Returns
///
/// Returns a `Result` containing either:
/// * `Vec<EndpointNetworkTraffic>` - Collection of traffic records
/// * `sqlx::Error` - Database error details
///
/// # Examples
///
/// ```ignore
/// // Get traffic from 30-60 minutes ago (30 minute window, 30 minute offset)
/// let previous = get_previous_traffic(&pool, 30, 30).await?;
/// ```
#[allow(dead_code)]
pub async fn get_previous_traffic(
    pool: &MySqlPool,
    window_seconds: u64,
    offset_seconds: u64,
) -> Result<Vec<EndpointNetworkTraffic>, sqlx::Error> {
    sqlx::query_as::<_, EndpointNetworkTraffic>(
        r#"
        SELECT
            endpoint_id,
            record_timestamp,
            internal_ip,
            external_ip,
            destination_port,
            protocol,
            connection_state,
            packets,
            bytes
        FROM endpoint_network_traffic
        WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
        AND record_timestamp < NOW() - INTERVAL ? SECOND
        "#,
    )
    .bind(window_seconds + offset_seconds)
    .bind(offset_seconds)
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching previous traffic with offset: {:?}", e);
        e
    })
}

/// Retrieves recent protocol usage data from the database.
///
/// This function queries the `endpoint_network_traffic` table for traffic records within
/// a specified time window, returning all relevant details such as protocol, source/destination IPs,
/// and data transfer metrics.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `window_seconds` - The time window in seconds to look back from the current time.
///
/// # Returns
///
/// A `Result` containing either a vector of `EndpointNetworkTraffic` records or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// let recent_protocols = get_recent_protocols(&pool, 3600).await?;
/// for protocol in recent_protocols {
///     println!("Protocol: {}, Bytes: {}", protocol.protocol, protocol.bytes);
/// }
/// ```
pub async fn get_recent_protocols(
    pool: &MySqlPool,
    window_seconds: u64,
) -> Result<Vec<EndpointNetworkTraffic>, sqlx::Error> {
    sqlx::query_as::<_, EndpointNetworkTraffic>(
        r#"
        SELECT
            endpoint_id,
            record_timestamp,
            internal_ip,
            external_ip,
            destination_port,
            protocol,
            connection_state,
            packets,
            bytes
        FROM endpoint_network_traffic
        WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
        ORDER BY record_timestamp DESC
        "#,
    )
    .bind(window_seconds)
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching recent protocols : {:?}", e);
        e
    })
}

/// Retrieves aggregated bandwidth usage data from the database.
///
/// This function queries the `endpoint_network_traffic` table for traffic records within
/// a specified time window, grouping by `endpoint_id`, `internal_ip`, and `external_ip` to
/// calculate total bytes transferred. It returns aggregated bandwidth data.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `window_seconds` - The time window in seconds to look back from the current time.
/// * `endpoint_id` - The ID of the endpoint to retrieve bandwidth data for. Use -1 for network-wide data.
///
/// # Returns
///
/// A `Result` containing either a vector of `AggregatedBandwidth` records or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// let recent_bandwidth = get_recent_bandwidth(&pool, 86400).await?;
/// for record in recent_bandwidth {
///     println!("Endpoint: {}, Host: {}, Total Bytes: {}", record.endpoint_id, record.external_ip, record.total_bytes);
/// }
/// ```
pub async fn get_recent_bandwidth(
    pool: &MySqlPool,
    endpoint_id: u32,
    window_seconds: u64,
) -> Result<Vec<AggregatedBandwidth>, sqlx::Error> {
    if endpoint_id == 0 {
        sqlx::query_as::<_, AggregatedBandwidth>(
            r#"
            SELECT
                CAST(0 AS UNSIGNED) as endpoint_id,
                '' as internal_ip,
                '' as external_ip,
                CAST(COALESCE(SUM(bytes), 0) AS UNSIGNED) as total_bytes
            FROM endpoint_network_traffic
            WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
            "#,
        )
        .bind(window_seconds)
        .fetch_all(pool)
        .await
        .map_err(|e| {
            println!("Error fetching bandwidth from all network: {:?}", e);
            e
        })
    } else {
        sqlx::query_as::<_, AggregatedBandwidth>(
            r#"
            SELECT
                endpoint_id,
                internal_ip,
                external_ip,
                CAST(COALESCE(SUM(bytes), 0) AS UNSIGNED) as total_bytes
            FROM endpoint_network_traffic
            WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
              AND endpoint_id = ?
            GROUP BY endpoint_id, internal_ip, external_ip
            "#,
        )
        .bind(window_seconds)
        .bind(endpoint_id)
        .fetch_all(pool)
        .await
        .map_err(|e| {
            println!(
                "Error fetching recent bandwidth from certain endpoint: {:?}",
                e
            );
            e
        })
    }
}

/// Retrieves process information from the database for a given time window.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `window_seconds` - The time window in seconds for querying process data.
///
/// # Returns
///
/// A `Result` containing a vector of `EndpointProcInfo` records or a `sqlx::Error` on failure.
pub async fn get_recent_proc_info(
    pool: &MySqlPool,
    window_seconds: u64,
) -> Result<Vec<EndpointProcInfo>, sqlx::Error> {
    sqlx::query_as::<_, EndpointProcInfo>(
        r#"
        SELECT
            endpoint_id,
            record_timestamp,
            proc_info
        FROM endpoint_proc_info
        WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
        "#,
    )
    .bind(window_seconds)
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching recent proc info: {:?}", e);
        e
    })
}

/// Inserts a process anomaly event into the database.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `data` - A reference to a `ProcAnomalyEvent` containing anomaly details.
///
/// # Returns
///
/// A `Result` indicating success or a database error.
///
/// # Example
///
/// ```ignore
/// let proc_anomaly_event = ProcAnomalyEvent {
///     endpoint_id: 1,
///     proc_name: "proc_name".to_string(),
///     proc_info: "proc_info".to_string(),
///     time_window_start: OffsetDateTime::now_utc(),
///     time_window_end: OffsetDateTime::now_utc(),
///     alert_description: Some("alert_description".to_string()),
///     severity_level: Some("severity_level".to_string()),
/// };
/// insert_proc_anomaly_event(&pool, &proc_anomaly_event).await?;
/// ```
pub async fn insert_proc_anomaly_event(
    pool: &MySqlPool,
    data: &ProcAnomalyEvent,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        r#"
        INSERT INTO proc_info_anomaly_events (
            endpoint_id,
            proc_name,
            proc_info,
            time_window_start,
            time_window_end,
            alert_description,
            severity_level,
            created_at,
            updated_at,
            resolved,
            resolution_description
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        "#,
    )
    .bind(data.endpoint_id)
    .bind(&data.proc_name)
    .bind(&data.proc_info)
    .bind(data.time_window_start)
    .bind(data.time_window_end)
    .bind(data.alert_description.as_deref())
    .bind(data.severity_level.as_deref())
    .bind(data.created_at)
    .bind(data.updated_at)
    .bind(data.resolved)
    .bind(data.resolution_description.as_deref())
    .execute(pool)
    .await
    .map_err(|e| {
        println!("Error inserting proc anomoly event: {:?}", e);
        e
    })?;
    Ok(())
}

/// Retrieves user-defined anomaly configurations for a specific endpoint.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `endpoint_id` - The ID of the endpoint for which configurations are needed.
///
/// # Returns
///
/// A `Result` containing a vector of `UserAnomalyConfig` records or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// let user_configs = get_user_configs(&pool, 1).await?;
/// ```
pub async fn get_user_configs(
    pool: &MySqlPool,
    endpoint_id: u32,
) -> Result<Vec<UserAnomalyConfig>, sqlx::Error> {
    sqlx::query_as::<_, UserAnomalyConfig>(
        r#"
        SELECT
            endpoint_id,
            user_id,
            event_description,
            target_host,
            severity_level,
            bandwidth_threshold,
            sliding_window_minutes
        FROM user_network_anomaly_events
        WHERE endpoint_id = ?
        "#,
    )
    .bind(endpoint_id)
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching single user configs: {:?}", e);
        e
    })
}

/// Retrieves all user-defined anomaly configurations from the database.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
///
/// # Returns
///
/// A `Result` containing a vector of `UserAnomalyConfig` records or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// let user_configs = get_all_user_configs(&pool).await?;
/// ```
pub async fn get_all_user_configs(pool: &MySqlPool) -> Result<Vec<UserAnomalyConfig>, sqlx::Error> {
    sqlx::query_as::<_, UserAnomalyConfig>(
        r#"
        SELECT
            endpoint_id,
            user_id,
            event_description,
            target_host,
            severity_level,
            bandwidth_threshold,
            sliding_window_minutes
        FROM user_network_anomaly_events
        "#,
    )
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching all user configs: {:?}", e);
        e
    })
}

/// Inserts a network anomaly event into the database and sends an alert if severity is high.
/// This function is used to insert network anomaly events into the database and send an alert if the severity level is high or critical.
/// If the severity level is high or critical, an alert is sent asynchronously using a tokio task.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `data` - A reference to a `NetworkAnomalyEvent` containing the event details.
///
/// # Returns
///
/// A `Result` containing the ID of the inserted event or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// let event_id = insert_network_anomaly_event_with_alert(&pool, &event).await?;
/// ```
pub async fn insert_network_anomaly_event_with_alert(
    pool: &MySqlPool,
    data: &NetworkAnomalyEvent,
) -> Result<u32, sqlx::Error> {
    let result = sqlx::query(
        r#"
        INSERT INTO network_anomaly_events (
            endpoint_id,
            host_ip,
            bandwidth_usage,
            time_window_start,
            time_window_end,
            alert_description,
            severity_level,
            created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        "#,
    )
    .bind(data.endpoint_id)
    .bind(&data.host_ip)
    .bind(data.bandwidth_usage.to_string())
    .bind(data.time_window_start)
    .bind(data.time_window_end)
    .bind(data.alert_description.as_deref().unwrap_or_default())
    .bind(&data.severity_level)
    .bind(data.created_at)
    .execute(pool)
    .await?;

    let event_id = result.last_insert_id() as u32;

    if let Some(severity) = &data.severity_level {
        if severity == "CRITICAL" {
            // Use a timeout to prevent the task from hanging indefinitely
            let event_id_copy = event_id;
            tokio::spawn(async move {
                // Set a timeout for the alert sending
                let _ = tokio::time::timeout(
                    std::time::Duration::from_secs(5),
                    crate::webhook::send_alert(
                        event_id_copy,
                        crate::webhook::EventType::NetworkAnomaly,
                    ),
                )
                .await;
            });
        }
    }
    Ok(event_id)
}

/// Retrieves recent resource data from the database.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `window_seconds` - The time window in seconds for querying resource data.
///
/// # Returns
///
/// A `Result` containing a vector of `EndpointResourceData` records or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// let resource_data = get_recent_resource_data(&pool, 86400).await?;
/// ```
pub async fn get_recent_resource_data(
    pool: &MySqlPool,
    window_seconds: u64,
) -> Result<Vec<EndpointResourceData>, sqlx::Error> {
    sqlx::query_as::<_, EndpointResourceData>(
        r#"
        SELECT
            endpoint_id,
            record_timestamp,
            resource_info
        FROM endpoint_resource_data
        WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
        "#,
    )
    .bind(window_seconds)
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching recent resource data: {:?}", e);
        e
    })
}

/// Inserts a resource anomaly event into the database.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `data` - A reference to a `ResourceInfoAnomalyEvent` containing anomaly details.
///
/// # Returns
///
/// A `Result` indicating success or a database error.
///
/// # Example
///
/// ```ignore
/// let resource_anomaly_event = ResourceInfoAnomalyEvent {
///     endpoint_id: 1,
///     resource_info: "resource_info".to_string(),
///     time_window_start: OffsetDateTime::now_utc(),
///     time_window_end: OffsetDateTime::now_utc(),
///     alert_description: Some("alert_description".to_string()),
///     severity_level: Some("severity_level".to_string()),
/// };
/// insert_resource_anomaly_event(&pool, &resource_anomaly_event).await?;
/// ```
pub async fn insert_resource_anomaly_event(
    pool: &MySqlPool,
    data: &ResourceInfoAnomalyEvent,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        r#"
        INSERT INTO resource_info_anomaly_events (
            endpoint_id,
            resource_info,
            time_window_start,
            time_window_end,
            alert_description,
            severity_level,
            created_at,
            updated_at,
            resolved,
            resolution_description
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        "#,
    )
    .bind(data.endpoint_id)
    .bind(&data.resource_info)
    .bind(data.time_window_start)
    .bind(data.time_window_end)
    .bind(data.alert_description.as_deref())
    .bind(data.severity_level.as_deref())
    .bind(data.created_at)
    .bind(data.updated_at)
    .bind(data.resolved)
    .bind(data.resolution_description.as_deref())
    .execute(pool)
    .await
    .map_err(|e| {
        println!("Error inserting resource anomaly event: {:?}", e);
        e
    })?;
    Ok(())
}

/// Retrieves recent user login data from the database.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `window_seconds` - The time window in seconds for querying login data.
///
/// # Returns
///
/// A `Result` containing a vector of login data records or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// let login_data = get_recent_user_logins(&pool, 86400).await?;
/// ```
pub async fn get_recent_user_logins(
    pool: &MySqlPool,
    window_seconds: u64,
) -> Result<Vec<serde_json::Value>, sqlx::Error> {
    let login_records = sqlx::query_as::<_, EndpointLoginInfo>(
        r#"
        SELECT
            endpoint_id,
            record_timestamp,
            login_info
        FROM endpoint_login_info
        WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
        "#,
    )
    .bind(window_seconds)
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching recent login data: {:?}", e);
        e
    })?;

    // Process the login records into the expected format
    let mut result = Vec::new();
    for record in login_records {
        let combined_record = serde_json::json!({
            "EndpointId": record.endpoint_id,
            "LoginData": record.login_info.0,
            "UserData": {},
            "GroupData": {},
        });

        result.push(combined_record);
    }

    Ok(result)
}

/// Inserts a user login anomaly event into the database.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `data` - A reference to a `UserLoginAnomalyEvent` containing anomaly details.
///
/// # Returns
///
/// A `Result` indicating success or a database error.
///
/// # Example
///
/// ```ignore
/// let user_login_anomaly_event = UserLoginAnomalyEvent {
///     uid: 1000,
///     username: "user".to_string(),
///     ip: "192.168.1.1".parse().unwrap(),
///     login_time: OffsetDateTime::now_utc(),
///     logout_time: Some(OffsetDateTime::now_utc()),
///     alert_description: Some("Suspicious login".to_string()),
///     severity_level: Some("HIGH".to_string()),
///     // ... other fields
/// };
/// insert_user_login_anomaly_event(&pool, &user_login_anomaly_event).await?;
/// ```
pub async fn insert_user_login_anomaly_event(
    pool: &MySqlPool,
    data: &crate::models::UserLoginAnomalyEvent,
) -> Result<(), sqlx::Error> {
    // Creates a JSON object for login_info
    let login_info = serde_json::json!({
        "username": data.username,
        "ip": data.ip.to_string(),
        "login_time": data.login_time.to_string(),
        "logout_time": data.logout_time.map(|t| t.to_string()),
        "alert_reason": data.alert_description
    });

    // Check if a similar anomaly already exists in the database
    let existing = sqlx::query(
        r#"
        SELECT COUNT(*) as count
        FROM login_info_anomaly_events
        WHERE endpoint_id = ?
        AND JSON_EXTRACT(login_info, '$.ip') = ?
        AND JSON_EXTRACT(login_info, '$.alert_reason') = ?
        AND created_at >= NOW() - INTERVAL 1 HOUR
        "#,
    )
    .bind(data.endpoint_id)
    .bind(format!("\"{}\"", data.ip.to_string()))
    .bind(format!(
        "\"{}\"",
        data.alert_description.as_deref().unwrap_or_default()
    ))
    .fetch_one(pool)
    .await;
    let count = match existing {
        Ok(row) => {
            let count: i64 = row.get("count");
            count
        }
        Err(_) => 0,
    };

    // If no duplicates found in database, insert the new record
    if count == 0 {
        sqlx::query(
            r#"
            INSERT INTO login_info_anomaly_events (
                endpoint_id,
                login_info,
                time_window_start,
                time_window_end,
                alert_description,
                acknowledged,
                severity_level,
                created_at,
                updated_at,
                resolved,
                resolution_description
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            "#,
        )
        .bind(data.endpoint_id)
        .bind(login_info.to_string())
        .bind(data.login_time)
        .bind(data.logout_time.unwrap_or(data.login_time))
        .bind(data.alert_description.as_deref())
        .bind(data.acknowledged)
        .bind(data.severity_level.as_deref())
        .bind(data.created_at)
        .bind(data.updated_at)
        .bind(data.resolved)
        .bind(data.resolution_description.as_deref())
        .execute(pool)
        .await
        .map_err(|e| {
            println!("Error inserting user login anomaly event: {:?}", e);
            e
        })?;
    }

    Ok(())
}

/// Retrieves recent file integrity data from the database.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `window_seconds` - The time window in seconds for querying file data.
///
/// # Returns
///
/// A `Result` containing a vector of `EndpointFileInfo` records or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// let file_data = get_recent_file_info(&pool, 86400).await?;
/// ```
pub async fn get_recent_file_info(
    pool: &MySqlPool,
    window_seconds: u64,
) -> Result<Vec<EndpointFileInfo>, sqlx::Error> {
    sqlx::query_as::<_, EndpointFileInfo>(
        r#"
        SELECT
            endpoint_id,
            record_timestamp,
            file_info
        FROM endpoint_file_info
        WHERE record_timestamp >= NOW() - INTERVAL ? SECOND
        "#,
    )
    .bind(window_seconds)
    .fetch_all(pool)
    .await
    .map_err(|e| {
        println!("Error fetching recent file info: {:?}", e);
        e
    })
}

/// Inserts a file integrity anomaly event into the database.
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `data` - A reference to a `FileInfoAnomalyEvent` containing anomaly details.
///
/// # Returns
///
/// A `Result` indicating success or a database error.
///
/// # Example
///
/// ```ignore
/// let file_anomaly_event = FileInfoAnomalyEvent {
///     endpoint_id: 1,
///     file_info: json!({"path": "/etc/passwd", "action": "mod"}).into(),
///     time_window_start: OffsetDateTime::now_utc(),
///     time_window_end: OffsetDateTime::now_utc(),
///     alert_description: Some("Sensitive file modified".to_string()),
///     severity_level: Some("HIGH".to_string()),
///     // ... other fields
/// };
/// insert_file_info_anomaly_event(&pool, &file_anomaly_event).await?;
/// ```
pub async fn insert_file_info_anomaly_event(
    pool: &MySqlPool,
    data: &FileInfoAnomalyEvent,
) -> Result<(), sqlx::Error> {
    let result = sqlx::query(
        r#"
        INSERT INTO file_info_anomaly_events (
            endpoint_id,
            file_info,
            time_window_start,
            time_window_end,
            alert_description,
            acknowledged,
            severity_level,
            created_at,
            updated_at,
            resolved,
            resolution_description
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        "#,
    )
    .bind(data.endpoint_id)
    .bind(&data.file_info)
    .bind(data.time_window_start)
    .bind(data.time_window_end)
    .bind(data.alert_description.as_deref())
    .bind(data.acknowledged)
    .bind(data.severity_level.as_deref())
    .bind(data.created_at)
    .bind(data.updated_at)
    .bind(data.resolved)
    .bind(data.resolution_description.as_deref())
    .execute(pool)
    .await
    .map_err(|e| {
        println!("Error inserting file integrity anomaly event: {:?}", e);
        e
    })?;

    // If severity is CRITICAL, send an alert
    if let Some(severity) = &data.severity_level {
        if severity == "CRITICAL" || severity == "HIGH" {
            let event_id = result.last_insert_id() as u32;
            tokio::spawn(async move {
                if let Err(e) = crate::webhook::send_alert(
                    event_id,
                    crate::webhook::EventType::FileIntegrityAnomaly,
                )
                .await
                {
                    eprintln!("Error sending file integrity alert: {:?}", e);
                }
            });
        }
    }

    Ok(())
}

/// Retrieves encrypted API keys from the database
///
/// # Arguments
///
/// * `pool` - A reference to the MySQL database connection pool.
/// * `key_id` - Optional ID of the specific key to retrieve. If None, retrieves all active keys.
///   Note: The API key update pipeline only uses this function with a specific key ID.
///
/// # Returns
///
/// A `Result` containing a vector of `ExternalKey` records or a `sqlx::Error` on failure.
///
/// # Example
///
/// ```ignore
/// // Get all active API keys (used for initial loading)
/// let keys = get_external_keys(&pool, None).await?;
///
/// // Get a specific API key (used for updates)
/// let key = get_external_keys(&pool, Some(1)).await?;
/// ```
pub async fn get_external_keys(
    pool: &MySqlPool,
    key_id: Option<i32>,
) -> Result<Vec<ExternalKey>, sqlx::Error> {
    match key_id {
        Some(id) => {
            println!("Fetching specific API key with ID: {}", id);
            let result = sqlx::query_as::<_, ExternalKey>(
                r#"
                SELECT
                    id,
                    description,
                    enc_key,
                    status
                FROM external_keys
                WHERE id = ? AND status = 1
                "#,
            )
            .bind(id)
            .fetch_all(pool)
            .await
            .map_err(|e| {
                eprintln!("Error fetching external key with ID {}: {:?}", id, e);
                e
            });

            if let Ok(keys) = &result {
                if keys.is_empty() {
                    println!("No active API key found with ID: {}", id);
                } else {
                    println!("Successfully fetched API key with ID: {}", id);
                }
            }

            result
        }
        None => {
            println!("Fetching all active API keys");
            let result = sqlx::query_as::<_, ExternalKey>(
                r#"
                SELECT
                    id,
                    description,
                    enc_key,
                    status
                FROM external_keys
                WHERE status = 1
                "#,
            )
            .fetch_all(pool)
            .await
            .map_err(|e| {
                eprintln!("Error fetching all external keys: {:?}", e);
                e
            });

            if let Ok(keys) = &result {
                if keys.is_empty() {
                    println!("No active API keys found in database");
                } else {
                    println!("Successfully fetched {} active API keys", keys.len());
                }
            }

            result
        }
    }
}
