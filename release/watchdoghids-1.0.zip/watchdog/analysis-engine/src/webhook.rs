//! Webhook server for updating user configurations.
//!
//! This module contains the code for a simple webhook server that listens for incoming POST requests.
//! The server expects a JSON body with an `endpoint_id` field and updates the cache with the user's
//! anomaly configuration from the database.
//!
//! # Dependencies
//!
//! - `warp` for the web server implementation.
//! - `sqlx` for database interactions.
//! - `dashmap` for shared cache management.
//! - `serde` for JSON serialization.
//! - `tokio` for async runtime.
use crate::db;
use crate::models::UserAnomalyConfig;
use dashmap::DashMap;
use reqwest::Client;
use sqlx::MySqlPool;
use std::sync::Arc;
use std::{convert::Infallible, time::Duration};
use tokio::sync::broadcast;
use warp::{Filter, Rejection, Reply};

/// Represents a request to update a user's anomaly configuration
///
/// # Fields
///
/// * `endpoint_id` - The ID of the endpoint to update the configuration for.
#[derive(serde::Deserialize)]
struct WebhookRequest {
    endpoint_id: u32,
}

/// Represents a request to notify about API key updates
///
/// # Fields
///
/// * `key_id` - ID of the specific key that was updated.
#[derive(serde::Deserialize)]
struct ApiKeyUpdateRequest {
    key_id: i32,
}

/// Notification type for API key updates
#[derive(Debug, Clone)]
pub enum ApiKeyNotification {
    /// Update a specific key
    UpdateKey(i32),
}

/// Represents a request to send an alert
///
/// # Fields
///
/// * `event_id` - The ID of the event to alert on.
/// * `event_type` - The type of event (0=network, 1=process, 2=resource, 3=login, 4=file).
#[derive(serde::Serialize, Debug)]
pub struct AlertRequest {
    event_id: u32,
    event_type: u8,
}

/// Represents the type of event
///
/// # Variants
///
/// * `NetworkAnomaly` - A network anomaly event (0).
/// * `ProcInfoAnomaly` - A process info anomaly event (1).
/// * `ResourceInfoAnomaly` - A resource info anomaly event (2).
/// * `LoginInfoAnomaly` - A login info anomaly event (3).
/// * `FileIntegrityAnomaly` - A file integrity anomaly event (4).
#[derive(Debug, Clone, Copy)]
pub enum EventType {
    NetworkAnomaly = 0,
    ProcInfoAnomaly = 1,
    ResourceInfoAnomaly = 2,
    LoginInfoAnomaly = 3,
    FileIntegrityAnomaly = 4,
}

/// Starts the webhook server
///
/// This function starts a new warp server that listens for incoming webhook requests.
/// The server provides two endpoints:
/// - `/webhook/config-update`: Updates user anomaly configurations
/// - `/webhook/api-key-update`: Notifies about API key updates
///
/// # Arguments
///
/// * `cache` - A reference to the shared cache of user configurations.
/// * `pool` - A reference to the MySQL database connection pool.
/// * `api_key_tx` - A sender for API key update notifications.
pub async fn start_webhook_server(
    cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
    pool: MySqlPool,
    api_key_tx: broadcast::Sender<ApiKeyNotification>,
) {
    let api_key = std::env::var("WEBHOOK_API_KEY").expect("WEBHOOK_API_KEY must be set");
    let api_key_clone = api_key.clone();

    // Config update endpoint
    let config_update = warp::path!("webhook" / "config-update")
        .and(warp::post())
        .and(warp::any().map(move || api_key.clone()))
        .and(warp::header::<String>("x-api-key"))
        .and(warp::body::json())
        .and(with_db(pool.clone()))
        .and(with_cache(cache.clone()))
        .and_then(handle_config_update);

    // API key update endpoint
    let api_key_tx = warp::any().map(move || api_key_tx.clone());
    let api_key_update = warp::path!("webhook" / "api-key-update")
        .and(warp::post())
        .and(warp::any().map(move || api_key_clone.clone()))
        .and(warp::header::<String>("x-api-key"))
        .and(warp::body::json())
        .and(with_db(pool.clone()))
        .and(api_key_tx)
        .and_then(handle_api_key_update);

    println!("API key update webhook endpoint configured at /webhook/api-key-update");

    // Combine routes
    let routes = config_update.or(api_key_update);

    // Start the server
    println!("Starting webhook server on port 8080");
    warp::serve(routes).run(([0, 0, 0, 0], 8080)).await;
}

/// Creates a Warp filter that provides a database connection.
///
/// # Arguments
///
/// * `pool` - A MySQL connection pool.
///
/// # Returns
///
/// A Warp filter that injects the database connection into handlers.
fn with_db(pool: MySqlPool) -> impl Filter<Extract = (MySqlPool,), Error = Infallible> + Clone {
    warp::any().map(move || pool.clone())
}

fn with_cache(
    cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
) -> impl Filter<Extract = (Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,), Error = Infallible> + Clone
{
    warp::any().map(move || cache.clone())
}

/// Handles requests to update user anomaly configurations
///
/// # Arguments
///
/// * `expected_key` - The expected API key for authentication
/// * `incoming_key` - The API key provided in the request
/// * `req` - The webhook request containing the endpoint ID
/// * `pool` - The database connection pool
/// * `cache` - The shared cache of user configurations
///
/// # Returns
///
/// A Result containing a reply with the appropriate status code
async fn handle_config_update(
    expected_key: String,
    incoming_key: String,
    req: WebhookRequest,
    pool: MySqlPool,
    cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
) -> Result<impl Reply, Rejection> {
    if incoming_key != expected_key {
        return Ok(warp::reply::with_status(
            "Unauthorized",
            warp::http::StatusCode::UNAUTHORIZED,
        ));
    }

    match db::get_user_configs(&pool, req.endpoint_id).await {
        Ok(configs) => {
            cache.insert(req.endpoint_id as u64, configs);
            Ok(warp::reply::with_status(
                "Configuration updated",
                warp::http::StatusCode::OK,
            ))
        }
        Err(e) => {
            eprintln!("Failed to update config: {:?}", e);
            Ok(warp::reply::with_status(
                "Internal server error",
                warp::http::StatusCode::INTERNAL_SERVER_ERROR,
            ))
        }
    }
}

/// Handles requests to update API keys
///
/// # Arguments
///
/// * `expected_key` - The expected API key for authentication
/// * `incoming_key` - The API key provided in the request
/// * `req` - The API key update request
/// * `pool` - The database connection pool
/// * `api_key_tx` - A sender for API key update notifications
///
/// # Returns
///
/// A Result containing a reply with the appropriate status code
async fn handle_api_key_update(
    expected_key: String,
    incoming_key: String,
    req: ApiKeyUpdateRequest,
    pool: MySqlPool,
    api_key_tx: broadcast::Sender<ApiKeyNotification>,
) -> Result<impl Reply, Rejection> {
    if incoming_key != expected_key {
        return Ok(warp::reply::with_status(
            "Unauthorized",
            warp::http::StatusCode::UNAUTHORIZED,
        ));
    }

    // Fetch the updated key from the database
    println!(
        "Processing API key update request for key ID: {}",
        req.key_id
    );
    match db::get_external_keys(&pool, Some(req.key_id)).await {
        Ok(keys) => {
            if keys.is_empty() {
                println!("No API key found with ID: {}", req.key_id);
                return Ok(warp::reply::with_status(
                    "No key found",
                    warp::http::StatusCode::NOT_FOUND,
                ));
            }

            // Create notification for the specific key
            println!("API key update received for key ID: {}", req.key_id);
            let notification = ApiKeyNotification::UpdateKey(req.key_id);

            // Send the notification
            println!("Sending API key update notification to main process...");
            if let Err(e) = api_key_tx.send(notification) {
                eprintln!("Failed to send API key update notification: {}", e);
            } else {
                println!("API key update notification sent successfully");
            }

            Ok(warp::reply::with_status(
                "API key update received",
                warp::http::StatusCode::OK,
            ))
        }
        Err(e) => {
            eprintln!("Failed to fetch updated API keys: {:?}", e);
            Ok(warp::reply::with_status(
                "Internal server error",
                warp::http::StatusCode::INTERNAL_SERVER_ERROR,
            ))
        }
    }
}

/// Sends an alert to the external notification server
///
/// # Arguments
///
/// * `event_id` - The ID of the event to alert on
/// * `event_type` - The type of event (0=network, 1=process, 2=resource, 3=login, 4=file)
///
/// # Returns
///
/// A Result indicating success or a communication error with detailed message
pub async fn send_alert(event_id: u32, event_type: EventType) -> Result<(), String> {
    // Check if NOTIFICATION_SERVER_URL is set and valid
    let server_url = match std::env::var("NOTIFICATION_SERVER_URL") {
        Ok(url) => {
            if url.starts_with("http://") || url.starts_with("https://") {
                url
            } else {
                format!("http://{}", url)
            }
        }
        Err(_) => "http://localhost:8081".to_string(),
    };

    let endpoint = format!("{}/analytics/alerts/new", server_url);

    let client = Client::builder()
        .timeout(Duration::from_secs(3))
        .connect_timeout(Duration::from_secs(2))
        .build()
        .map_err(|e| format!("Failed to build HTTP client: {}", e))?;

    let request_body = AlertRequest {
        event_id,
        event_type: event_type as u8,
    };

    let response = client
        .post(&endpoint)
        .header("Content-Type", "application/json")
        .json(&request_body)
        .send()
        .await
        .map_err(|e| format!("Failed to send alert request: {}", e))?;

    let status = response.status();

    let response_text = response
        .text()
        .await
        .unwrap_or_else(|e| format!("Failed to read response body: {}", e));

    if !status.is_success() {
        return Err(format!(
            "Server returned error: {} - {}",
            status, response_text
        ));
    }
    Ok(())
}
