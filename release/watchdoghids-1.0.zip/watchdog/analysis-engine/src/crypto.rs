//! Cryptography module for handling encrypted data
//!
//! This module provides functionality to decrypt data encrypted with AGE encryption.
//! It handles ASCII armor decoding and AGE decryption using a provided identity key.
//!
//! # Dependencies
//!
//! - `age` for AGE encryption/decryption.
//! - `std::io` for reading/writing data.
//! - `std::str::FromStr` for parsing identity keys.

use std::io::Read;
use std::str::FromStr;

/// Error type for cryptography operations
#[derive(Debug, thiserror::Error)]
pub enum CryptoError {
    #[error("Failed to decode ASCII armor: {0}")]
    ArmorDecodeError(String),

    #[error("Failed to parse identity: {0}")]
    IdentityParseError(String),

    #[error("Decryption failed: {0}")]
    DecryptionError(String),

    #[error("I/O error: {0}")]
    IoError(#[from] std::io::Error),
}

/// Decrypts data encrypted with AGE encryption
///
/// # Arguments
///
/// * `encrypted_data` - The encrypted data in ASCII armor format
/// * `identity_key` - The AGE identity key for decryption
///
/// # Returns
///
/// A Result containing the decrypted data as a String, or a CryptoError
pub fn decrypt_age_data(encrypted_data: &str, identity_key: &str) -> Result<String, CryptoError> {
    // First decode the ASCII armor
    let decoded = decode_ascii_armor(encrypted_data)?;

    // Parse the identity key
    let identity = age::x25519::Identity::from_str(identity_key)
        .map_err(|e| CryptoError::IdentityParseError(e.to_string()))?;

    // Use the age::decrypt function which handles the decryption process
    let decrypted = age::decrypt(&identity, &decoded)
        .map_err(|e| CryptoError::DecryptionError(e.to_string()))?;

    // Convert to string
    String::from_utf8(decrypted).map_err(|e| CryptoError::DecryptionError(e.to_string()))
}

/// Decodes ASCII armor format
///
/// # Arguments
///
/// * `armored_data` - The data in ASCII armor format
///
/// # Returns
///
/// A Result containing the decoded data as a Vec<u8>, or a CryptoError
fn decode_ascii_armor(armored_data: &str) -> Result<Vec<u8>, CryptoError> {
    let mut decoded = Vec::new();
    let mut reader = age::armor::ArmoredReader::new(armored_data.as_bytes());
    reader
        .read_to_end(&mut decoded)
        .map_err(|e| CryptoError::ArmorDecodeError(e.to_string()))?;

    Ok(decoded)
}
