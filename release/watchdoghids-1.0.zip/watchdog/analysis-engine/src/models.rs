//! Data models for network traffic analysis
//!
//! Contains struct definitions for:
//! - Network traffic records
//! - Anomaly events
//!
//! These models map directly to database tables and provide
//! type-safe access to the data.
//!
//! # Dependencies
//!
//! - `serde_json` for JSON parsing.
//! - `sqlx` for database interactions.
//! - `time` for date and time operations.
//! - `std::net::IpAddr` for IP address handling.

use serde::{Deserialize, Serialize};
use serde_json::Value;
use sqlx::types::Json;
use sqlx::FromRow;
use std::collections::HashMap;
use std::net::IpAddr;
use time::OffsetDateTime;

/// Represents a single network traffic record from an endpoint
///
/// Maps to the `endpoint_network_traffic` table in the database.
#[derive(Debug, FromRow, Clone)]
#[allow(dead_code)]
pub struct EndpointNetworkTraffic {
    pub endpoint_id: u32,
    pub record_timestamp: OffsetDateTime,
    pub internal_ip: String,
    pub external_ip: String,
    pub destination_port: u32,
    pub protocol: String,
    pub connection_state: String,
    pub packets: u32,
    pub bytes: u64,
}

/// Represents a detected network traffic anomaly
///
/// Maps to the `network_anomaly_events` table in the database.
#[derive(Debug, FromRow, Clone)]
#[allow(dead_code)]
pub struct NetworkAnomalyEvent {
    pub event_id: u32,
    pub endpoint_id: u32,
    pub host_ip: String,
    pub bandwidth_usage: u64,
    pub time_window_start: OffsetDateTime,
    pub time_window_end: OffsetDateTime,
    pub alert_description: Option<String>,
    pub acknowledged: bool,
    pub severity_level: Option<String>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub resolved: bool,
    pub resolution_description: Option<String>,
}

/// Represents aggregated bandwidth data for an endpoint
#[derive(Debug, FromRow, Clone)]
pub struct AggregatedBandwidth {
    pub endpoint_id: u32,
    pub internal_ip: String,
    pub external_ip: String,
    pub total_bytes: u64,
}

/// Represents process information for an endpoint
///
/// Maps to the `endpoint_proc_info` table in the database.
#[derive(Debug, FromRow, Clone)]
pub struct EndpointProcInfo {
    pub endpoint_id: u32,
    pub record_timestamp: OffsetDateTime,
    pub proc_info: Json<Value>,
}

/// Represents login information for an endpoint
///
/// Maps to the `endpoint_login_info` table in the database.
#[allow(dead_code)]
#[derive(Debug, FromRow, Clone)]
pub struct EndpointLoginInfo {
    pub endpoint_id: u32,
    pub record_timestamp: OffsetDateTime,
    pub login_info: Json<Value>,
}

/// Represents a detected process anomaly
///
/// Maps to the `proc_anomaly_events` table in the database.
#[derive(Debug, FromRow, Clone)]
pub struct ProcAnomalyEvent {
    pub endpoint_id: u32,
    pub proc_name: String,
    pub proc_info: Json<Value>,
    pub time_window_start: OffsetDateTime,
    pub time_window_end: OffsetDateTime,
    pub alert_description: Option<String>,
    pub acknowledged: bool,
    pub severity_level: Option<String>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub resolved: bool,
    pub resolution_description: Option<String>,
}

/// Represents a user anomaly configuration
///
/// Maps to the `user_anomaly_configs` table in the database.
#[derive(Debug, FromRow, Clone)]
pub struct UserAnomalyConfig {
    pub endpoint_id: u32,
    pub user_id: u32,
    pub event_description: String,
    pub target_host: String,
    pub severity_level: String,
    pub bandwidth_threshold: u64,
    pub sliding_window_minutes: u64,
}

/// Represents IP threat information
#[derive(Debug, FromRow, Clone, Serialize, Deserialize)]
#[allow(dead_code)]
pub struct IpThreatInfo {
    pub ip: IpAddr,
    pub is_malicious: bool,
    pub confidence_score: u8,
    pub categories: Vec<String>,
    pub total_reports: u32,
    pub country_code: Option<String>,
    pub country_name: Option<String>,
    pub isp: Option<String>,
    pub domain: Option<String>,
    pub usage_type: Option<String>,
    pub last_reported_at: Option<String>,
    pub source: String,
}

/// Represents abuse IP data
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct AbuseIpData {
    #[serde(rename = "ipAddress")]
    pub ip_address: String,
    #[serde(rename = "isPublic")]
    pub is_public: Option<bool>,
    #[serde(rename = "ipVersion")]
    pub ip_version: Option<u8>,
    #[serde(rename = "isWhitelisted")]
    pub is_whitelisted: Option<bool>,
    #[serde(rename = "abuseConfidenceScore")]
    pub abuse_confidence_score: u8,
    #[serde(rename = "countryCode")]
    pub country_code: Option<String>,
    #[serde(rename = "countryName")]
    pub country_name: Option<String>,
    #[serde(rename = "usageType")]
    pub usage_type: Option<String>,
    #[serde(rename = "isp")]
    pub isp: Option<String>,
    #[serde(rename = "domain")]
    pub domain: Option<String>,
    #[serde(rename = "hostnames")]
    pub hostnames: Option<Vec<String>>,
    #[serde(rename = "isTor")]
    pub is_tor: Option<bool>,
    #[serde(rename = "totalReports")]
    pub total_reports: u32,
    #[serde(rename = "numDistinctUsers")]
    pub num_distinct_users: Option<u32>,
    #[serde(rename = "lastReportedAt")]
    pub last_reported_at: Option<String>,
    #[serde(default)]
    pub reports: Option<Vec<AbuseReport>>,
    #[serde(default)]
    pub categories: Vec<u32>,
}

/// Represents an abuse report in the AbuseIPDB response
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct AbuseReport {
    #[serde(rename = "reportedAt")]
    pub reported_at: String,
    pub comment: Option<String>,
    pub categories: Vec<u32>,
    #[serde(rename = "reporterId")]
    pub reporter_id: u32,
    #[serde(rename = "reporterCountryCode")]
    pub reporter_country_code: Option<String>,
    #[serde(rename = "reporterCountryName")]
    pub reporter_country_name: Option<String>,
}

/// Represents an abuse IPDB response
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct AbuseIpDbResponse {
    pub data: AbuseIpData,
}

/// Represents resource data for an endpoint
///
/// Maps to the `endpoint_resource_data` table in the database.
#[derive(Debug, FromRow, Clone)]
pub struct EndpointResourceData {
    pub endpoint_id: u32,
    pub record_timestamp: OffsetDateTime,
    pub resource_info: Json<Value>,
}

/// Represents a resource info anomaly event
///
/// Maps to the `resource_info_anomaly_events` table in the database.
#[derive(Debug, Clone)]
pub struct ResourceInfoAnomalyEvent {
    pub endpoint_id: u32,
    pub resource_info: Json<Value>,
    pub time_window_start: OffsetDateTime,
    pub time_window_end: OffsetDateTime,
    pub alert_description: Option<String>,
    pub acknowledged: bool,
    pub severity_level: Option<String>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub resolved: bool,
    pub resolution_description: Option<String>,
}

/// Represents a VirusTotal API response
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct VirusTotalResponse {
    pub data: VirusTotalData,
}

/// Represents VirusTotal data
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct VirusTotalData {
    pub attributes: VirusTotalAttributes,
}

/// Represents VirusTotal attributes
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct VirusTotalAttributes {
    pub last_analysis_stats: AnalysisStats,
    pub last_analysis_results: std::collections::HashMap<String, AnalysisResult>,
    pub country: String,
    pub last_modification_date: i64,
}

/// Represents VirusTotal analysis statistics
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct AnalysisStats {
    pub malicious: u32,
    pub suspicious: u32,
    pub harmless: u32,
}

/// Represents a VirusTotal analysis result
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct AnalysisResult {
    pub category: String,
    pub result: String,
}

/// Represents a cached entry for IP threat information
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct CacheEntry {
    pub threat_info: IpThreatInfo,
    pub cached_at: i64,
}

/// Represents the structure of the cache file
#[derive(Debug, Serialize, Deserialize)]
pub struct CacheFile {
    pub version: u8,
    pub entries: HashMap<String, CacheEntry>,
}

/// Represents user data from the system
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserData {
    pub name: String,
}

/// Represents group data from the system
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GroupData {
    pub name: String,
    pub members: Vec<u32>,
}

/// Represents login data from the system
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoginData {
    pub ip: IpAddr,
    pub date_start: String,
    pub time_start: String,
    pub date_end: String,
    pub time_end: String,
}

/// Represents a user login anomaly event
#[derive(Debug, Clone)]
pub struct UserLoginAnomalyEvent {
    pub endpoint_id: u32,
    pub username: String,
    pub ip: IpAddr,
    pub login_time: OffsetDateTime,
    pub logout_time: Option<OffsetDateTime>,
    pub alert_description: Option<String>,
    pub acknowledged: bool,
    pub severity_level: Option<String>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub resolved: bool,
    pub resolution_description: Option<String>,
}

/// Represents file integrity information for an endpoint
///
/// Maps to the `endpoint_file_info` table in the database.
#[derive(Debug, FromRow, Clone)]
pub struct EndpointFileInfo {
    pub endpoint_id: u32,
    pub record_timestamp: OffsetDateTime,
    pub file_info: Json<Value>,
}

/// Represents a file integrity anomaly event
///
/// Maps to the `file_info_anomaly_events` table in the database.
#[derive(Debug, Clone)]
pub struct FileInfoAnomalyEvent {
    pub endpoint_id: u32,
    pub file_info: Json<Value>,
    pub time_window_start: OffsetDateTime,
    pub time_window_end: OffsetDateTime,
    pub alert_description: Option<String>,
    pub acknowledged: bool,
    pub severity_level: Option<String>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub resolved: bool,
    pub resolution_description: Option<String>,
}

/// Represents an external API key from the database
#[derive(Debug, sqlx::FromRow)]
pub struct ExternalKey {
    pub id: i32,
    pub description: String,
    pub enc_key: String,
    pub status: bool,
}
