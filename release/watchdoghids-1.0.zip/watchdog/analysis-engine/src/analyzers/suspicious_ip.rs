//! Module for analyzing network traffic for suspicious IP addresses
//!
//! This module provides the SuspiciousIpAnalyzer struct, which is responsible for
//! analyzing network traffic data for connections to suspicious IP addresses.
//! The analyzer uses threat intelligence APIs to check IP addresses for malicious activity
//! and creates anomaly events for detected threats.
//!
//! # Dependencies
//!
//! - `crate::api::ApiType` for API types.
//! - `crate::models::{EndpointNetworkTraffic, NetworkAnomalyEvent}` for data models.
//! - `sqlx::MySqlPool` for database interactions.
//! - `std::net::IpAddr` for IP address handling.
//! - `std::sync::Arc` for shared references.
//! - `time::OffsetDateTime` for date and time operations.
//! - `std::str::FromStr` for string parsing.   

use crate::api::ApiType;
use crate::models::{EndpointNetworkTraffic, NetworkAnomalyEvent};
use sqlx::MySqlPool;
use std::net::IpAddr;
use std::str::FromStr;
use std::sync::Arc;
use time::OffsetDateTime;

#[derive(Clone)]
pub struct SuspiciousIpAnalyzer {
    apis: Arc<Vec<ApiType>>,
    confidence_threshold: u8,
}

impl SuspiciousIpAnalyzer {
    /// Creates a new instance of the SuspiciousIpAnalyzer.
    ///
    /// # Arguments
    ///
    /// * `apis` - Arc containing available API services
    /// * `confidence_threshold` - Minimum confidence score to consider an IP malicious (0-100)
    ///
    /// # Returns
    ///
    /// A new instance of SuspiciousIpAnalyzer
    pub fn new(apis: Arc<Vec<ApiType>>, confidence_threshold: u8) -> Self {
        Self {
            apis,
            confidence_threshold: confidence_threshold.clamp(0, 100),
        }
    }

    /// Run the suspicious IP analysis on recent network traffic data.
    ///
    /// This method:
    /// 1. Fetches recent network traffic from the database
    /// 2. For each unique external IP, checks against threat intelligence APIs
    /// 3. Creates anomaly events for IPs found to be malicious
    /// 4. Stores the events in the database
    ///
    /// # Arguments
    ///
    /// * `pool` - Database connection pool
    ///
    /// # Returns
    ///
    /// A Result indicating success or containing a database error
    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        let traffic_data = crate::db::get_recent_traffic(pool, 30).await?;

        let mut suspicious_events = Vec::new();

        let mut unique_ips = std::collections::HashMap::new();
        for traffic in &traffic_data {
            unique_ips.insert(traffic.external_ip.clone(), traffic);
        }

        for (ip_str, traffic_record) in unique_ips {
            if is_private_ip(&ip_str) {
                continue;
            }

            if let Ok(ip) = IpAddr::from_str(&ip_str) {
                for api in self.apis.iter() {
                    let api_call_result =
                        tokio::time::timeout(std::time::Duration::from_secs(30), api.check_ip(ip))
                            .await;

                    // Handle timeout result
                    match api_call_result {
                        Ok(api_result) => {
                            // Handle API result
                            match api_result {
                                Ok(threat_info) => {
                                    let is_malicious = threat_info.is_malicious;
                                    let confidence_score = threat_info.confidence_score;

                                    if is_malicious && confidence_score >= self.confidence_threshold
                                    {
                                        let event =
                                            create_anomaly_event(traffic_record, &threat_info);
                                        suspicious_events.push(event);
                                    }

                                    //got a result, no need to try other APIs
                                    break;
                                }
                                Err(e) => {
                                    eprintln!("Error checking IP {}: {:?}", ip_str, e);
                                    // Try the next API
                                    continue;
                                }
                            }
                        }
                        Err(e) => {
                            eprintln!("Timeout checking IP {}: {}", ip_str, e);
                            // Try the next API
                            continue;
                        }
                    }
                }
            }
        }
        for event in suspicious_events {
            if let Err(e) = crate::db::insert_network_anomaly_event_with_alert(pool, &event).await {
                eprintln!("Error inserting event for IP {}: {:?}", event.host_ip, e);
            }
        }
        Ok(())
    }
}

// Create a NetworkAnomalyEvent for a detected suspicious IP
///
/// # Arguments
///
/// * `traffic` - A reference to the `EndpointNetworkTraffic` record.
/// * `threat_info` - A reference to the `IpThreatInfo` record.
///
/// # Returns   
///
/// A `NetworkAnomalyEvent` record.
fn create_anomaly_event(
    traffic: &EndpointNetworkTraffic,
    threat_info: &crate::models::IpThreatInfo,
) -> NetworkAnomalyEvent {
    // Calculate severity based on confidence score
    let severity = if threat_info.confidence_score >= 90 {
        "CRITICAL"
    } else if threat_info.confidence_score >= 70 {
        "HIGH"
    } else if threat_info.confidence_score >= 50 {
        "MEDIUM"
    } else {
        "LOW"
    };

    // Create event description with additional information
    let categories_str = if threat_info.categories.is_empty() {
        "None".to_string()
    } else {
        threat_info.categories.join(", ")
    };

    // Get additional information from threat_info
    let country_info = match (&threat_info.country_code, &threat_info.country_name) {
        (Some(code), Some(name)) => format!("Country: {} ({})", name, code),
        (Some(code), None) => format!("Country: {}", code),
        (None, Some(name)) => format!("Country: {}", name),
        (None, None) => "Unknown country".to_string(),
    };

    let isp_info = threat_info
        .isp
        .as_ref()
        .map(|isp| format!("ISP: {}", isp))
        .unwrap_or_else(|| "".to_string());

    let domain_info = threat_info
        .domain
        .as_ref()
        .map(|domain| format!("Domain: {}", domain))
        .unwrap_or_else(|| "".to_string());

    let usage_info = threat_info
        .usage_type
        .as_ref()
        .map(|usage| format!("Usage: {}", usage))
        .unwrap_or_else(|| "".to_string());

    let last_reported = threat_info
        .last_reported_at
        .as_ref()
        .map(|date| format!("Last reported: {}", date))
        .unwrap_or_else(|| "No report date available".to_string());

    let mut additional_info = vec![country_info, last_reported];
    if !isp_info.is_empty() {
        additional_info.push(isp_info);
    }
    if !domain_info.is_empty() {
        additional_info.push(domain_info);
    }
    if !usage_info.is_empty() {
        additional_info.push(usage_info);
    }

    let description = format!(
        "Connection to malicious IP {} detected\n\
         Confidence: {}%\n\
         Source: {}\n\
         {}\n\
         Categories: {}",
        threat_info.ip,
        threat_info.confidence_score,
        threat_info.source,
        additional_info.join("\n"),
        categories_str
    );

    // Current time for the event timestamps
    let now = OffsetDateTime::now_utc();

    NetworkAnomalyEvent {
        event_id: 0,
        endpoint_id: traffic.endpoint_id,
        host_ip: traffic.external_ip.clone(),
        bandwidth_usage: traffic.bytes,
        time_window_start: traffic.record_timestamp,
        time_window_end: traffic.record_timestamp,
        alert_description: Some(description),
        acknowledged: false,
        severity_level: Some(severity.to_string()),
        created_at: now,
        updated_at: now,
        resolved: false,
        resolution_description: None,
    }
}

/// Check if an IP address is private or loopback
///
/// # Arguments
///
/// * `ip_str` - A string representing the IP address.
///
/// # Returns   
///
/// A boolean value indicating if the IP address is private or loopback.    
fn is_private_ip(ip_str: &str) -> bool {
    if let Ok(ip) = IpAddr::from_str(ip_str) {
        match ip {
            IpAddr::V4(ipv4) => ipv4.is_private() || ipv4.is_loopback(),
            IpAddr::V6(ipv6) => ipv6.is_loopback(),
        }
    } else {
        true
    }
}
