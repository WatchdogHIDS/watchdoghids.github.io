//! Module for analyzing resource usage data for anomalies
//!
//! This analyzer monitors CPU and memory usage patterns across processes
//! to identify prolonged high resource usage that might indicate problems
//! such as resource leaks, cryptominers, intusions or other abnormal behavior.
//!
//! # Dependencies
//!
//! - `crate::db` for database interactions.
//! - `crate::models` for data models.
//! - `dashmap` for shared cache management.
//! - `sqlx` for database interactions.

use crate::models::*;
use dashmap::DashMap;
use serde_json::json;
use sqlx::MySqlPool;
use std::sync::Arc;
use std::time::Duration;
use time::OffsetDateTime;

// Thresholds
const CPU_USAGE_THRESHOLD: f64 = 80.0; // 80% CPU usage
const MEM_USAGE_THRESHOLD: f64 = 75.0; // 75% memory usage
const MIN_DURATION_SECONDS: u64 = 300; // 5 minutes of continuous high usage

#[derive(Clone)]
#[allow(dead_code)]
pub struct ResourceAnalyzer {
    config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,

    // Tracks resource usage over time to detect prolonged usage
    process_history: Arc<DashMap<String, Vec<ResourceSnapshot>>>,
}

#[derive(Clone, Debug)]
struct ResourceSnapshot {
    timestamp: OffsetDateTime,
    cpu: f64,
    memory: f64,
}

impl ResourceAnalyzer {
    pub fn new(config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>) -> Self {
        Self {
            config_cache,
            process_history: Arc::new(DashMap::new()),
        }
    }

    /// Runs the resource analysis on the recent resource data
    ///
    /// # Arguments
    ///
    /// * `pool` - A reference to the MySQL database connection pool.
    ///
    /// # Returns
    ///
    /// A `Result` indicating success or a database error.
    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        let resource_data = crate::db::get_recent_resource_data(pool, MIN_DURATION_SECONDS).await?;

        if resource_data.is_empty() {
            println!("No resource data available for analysis");
            return Ok(());
        }

        let anomalies = self.analyze(&resource_data);

        for anomaly in anomalies {
            crate::db::insert_resource_anomaly_event(pool, &anomaly).await?;
        }

        Ok(())
    }

    /// Analyzes resource data to identify anomalies
    ///
    /// # Arguments
    ///
    /// * `data` - A slice of `EndpointResourceData` records to analyze.
    ///
    /// # Returns
    ///
    /// A vector of `ResourceInfoAnomalyEvent` records.
    fn analyze(&self, data: &[EndpointResourceData]) -> Vec<ResourceInfoAnomalyEvent> {
        let mut anomalies = Vec::new();
        let now = OffsetDateTime::now_utc();

        // Process current data and update the history
        for record in data {
            if let Some(resource_data) = record.resource_info.get("ResourceData") {
                // Process each PID's data
                if let Some(process_map) = resource_data.as_object() {
                    for (pid, process_info) in process_map {
                        // Parse metrics
                        if let (Some(cpu_str), Some(mem_str), Some(time_str)) = (
                            process_info.get("cpu").and_then(|c| c.as_str()),
                            process_info.get("mem").and_then(|m| m.as_str()),
                            process_info.get("time").and_then(|t| t.as_str()),
                        ) {
                            if let (Ok(cpu), Ok(mem)) =
                                (cpu_str.parse::<f64>(), mem_str.parse::<f64>())
                            {
                                // Create a unique key for the endpoint + process pair
                                let key = format!("{}:{}", record.endpoint_id, pid);

                                // Add to history
                                let snapshot = ResourceSnapshot {
                                    timestamp: record.record_timestamp,
                                    cpu,
                                    memory: mem,
                                };

                                // Update process history
                                self.process_history
                                    .entry(key.clone())
                                    .or_insert_with(Vec::new)
                                    .push(snapshot.clone());

                                // checks for prolonged high resource usage
                                if let Some(anomaly) = self.check_prolonged_usage(
                                    &key,
                                    record.endpoint_id,
                                    pid,
                                    cpu,
                                    mem,
                                    time_str,
                                    now,
                                ) {
                                    anomalies.push(anomaly);
                                }
                            }
                        }
                    }
                }
            }
        }

        // prune old history entries (older than 10 minutes)
        self.prune_history(now - Duration::from_secs(600));

        anomalies
    }

    /// Checks for prolonged high resource usage
    ///
    /// # Arguments
    ///
    /// * `key` - Unique key for the process
    /// * `endpoint_id` - ID of the endpoint
    /// * `pid` - Process ID
    /// * `cpu` - CPU usage percentage
    /// * `mem` - Memory usage percentage
    /// * `time_str` - Time string for the snapshot
    /// * `now` - Current time
    fn check_prolonged_usage(
        &self,
        key: &str,
        endpoint_id: u32,
        pid: &str,
        cpu: f64,
        mem: f64,
        time_str: &str,
        now: OffsetDateTime,
    ) -> Option<ResourceInfoAnomalyEvent> {
        if cpu < CPU_USAGE_THRESHOLD && mem < MEM_USAGE_THRESHOLD {
            return None;
        }

        if let Some(history) = self.process_history.get(key) {
            // Count how long this process has been above thresholds
            let high_usage_duration = history
                .iter()
                .filter(|s| s.cpu >= CPU_USAGE_THRESHOLD || s.memory >= MEM_USAGE_THRESHOLD)
                .count();

            // if usagse has been high and at least 5 consecutive samples
            if high_usage_duration >= 5 {
                let earliest = history
                    .iter()
                    .filter(|s| s.cpu >= CPU_USAGE_THRESHOLD || s.memory >= MEM_USAGE_THRESHOLD)
                    .map(|s| s.timestamp)
                    .min()
                    .unwrap_or(now);

                let resource_info = json!({
                    "pid": pid,
                    "cpu": cpu,
                    "memory": mem,
                    "time": time_str,
                    "duration": high_usage_duration,
                    "history": history.iter()
                        .map(|s| json!({
                            "timestamp": s.timestamp.to_string(),
                            "cpu": s.cpu,
                            "memory": s.memory
                        }))
                        .collect::<Vec<_>>()
                });

                // Determine severity based on thresholds
                let severity = if cpu > 95.0 || mem > 90.0 {
                    "CRITICAL"
                } else if cpu > 85.0 || mem > 80.0 {
                    "HIGH"
                } else if cpu > 80.0 || mem > 75.0 {
                    "MEDIUM"
                } else {
                    "LOW"
                };

                return Some(ResourceInfoAnomalyEvent {
                    endpoint_id,
                    resource_info: resource_info.into(),
                    time_window_start: earliest,
                    time_window_end: now,
                    alert_description: Some(format!(
                        "Process {} has high resource usage: CPU {}%, Memory {}% for an extended period",
                        pid, cpu, mem
                    )),
                    acknowledged: false,
                    severity_level: Some(severity.to_string()),
                    created_at: now,
                    updated_at: now,
                    resolved: false,
                    resolution_description: None,
                });
            }
        }

        None
    }

    /// Removes old entries from process history
    ///
    /// # Arguments
    ///
    /// * `cutoff` - The cutoff time for pruning.   
    fn prune_history(&self, cutoff: OffsetDateTime) {
        for mut entry in self.process_history.iter_mut() {
            entry.retain(|snapshot| snapshot.timestamp > cutoff);
        }

        self.process_history
            .retain(|_, history| !history.is_empty());
    }
}
