//! Module containing analyzer types and implementations.
//!
//! This module provides a unified interface for different types of analyzers
//! that can be used to process data from a MySQL database.
//! //! # Architecture
//!
//! - Uses enum-based polymorphism for different analyzer types
//! - Each analyzer implements its own analysis logic
//! - Common interface through `AnalyzerType::run`

//! Represents different types of analyzers available in the system.
//!
//! Each variant contains a specific analyzer implementation that can be executed
//! using the same interface.
//!

//!
//! To add a new analyzer:
//! 1. Add a new variant to the enum
//! 2. Implement the `Clone` match arm
//! 3. Implement the `run` match arm
//!
//! # Dependencies
//!
//! - `crate::db` for database interactions.
//! - `crate::models` for data models.
//! - `crate::api` for API interactions.
//! - `crate::webhook` for webhook interactions.
//! - `crate::analyzers` for analyzer implementations.
//!

pub mod bandwidth;
pub mod file_integrity;
pub mod procinfo;
pub mod protocol;
pub mod resource;
pub mod suspicious_ip;
pub mod traffic;
pub mod user_login;
use sqlx::MySqlPool;

/// Represents different types of analyzers available in the system.
///
/// Each variant contains a specific analyzer implementation that can be executed
/// using the same interface. This enum serves as the primary way to manage
/// different types of analysis that can be performed on network data.
///
/// # Variants
///
/// * `Traffic` - Analyzes network traffic patterns for anomalies
///
/// # Examples
///
/// ```ignore
/// use analyzers::AnalyzerType;
/// use analyzers::traffic::TrafficAnalyzer;
///
/// let analyzer = AnalyzerType::Traffic(TrafficAnalyzer::new());
/// ```
pub enum AnalyzerType {
    Traffic(traffic::TrafficAnalyzer),
    Protocol(protocol::ProtocolAnalyzer),
    Bandwidth(bandwidth::BandwidthAnalyzer),
    Procinfo(procinfo::ProcinfoAnalyzer),
    SuspiciousIp(suspicious_ip::SuspiciousIpAnalyzer),
    Resource(resource::ResourceAnalyzer),
    UserLogin(user_login::UserLoginAnalyzer),
    FileIntegrity(file_integrity::FileIntegrityAnalyzer),
    // Add new variants here for future analyzers
}

/// Implements cloning functionality for analyzer types
///
/// Enables analyzers to be cloned when needed, particularly useful
/// when spawning multiple analysis tasks.
///
/// # Returns
///
/// A cloned analyzer type.
impl Clone for AnalyzerType {
    fn clone(&self) -> Self {
        match self {
            Self::Traffic(a) => Self::Traffic(a.clone()),
            Self::Protocol(a) => Self::Protocol(a.clone()),
            Self::Bandwidth(a) => Self::Bandwidth(a.clone()),
            Self::Procinfo(a) => Self::Procinfo(a.clone()),
            Self::SuspiciousIp(a) => Self::SuspiciousIp(a.clone()),
            Self::Resource(a) => Self::Resource(a.clone()),
            Self::UserLogin(a) => Self::UserLogin(a.clone()),
            Self::FileIntegrity(a) => Self::FileIntegrity(a.clone()),
            // Add new variants here for future analyzers
            // example: Self::NewAnalyzer(a) => Self::NewAnalyzer(a.clone()),
        }
    }
}

/// Provides the main interface for executing analyzers
///
/// # Arguments
///
/// * `pool` - The database pool.
///
/// # Returns
///
impl AnalyzerType {
    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        match self {
            Self::Traffic(analyzer) => analyzer.run(pool).await,
            Self::Protocol(analyzer) => analyzer.run(pool).await,
            Self::Bandwidth(analyzer) => analyzer.run(pool).await,
            Self::Procinfo(analyzer) => analyzer.run(pool).await,
            Self::SuspiciousIp(analyzer) => analyzer.run(pool).await,
            Self::Resource(analyzer) => analyzer.run(pool).await,
            Self::UserLogin(analyzer) => analyzer.run(pool).await,
            Self::FileIntegrity(analyzer) => analyzer.run(pool).await,
            // Add new variants here for future analyzers
            // example: Self::NewAnalyzer(analyzer) => analyzer.run(pool).await,
        }
    }
}
