//! User Login Analysis Module
//!
//! Provides functionality to analyze user login patterns and detect anomalies
//! by examining login data, user information, and group memberships.
//!
//! # Features
//!
//! - Login pattern analysis
//! - Suspicious login detection
//! - User and group context awareness
//! - Configurable thresholds and time windows
//! - Severity classification
//!
//! # Dependencies
//!
//! - `crate::db` for database interactions.
//! - `crate::models` for data models.
//! - `dashmap` for shared cache management.
//! - `sqlx` for database interactions.
//! - `std::sync::Arc` for shared references.

use crate::db;
use crate::models::*;
use dashmap::DashMap;
use serde_json::Value;
use sqlx::MySqlPool;
use std::collections::HashMap;
use std::sync::Arc;
use time::OffsetDateTime;

/// Time window in seconds for login analysis
const ANALYSIS_INTERVAL_SECS: u64 = 60;

/// Threshold for suspicious login attempts
const SUSPICIOUS_LOGIN_THRESHOLD: u32 = 3;

/// Threshold for unusual login hours
const UNUSUAL_HOUR_START: u32 = 0; // 12 AM
const UNUSUAL_HOUR_END: u32 = 5; // 5 AM

/// Threshold for maximum login duration in hours
const MAX_NORMAL_LOGIN_DURATION: u64 = 12; // 12 hours

/// Known internal IP ranges
const INTERNAL_IP_PREFIXES: [&str; 3] = ["10.", "192.168.", "172.16."];

/// Time in seconds before a similar anomaly can be reported again
const ANOMALY_REPORT_COOLDOWN_SECS: i64 = 3600; // 1 hour

/// Represents a user login analyzer
#[derive(Clone)]
#[allow(dead_code)]
pub struct UserLoginAnalyzer {
    config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
    // Cache to track recently reported anomalies to prevent duplicates
    reported_anomalies: Arc<DashMap<String, OffsetDateTime>>,
}

impl UserLoginAnalyzer {
    /// Creates a new instance of UserLoginAnalyzer
    ///
    /// # Arguments
    ///
    /// * `config_cache` - A shared cache of user anomaly configurations.
    ///
    /// # Returns
    ///
    /// A new UserLoginAnalyzer instance
    pub fn new(config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>) -> Self {
        Self {
            config_cache,
            reported_anomalies: Arc::new(DashMap::new()),
        }
    }

    /// Executes the user login analysis process
    ///
    /// # Arguments
    ///
    /// * `pool` - Database connection pool
    ///
    /// # Returns
    ///
    /// Result indicating success or database error
    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        // Retrieve login data from the database
        let login_data = db::get_recent_user_logins(pool, ANALYSIS_INTERVAL_SECS).await?;

        // Process the data to detect anomalies
        let events = self.analyze(&login_data).await;

        // Store detected anomalies
        for event in events {
            db::insert_user_login_anomaly_event(pool, &event).await?;
        }

        Ok(())
    }

    /// Analyzes login data to detect anomalies
    ///
    /// # Arguments
    ///
    /// * `data` - Login data from the database
    ///
    /// # Returns
    ///
    /// Vector of UserLoginAnomalyEvent for detected anomalies
    async fn analyze(&self, data: &[Value]) -> Vec<UserLoginAnomalyEvent> {
        let mut anomalies = Vec::new();
        let now = OffsetDateTime::now_utc();

        // Track login patterns per user for frequency analysis
        let mut user_login_counts: HashMap<u32, u32> = HashMap::new();
        let mut user_ip_map: HashMap<u32, Vec<String>> = HashMap::new();

        // collect statistics about login patterns
        for record in data {
            if let Some(login_data) = record.get("LoginData") {
                for (_timestamp, login) in login_data.as_object().unwrap() {
                    let uid = login.get("uid").and_then(|v| v.as_u64()).unwrap_or(0) as u32;
                    let ip_str = login
                        .get("ip")
                        .and_then(|v| v.as_str())
                        .unwrap_or("0.0.0.0");

                    // Count logins per user
                    *user_login_counts.entry(uid).or_insert(0) += 1;

                    // Track IPs used by each user
                    user_ip_map
                        .entry(uid)
                        .or_insert_with(Vec::new)
                        .push(ip_str.to_string());
                }
            }
        }

        // analyze for suspicious patterns
        for record in data {
            if let Some(login_data) = record.get("LoginData") {
                for (timestamp, login) in login_data.as_object().unwrap() {
                    let uid = login.get("uid").and_then(|v| v.as_u64()).unwrap_or(0) as u32;
                    let ip_str = login
                        .get("ip")
                        .and_then(|v| v.as_str())
                        .unwrap_or("0.0.0.0");

                    // Parse login and logout times
                    let date_start = login
                        .get("date_start")
                        .and_then(|v| v.as_str())
                        .unwrap_or("");
                    let time_start = login
                        .get("time_start")
                        .and_then(|v| v.as_str())
                        .unwrap_or("");
                    let date_end = login.get("date_end").and_then(|v| v.as_str()).unwrap_or("");
                    let time_end = login.get("time_end").and_then(|v| v.as_str()).unwrap_or("");

                    // Get username from UserData if available
                    let username = self.get_username_for_uid(record, uid);

                    // Get users group memberships
                    let groups = self.get_user_groups(record, uid);

                    // Check if this login is suspicious
                    let (is_suspicious, reason) = self.is_suspicious_login(
                        uid,
                        ip_str,
                        &username,
                        &groups,
                        timestamp,
                        date_start,
                        time_start,
                        date_end,
                        time_end,
                        &user_login_counts,
                        &user_ip_map,
                    );

                    if is_suspicious {
                        // Check if this is a duplicate anomaly
                        if !self.is_duplicate_anomaly(uid, ip_str, &reason) {
                            // Create anomaly event
                            let anomaly = UserLoginAnomalyEvent {
                                endpoint_id: record
                                    .get("EndpointId")
                                    .and_then(|v| v.as_u64())
                                    .unwrap_or(0)
                                    as u32,
                                username: username.clone(),
                                ip: ip_str
                                    .parse()
                                    .unwrap_or_else(|_| "0.0.0.0".parse().unwrap()),
                                login_time: now,
                                logout_time: Some(now),
                                alert_description: Some(reason),
                                acknowledged: false,
                                severity_level: Some(
                                    self.determine_severity(uid, ip_str, &username, &groups),
                                ),
                                created_at: now,
                                updated_at: now,
                                resolved: false,
                                resolution_description: None,
                            };

                            anomalies.push(anomaly);
                        }
                    }
                }
            }
        }

        anomalies
    }

    /// Extracts username for a given UID from the user data
    ///
    /// # Arguments
    ///
    /// * `record` - JSON record containing user data
    /// * `uid` - User ID to look up
    ///
    /// # Returns
    ///
    /// Username as a string
    fn get_username_for_uid(&self, record: &Value, uid: u32) -> String {
        if let Some(user_data) = record.get("UserData") {
            if let Some(user) = user_data.get(&uid.to_string()) {
                if let Some(name) = user.get("name").and_then(|v| v.as_str()) {
                    return name.to_string();
                }
            }
        }

        format!("Unknown (UID: {})", uid)
    }

    /// Gets the groups a user belongs to
    ///
    /// # Arguments
    ///
    /// * `record` - JSON record containing group data
    /// * `uid` - User ID to look up
    ///
    /// # Returns
    ///
    /// Vector of group names the user belongs to
    fn get_user_groups(&self, record: &Value, uid: u32) -> Vec<String> {
        let mut groups = Vec::new();

        if let Some(group_data) = record.get("GroupData") {
            for (_group_id, group) in group_data.as_object().unwrap() {
                if let Some(members) = group.get("members").and_then(|v| v.as_array()) {
                    if members
                        .iter()
                        .any(|m| m.as_u64().map_or(false, |id| id as u32 == uid))
                    {
                        if let Some(name) = group.get("name").and_then(|v| v.as_str()) {
                            groups.push(name.to_string());
                        }
                    }
                }
            }
        }

        groups
    }

    /// Checks if a login is suspicious based on various factors
    ///
    /// # Arguments
    ///
    /// * `uid` - User ID
    /// * `ip` - IP address as string
    /// * `username` - Username
    /// * `groups` - Groups the user belongs to
    /// * `timestamp` - Login timestamp
    /// * `date_start` - Login date
    /// * `time_start` - Login time
    /// * `date_end` - Logout date
    /// * `time_end` - Logout time
    /// * `user_login_counts` - Map of login counts per user
    /// * `user_ip_map` - Map of IPs used by each user
    ///
    /// # Returns
    ///
    /// Tuple of (is_suspicious, reason)
    fn is_suspicious_login(
        &self,
        uid: u32,
        ip: &str,
        username: &str,
        groups: &[String],
        _timestamp: &str,
        date_start: &str,
        time_start: &str,
        date_end: &str,
        time_end: &str,
        user_login_counts: &HashMap<u32, u32>,
        user_ip_map: &HashMap<u32, Vec<String>>,
    ) -> (bool, String) {
        // Check for root or system user logins
        if uid == 0 {
            // Check if the root login is from an internal IP
            let is_internal_ip = INTERNAL_IP_PREFIXES
                .iter()
                .any(|prefix| ip.starts_with(prefix))
                || ip == "127.0.0.1";

            if !is_internal_ip {
                return (true, format!("Root login from external IP: {}", ip));
            }

            return (false, "".to_string());
        }

        if uid < 1000 && uid > 0 {
            return (
                true,
                format!(
                    "System user login detected: {} (UID: {}) from IP {}",
                    username, uid, ip
                ),
            );
        }

        // Check for logins from external IPs
        let is_external_ip = !INTERNAL_IP_PREFIXES
            .iter()
            .any(|prefix| ip.starts_with(prefix));
        if is_external_ip && ip != "0.0.0.0" && ip != "127.0.0.1" {
            return (true, format!("Login from external IP address: {}", ip));
        }

        // Check for logins at unusual hours
        if let Some(hour) = self.extract_hour_from_time(time_start) {
            if hour >= UNUSUAL_HOUR_START && hour <= UNUSUAL_HOUR_END {
                return (true, format!("Login at unusual hour: {}:00", hour));
            }
        }

        // Check for unusually long login sessions
        let login_duration =
            self.calculate_login_duration(date_start, time_start, date_end, time_end);
        if login_duration > MAX_NORMAL_LOGIN_DURATION {
            return (
                true,
                format!("Unusually long login session: {} hours", login_duration),
            );
        }

        // Check for multiple IPs used by the same user
        if let Some(ips) = user_ip_map.get(&uid) {
            if ips.len() > 1 {
                let unique_ips = ips.join(", ");
                return (
                    true,
                    format!("User logged in from multiple IPs: {}", unique_ips),
                );
            }
        }

        // Check for admin group users logging in from unusual locations
        let is_admin = groups
            .iter()
            .any(|g| g == "sudo" || g == "admin" || g == "wheel");
        if is_admin && is_external_ip {
            return (
                true,
                format!("Admin user logged in from external IP: {}", ip),
            );
        }

        // Check for excessive login frequency
        if let Some(count) = user_login_counts.get(&uid) {
            if *count > SUSPICIOUS_LOGIN_THRESHOLD {
                return (
                    true,
                    format!("Excessive login frequency: {} logins detected", count),
                );
            }
        }

        (false, String::new())
    }

    /// Determines severity level based on various factors
    ///
    /// # Arguments
    ///
    /// * `uid` - User ID
    /// * `ip` - IP address
    /// * `username` - Username
    /// * `groups` - Groups the user belongs to
    ///
    /// # Returns
    ///
    /// String indicating severity: "HIGH", "MEDIUM", or "LOW"
    fn determine_severity(&self, uid: u32, ip: &str, _username: &str, groups: &[String]) -> String {
        // Root user logins
        if uid == 0 {
            return "CRITICAL".to_string();
        }

        // Admin users logging in from external IPs are high severity
        let is_admin = groups
            .iter()
            .any(|g| g == "sudo" || g == "admin" || g == "wheel");
        let is_external_ip = !INTERNAL_IP_PREFIXES
            .iter()
            .any(|prefix| ip.starts_with(prefix));

        if is_admin && is_external_ip {
            return "HIGH".to_string();
        }

        // System users are medium to high severity depending on context
        if uid < 1000 {
            if is_external_ip {
                return "HIGH".to_string();
            } else {
                return "MEDIUM".to_string();
            }
        }

        // Regular users from external IPs are medium severity
        if is_external_ip {
            return "MEDIUM".to_string();
        }

        "LOW".to_string()
    }
    /// Parses a date and time string into an OffsetDateTime
    ///
    /// # Arguments
    ///
    /// * `date` - Date string in format "YYYY-MM-DD"
    /// * `time` - Time string in format "HH:MM:SS-ZZ:ZZ"
    ///
    /// # Returns
    ///
    /// OffsetDateTime representing the parsed date and time
    fn parse_datetime(&self, _date: &str, _time: &str) -> OffsetDateTime {
        OffsetDateTime::now_utc()
    }

    /// Extracts the hour from a time string
    ///
    /// # Arguments
    ///
    /// * `time` - Time string in format "HH:MM:SS-ZZ:ZZ"
    ///
    /// # Returns
    ///
    /// Option containing the hour as u32
    fn extract_hour_from_time(&self, time: &str) -> Option<u32> {
        if time.is_empty() {
            return None;
        }

        // Split by colon and parse the first part as hour
        let parts: Vec<&str> = time.split(':').collect();
        if parts.is_empty() {
            return None;
        }

        parts[0].parse::<u32>().ok()
    }

    /// Calculates login duration in hours
    ///
    /// # Arguments
    ///
    /// * `date_start` - Login date
    /// * `time_start` - Login time
    /// * `date_end` - Logout date
    /// * `time_end` - Logout time
    ///
    /// # Returns
    ///
    /// Login duration in hours
    fn calculate_login_duration(
        &self,
        _date_start: &str,
        _time_start: &str,
        _date_end: &str,
        _time_end: &str,
    ) -> u64 {
        // Parse start and end datetimes
        let start = self.parse_datetime(_date_start, _time_start);
        let end = self.parse_datetime(_date_end, _time_end);

        // Calculate duration in hours
        let duration = end - start;
        duration.whole_hours() as u64
    }

    /// Checks if a similar anomaly has been reported recently
    ///
    /// # Arguments
    ///
    /// * `uid` - User ID
    /// * `ip` - IP address
    /// * `reason` - Reason for the anomaly
    ///
    /// # Returns
    ///
    /// Boolean indicating if this is a duplicate anomaly
    fn is_duplicate_anomaly(&self, uid: u32, ip: &str, reason: &str) -> bool {
        // Create a unique key for this anomaly
        let key = format!("{}-{}-{}", uid, ip, reason);

        // Check if this anomaly has been reported recently
        if let Some(last_reported) = self.reported_anomalies.get(&key) {
            let now = OffsetDateTime::now_utc();
            let elapsed = now - *last_reported;

            // If the anomaly was reported recently, consider it a duplicate
            if elapsed.whole_seconds() < ANOMALY_REPORT_COOLDOWN_SECS {
                return true;
            }
        }

        // Not a duplicate, update the cache with current time
        self.reported_anomalies
            .insert(key, OffsetDateTime::now_utc());
        false
    }
}
