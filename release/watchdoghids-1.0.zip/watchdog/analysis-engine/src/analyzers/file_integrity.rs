//! Module for analyzing file integrity data for anomalies
//!
//! This analyzer monitors file changes across endpoints to identify suspicious
//! file modifications, creations, or deletions that might indicate security issues
//! such as malware, unauthorized access, or data tampering.
//!
//! # Dependencies
//!
//! - `crate::db` for database interactions.
//! - `crate::models` for data models.
//! - `dashmap` for shared cache management.
//! - `sqlx` for database interactions.

use crate::models::*;
use dashmap::DashMap;
use serde_json::json;
use sqlx::MySqlPool;
use std::sync::Arc;
use time::OffsetDateTime;

// Time window in seconds for file integrity analysis
const LOOKBACK_WINDOW_SECS: u64 = 30;

#[allow(dead_code)]
#[derive(Clone)]
pub struct FileIntegrityAnalyzer {
    config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,

    // Track previously seen files to detect changes
    previous_files: Arc<DashMap<String, FileState>>,
}

#[allow(dead_code)]
#[derive(Clone, Debug)]
struct FileState {
    path: String,
    endpoint_id: u32,
    last_seen: OffsetDateTime,
    last_action: String,
}

impl FileIntegrityAnalyzer {
    /// Creates a new `FileIntegrityAnalyzer` instance.
    ///
    /// # Arguments
    ///
    /// * `config_cache` - A shared cache of user anomaly configurations.
    ///
    /// # Returns
    ///
    /// A new instance of `FileIntegrityAnalyzer`.
    pub fn new(config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>) -> Self {
        Self {
            config_cache,
            previous_files: Arc::new(DashMap::new()),
        }
    }

    /// Runs the file integrity analysis on the recent file data
    ///
    /// # Arguments
    ///
    /// * `pool` - A reference to the MySQL database connection pool.
    ///
    /// # Returns
    ///
    /// A `Result` indicating success or a database error.
    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        let file_data = crate::db::get_recent_file_info(pool, LOOKBACK_WINDOW_SECS).await?;

        if file_data.is_empty() {
            return Ok(());
        }

        let anomalies = self.analyze(&file_data);

        for anomaly in anomalies {
            crate::db::insert_file_info_anomaly_event(pool, &anomaly).await?;
        }

        Ok(())
    }

    /// Analyzes file integrity data to identify anomalies
    ///
    /// # Arguments
    ///
    /// * `data` - A slice of `EndpointFileInfo` records to analyze.
    ///
    /// # Returns
    ///
    /// A vector of `FileInfoAnomalyEvent` records.
    fn analyze(&self, data: &[EndpointFileInfo]) -> Vec<FileInfoAnomalyEvent> {
        let mut anomalies = Vec::new();
        let now = OffsetDateTime::now_utc();

        // Process current data and update the history
        for record in data {
            if let Some(file_data) = record.file_info.get("FileData") {
                if let Some(file_map) = file_data.as_object() {
                    for (file_path, file_info) in file_map {
                        if let Some(file_info_obj) = file_info.as_object() {
                            // Extract the  file action type
                            let action_type = file_info_obj
                                .get("type")
                                .and_then(|v| v.as_str())
                                .unwrap_or("unknown");

                            // Extract time information
                            let time = file_info_obj
                                .get("time")
                                .and_then(|v| v.as_str())
                                .unwrap_or("00:00:00");
                            let date = file_info_obj
                                .get("date")
                                .and_then(|v| v.as_str())
                                .unwrap_or("1970-01-01");

                            // unique key for this file on this endpoint
                            let key = format!("{}:{}", record.endpoint_id, file_path);

                            // Check for suspicious file activity
                            if let Some(anomaly) = self.check_file_activity(
                                &key,
                                record.endpoint_id,
                                file_path,
                                action_type,
                                time,
                                date,
                                record.record_timestamp,
                                now,
                            ) {
                                anomalies.push(anomaly);
                            }

                            // Update tracking of this file
                            self.previous_files.insert(
                                key,
                                FileState {
                                    path: file_path.clone(),
                                    endpoint_id: record.endpoint_id,
                                    last_seen: record.record_timestamp,
                                    last_action: action_type.to_string(),
                                },
                            );
                        }
                    }
                }
            }
        }

        self.prune_old_entries(now);

        anomalies
    }

    /// Checks for suspicious file activity
    ///
    /// # Arguments
    ///
    /// * `key` - Unique key for the file
    /// * `endpoint_id` - ID of the endpoint
    /// * `file_path` - Path of the file
    /// * `action_type` - Type of action (create, mod, delete)
    /// * `time` - Time of the action
    /// * `date` - Date of the action
    /// * `timestamp` - Timestamp of the record
    /// * `now` - Current time
    fn check_file_activity(
        &self,
        key: &str,
        endpoint_id: u32,
        file_path: &str,
        action_type: &str,
        time: &str,
        date: &str,
        timestamp: OffsetDateTime,
        now: OffsetDateTime,
    ) -> Option<FileInfoAnomalyEvent> {
        let mut suspicious = false;
        let mut reason = String::new();

        // Check for sensitive file paths
        let (is_sensitive_path, _) = self.is_sensitive_path(file_path);
        if is_sensitive_path {
            suspicious = true;
            reason = format!("Modification to sensitive file: {}", file_path);
        }

        // rapid file changes
        if let Some(previous) = self.previous_files.get(key) {
            // If the same file was modified multiple times in a short period
            if action_type == "mod" && previous.last_action == "mod" {
                let time_diff = timestamp - previous.last_seen;

                // If modified twice within 5 seconds, consider suspicious
                if time_diff.whole_seconds() < 5 {
                    suspicious = true;
                    reason = format!("Rapid modifications to file: {}", file_path);
                }
            }

            // If a file was deleted and then created again quickly
            if action_type == "create" && previous.last_action == "delete" {
                let time_diff = timestamp - previous.last_seen;

                // If recreated within 10 seconds of deletion
                if time_diff.whole_seconds() < 10 {
                    suspicious = true;
                    reason = format!("File deleted and quickly recreated: {}", file_path);
                }
            }
        }

        // create an anomaly event
        if suspicious {
            let (_, severity) = self.is_sensitive_path(file_path);
            let file_info = json!({
                "path": file_path,
                "action": action_type,
                "time": time,
                "date": date,
                "detection_reason": reason
            });

            return Some(FileInfoAnomalyEvent {
                endpoint_id,
                file_info: file_info.into(),
                time_window_start: timestamp,
                time_window_end: now,
                alert_description: Some(reason),
                acknowledged: false,
                severity_level: Some(severity.to_string()),
                created_at: now,
                updated_at: now,
                resolved: false,
                resolution_description: None,
            });
        }

        None
    }

    /// Determines if a file path is sensitive
    ///
    /// # Arguments
    ///
    /// * `path` - File path to check
    ///
    /// # Returns
    ///
    /// Boolean indicating if the path is sensitive
    fn is_sensitive_path(&self, path: &str) -> (bool, &str) {
        // List of critical file patterns
        let critical_patterns = [
            // System configuration
            "/etc/passwd",
            "/etc/shadow",
            "/etc/sudoers",
            "/etc/ssh/",
            "/etc/security/",
            // Boot and kernel files
            "/boot/",
            "/lib/modules/",
            // System binaries
            "/bin/",
            "/sbin/",
            "/usr/bin/",
            "/usr/sbin/",
        ];

        let high_patterns = [
            // Credential files
            ".key", ".pem", ".crt", ".cer", ".p12", ".pfx", ".ssh/",
        ];

        let medium_patterns = [
            // Configuration files
            ".conf",
            ".config",
            ".ini",
            // Startup files
            "/etc/init.d/",
            "/etc/systemd/",
            // Cloud configuration
            ".aws/",
            ".azure/",
            ".kube/",
            // Script files in unusual locations
            "/tmp/",
            "/var/tmp/",
            // Executable files in unusual locations
            ".so",
            ".sh",
        ];

        if critical_patterns
            .iter()
            .any(|pattern| path.contains(pattern))
        {
            return (true, "CRITICAL");
        }

        if high_patterns.iter().any(|pattern| path.contains(pattern)) {
            return (true, "HIGH");
        }

        if medium_patterns.iter().any(|pattern| path.contains(pattern)) {
            return (true, "MEDIUM");
        }

        (false, "LOW")
    }

    /// Removes old entries from the file tracking map
    ///
    /// # Arguments
    ///
    /// * `now` - Current time
    fn prune_old_entries(&self, now: OffsetDateTime) {
        let keys_to_remove: Vec<String> = self
            .previous_files
            .iter()
            .filter_map(|entry| {
                let time_diff = now - entry.last_seen;
                if time_diff.whole_hours() > 24 {
                    Some(entry.key().clone())
                } else {
                    None
                }
            })
            .collect();

        for key in keys_to_remove {
            self.previous_files.remove(&key);
        }
    }
}
