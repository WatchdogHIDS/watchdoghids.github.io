//! Network Traffic Analysis Module
//!
//! Provides functionality to analyze network traffic patterns and detect anomalies
//! by comparing current and historical traffic data.
//!
//! # Features
//!
//! - Traffic aggregation by endpoint and IP
//! - Anomaly detection based on traffic changes
//! - Configurable thresholds and time windows
//! - Severity classification
//!
//! # Dependencies
//!
//! - `crate::db` for database interactions.
//! - `crate::models` for data models.
//! - `dashmap` for shared cache management.
//! - `sqlx` for database interactions.
//! - `std::collections::HashMap` for hash map.
//! - `std::sync::Arc` for shared references.

use crate::db;
use crate::models::UserAnomalyConfig;
use crate::models::{EndpointNetworkTraffic, NetworkAnomalyEvent};
use dashmap::DashMap;
use sqlx::MySqlPool;
use std::collections::HashMap;
use std::sync::Arc;
use time::OffsetDateTime;

/// Threshold percentage for determining traffic anomalies
const ANOMALY_THRESHOLD: f64 = 100.0;

/// Time window in seconds for traffic spike analysis
const ANALYSIS_INTERVAL_SECS: u64 = 300;

/// Aggregated traffic data for a specific endpoint and external IP combination
#[derive(Debug)]
struct TrafficAggregate {
    endpoint_id: u64,
    external_ip: String,
    bytes: u64,
    window_start: OffsetDateTime,
    window_end: OffsetDateTime,
}

#[derive(Clone)]
#[allow(dead_code)]
pub struct TrafficAnalyzer {
    config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
}

impl TrafficAnalyzer {
    /// Creates a new instance of TrafficAnalyzer
    ///
    /// # Returns
    ///
    /// A new TrafficAnalyzer instance
    pub fn new(config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>) -> Self {
        Self { config_cache }
    }

    /// Executes the traffic analysis process
    ///
    /// # Arguments
    ///
    /// * `pool` - Database connection pool
    ///
    /// # Returns
    ///
    /// Result indicating success or database error
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let analyzer = TrafficAnalyzer::new();
    /// analyzer.run(&pool).await?;
    /// ```
    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        // Use db functions for data retrieval
        let current_data = db::get_recent_traffic(pool, ANALYSIS_INTERVAL_SECS as u64).await?;
        let previous_data = db::get_previous_traffic(
            pool,
            ANALYSIS_INTERVAL_SECS as u64,
            ANALYSIS_INTERVAL_SECS as u64,
        )
        .await?;

        let events = self.analyze(&current_data, &previous_data).await;

        // Store events using db function
        for event in events {
            db::insert_network_anomaly_event_with_alert(pool, &event).await?;
        }

        Ok(())
    }

    /// Aggregates network traffic records by endpoint and external IP
    ///
    /// # Arguments
    ///
    /// * `records` - Slice of network traffic records to aggregate
    ///
    /// # Returns
    ///
    /// HashMap where:
    /// - Key: Tuple of (endpoint_id, external_ip)
    /// - Value: Aggregated traffic data
    fn aggregate_traffic(
        &self,
        records: &[EndpointNetworkTraffic],
    ) -> HashMap<(u64, String), TrafficAggregate> {
        let mut aggregates: HashMap<(u64, String), TrafficAggregate> = HashMap::new();

        for record in records {
            let key = (record.endpoint_id as u64, record.external_ip.clone());
            let entry = aggregates.entry(key).or_insert_with(|| TrafficAggregate {
                endpoint_id: record.endpoint_id as u64,
                external_ip: record.external_ip.clone(),
                bytes: 0,
                window_start: OffsetDateTime::from(record.record_timestamp),
                window_end: OffsetDateTime::from(record.record_timestamp),
            });

            entry.bytes += record.bytes;
            entry.window_start =
                OffsetDateTime::from(record.record_timestamp).min(entry.window_start);
            entry.window_end = OffsetDateTime::from(record.record_timestamp).max(entry.window_end);
        }

        aggregates
    }

    /// Analyzes traffic data to detect anomalies
    ///
    /// # Arguments
    ///
    /// * `current_data` - Current period traffic records
    /// * `previous_data` - Previous period traffic records for comparison
    ///
    /// # Returns
    ///
    /// Vector of NetworkAnomalyEvent for detected anomalies
    pub async fn analyze(
        &self,
        current_data: &[EndpointNetworkTraffic],
        previous_data: &[EndpointNetworkTraffic],
    ) -> Vec<NetworkAnomalyEvent> {
        let mut events = Vec::new();

        let current_aggregates = self.aggregate_traffic(current_data);
        let previous_aggregates = self.aggregate_traffic(previous_data);

        for (key, current) in current_aggregates {
            if let Some(previous) = previous_aggregates.get(&key) {
                let bytes_change = percentage_change(previous.bytes as f64, current.bytes as f64);

                if bytes_change > ANOMALY_THRESHOLD {
                    events.push(NetworkAnomalyEvent {
                        event_id: 0,
                        endpoint_id: current.endpoint_id as u32,
                        host_ip: current.external_ip,
                        bandwidth_usage: current.bytes,
                        time_window_start: current.window_end,
                        time_window_end: current.window_end,
                        alert_description: Some(format!(
                            "Traffic anomaly detected: Traffic changed by {:.1}%",
                            bytes_change
                        )),
                        acknowledged: false,
                        severity_level: Some(determine_severity(bytes_change)),
                        created_at: OffsetDateTime::now_utc(),
                        updated_at: OffsetDateTime::now_utc(),
                        resolved: false,
                        resolution_description: None,
                    });
                }
            }
        }

        events
    }
}

/// Calculates percentage change between two values
///
/// # Arguments
///
/// * `previous` - Previous value
/// * `current` - Current value
///
/// # Returns
///
/// Percentage change as float (positive for increase, negative for decrease)
fn percentage_change(previous: f64, current: f64) -> f64 {
    ((current - previous) / previous) * 100.0
}

/// Determines severity level based on change magnitude
///
/// # Arguments
///
/// * `change` - Percentage change value
///
/// # Returns
///
/// String indicating severity: "HIGH" (>80%), "MEDIUM" (>60%), or "LOW"
///
/// # Notes
///
/// Will be configurable in the future
fn determine_severity(change: f64) -> String {
    match change.abs() {
        c if c > 1000.0 => "CRITICAL",
        c if c > 500.0 => "HIGH",
        c if c > 200.0 => "MEDIUM",
        _ => "LOW",
    }
    .to_string()
}
