//! Protocol Analysis Module
//!
//! Provides functionality to detect and analyze deprecated or suspicious protocols
//! being used in network communications.
//!
//! # Features
//!
//! - Detection of known deprecated protocols
//! - Severity classification based on protocol risk
//! - Configurable protocol blacklist
//! - Automatic event generation for suspicious protocols
//!
//! # Dependencies
//!
//! - `crate::db` for database interactions.
//! - `crate::models` for data models.
//! - `dashmap` for shared cache management.
//! - `sqlx` for database interactions.
//! - `std::collections::HashSet` for hash set.
//! - `std::sync::Arc` for shared references.

use crate::db;
use crate::models::UserAnomalyConfig;
use crate::models::{EndpointNetworkTraffic, NetworkAnomalyEvent};
use dashmap::DashMap;
use sqlx::MySqlPool;
use std::collections::HashSet;
use std::sync::Arc;
use time::OffsetDateTime;

// Time window in seconds for protocol analysis
const ANALYSIS_INTERVAL_SECS: u64 = 30;

/// List of protocols considered suspicious or deprecated
///
/// Each protocol in this list will trigger an anomaly event when detected.
/// Severity levels are determined by protocol type:
/// - HIGH: telnet, rsh, sslv2, sslv3
/// - MEDIUM: ftp, snmpv2c, tlsv1.0, tlsv1.1
/// - LOW: all others
const SUSPICIOUS_PROTOCOLS: &[&str] = &[
    "telnet", "ftp", "rsh", "tftp", "http", "pop3", "imap", "smbv1", "snmpv1", "snmpv2c", "rdp",
    "irc", "nfsv2", "ldap", "x11", "netbios", "sslv2", "sslv3", "tlsv1.0", "tlsv1.1",
];

/// Analyzer for detecting deprecated and suspicious protocols
///
/// Monitors network traffic for protocols that are considered insecure
/// or deprecated by modern security standards
#[derive(Clone)]
#[allow(dead_code)]
pub struct ProtocolAnalyzer {
    config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
}

impl ProtocolAnalyzer {
    /// Creates a new instance of ProtocolAnalyzer
    ///
    /// # Returns
    ///
    /// A new ProtocolAnalyzer instance
    pub fn new(config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>) -> Self {
        Self { config_cache }
    }

    /// Executes the protocol analysis process
    ///
    /// # Arguments
    ///
    /// * `pool` - Database connection pool
    ///
    /// # Returns
    ///
    /// Result indicating success or database error
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let analyzer = ProtocolAnalyzer::new();
    /// analyzer.run(&pool).await?;
    /// ```
    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        let protocol_data = db::get_recent_protocols(pool, ANALYSIS_INTERVAL_SECS as u64).await?;

        let events = self.analyze(&protocol_data).await;

        for event in events {
            db::insert_network_anomaly_event_with_alert(pool, &event).await?;
        }

        Ok(())
    }

    /// Analyzes protocol data to detect suspicious protocols
    ///
    /// # Arguments
    ///
    /// * `protocol_data` - Network traffic records to analyze
    ///
    /// # Returns
    ///
    /// Vector of NetworkAnomalyEvent for detected suspicious protocols
    pub async fn analyze(
        &self,
        protocol_data: &[EndpointNetworkTraffic],
    ) -> Vec<NetworkAnomalyEvent> {
        let mut events = Vec::new();
        let suspicious: HashSet<_> = SUSPICIOUS_PROTOCOLS
            .iter()
            .map(|&s| s.to_string())
            .collect();

        for record in protocol_data {
            if suspicious.contains(&record.protocol.to_lowercase()) {
                events.push(NetworkAnomalyEvent {
                    event_id: 0,
                    endpoint_id: record.endpoint_id,
                    host_ip: record.external_ip.clone(),
                    bandwidth_usage: record.bytes,
                    time_window_start: record.record_timestamp,
                    time_window_end: record.record_timestamp,
                    alert_description: Some(format!(
                        "Deprecated/suspicious protocol detected: {}",
                        record.protocol
                    )),
                    acknowledged: false,
                    severity_level: Some(self.determine_protocol_severity(&record.protocol)),
                    created_at: OffsetDateTime::now_utc(),
                    updated_at: OffsetDateTime::now_utc(),
                    resolved: false,
                    resolution_description: None,
                });
            }
        }
        events
    }

    /// Determines severity level based on protocol type
    ///
    /// # Arguments
    ///
    /// * `protocol` - Protocol name to evaluate
    ///
    /// # Returns
    ///
    /// String indicating severity: "HIGH", "MEDIUM", or "LOW"
    fn determine_protocol_severity(&self, protocol: &str) -> String {
        match protocol.to_lowercase().as_str() {
            "telnet" | "rsh" | "sslv2" | "sslv3" | "rdp" => "CRITICAL",
            "ftp" | "snmpv2c" | "tlsv1.0" | "tlsv1.1" => "MEDIUM",
            _ => "LOW",
        }
        .to_string()
    }
}
