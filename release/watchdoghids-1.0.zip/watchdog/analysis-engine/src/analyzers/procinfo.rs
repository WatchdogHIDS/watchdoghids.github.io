//! This module contains the `ProcinfoAnalyzer` type which is responsible for analyzing process information data.
//!
//! The `ProcinfoAnalyzer` type provides a method `run` that fetches recent process information data from the database,
//! analyzes it for anomalies, and stores any detected anomalies in the database.
//!
//! # Dependencies
//!
//! - `sqlx` for database interactions.
//! - `time` for timestamp manipulation.
//! - `dashmap` for shared cache management.
//! - `serde` for JSON serialization.
//! - `tokio` for async runtime.
//! - `crate::models` for data models.
use crate::models::*;
use dashmap::DashMap;
use sqlx::MySqlPool;
use std::sync::Arc;
use time::OffsetDateTime;

const THREAD_THREASHOLD: u64 = 15;
const VM_DATA_THREASHOLD: u64 = 1_000_000_000;

#[derive(Clone)]
#[allow(dead_code)]
pub struct ProcinfoAnalyzer {
    config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
}
impl ProcinfoAnalyzer {
    /// Creates a new `ProcinfoAnalyzer` instance.
    ///
    /// # Arguments
    ///
    /// * `config_cache` - A shared cache of user anomaly configurations.
    ///
    /// # Returns
    ///
    /// A new instance of `ProcinfoAnalyzer`.
    pub fn new(config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>) -> Self {
        Self { config_cache }
    }

    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        // Get process data from last 30 seconds
        let process_data = crate::db::get_recent_proc_info(pool, 30).await?;
        let anomalies = self.analyze(&process_data).await;

        for anomaly in anomalies {
            crate::db::insert_proc_anomaly_event(pool, &anomaly).await?;
        }
        Ok(())
    }

    /// Analyzes the process information data for anomalies.
    ///
    /// This method processes the provided process information data and detects any anomalies based on predefined thresholds.
    ///
    /// # Arguments
    ///
    /// * `data` - A slice of `EndpointProcInfo` containing process information data.
    ///
    /// # Returns
    ///
    /// A vector of `ProcAnomalyEvent` representing the detected anomalies.
    async fn analyze(&self, data: &[EndpointProcInfo]) -> Vec<ProcAnomalyEvent> {
        let mut anomalies = Vec::new();
        let now = OffsetDateTime::now_utc();

        for record in data {
            if let Some(procs_data) = record.proc_info.get("ProcsData") {
                for (pid, proc) in procs_data.as_object().unwrap() {
                    let threads = proc.get("threads").and_then(|v| v.as_u64()).unwrap_or(0);

                    let vm_data = proc.get("vm_data").and_then(|v| v.as_u64()).unwrap_or(0);

                    let proc_name = proc
                        .get("name")
                        .and_then(|v| v.as_str())
                        .unwrap_or("unknown")
                        .to_string();

                    // Detect anomalies based on thresholds
                    if threads > THREAD_THREASHOLD || vm_data > VM_DATA_THREASHOLD {
                        let anomaly = ProcAnomalyEvent {
                            endpoint_id: record.endpoint_id,
                            proc_name: proc_name.clone(),
                            proc_info: proc.clone().into(),
                            time_window_start: record.record_timestamp,
                            time_window_end: now,
                            alert_description: Some(format!(
                                "Process {} (PID {}) exceeded thresholds: Threads={}, VM Data={}",
                                proc_name, pid, threads, vm_data
                            )),
                            acknowledged: false,
                            severity_level: Some(Self::determine_procinfo_severity(
                                threads, vm_data,
                            )),
                            created_at: now,
                            updated_at: now,
                            resolved: false,
                            resolution_description: None,
                        };
                        anomalies.push(anomaly);
                    }
                }
            }
        }
        anomalies
    }

    /// Determines the severity level based on the number of threads and virtual memory data.
    ///
    /// This method takes the number of threads and virtual memory data as input and returns a string
    /// representing the severity level.
    ///
    /// # Arguments
    ///
    /// * `threads` - The number of threads.
    /// * `vm_data` - The virtual memory data.
    ///
    /// # Returns
    ///
    /// A string representing the severity level.   
    fn determine_procinfo_severity(threads: u64, vm_data: u64) -> String {
        if threads > 100 || vm_data > 12_000_000_000 {
            "CRITICAL".to_string()
        } else if threads > 50 || vm_data > 7_000_000_000 {
            "HIGH".to_string()
        } else if threads > 30 || vm_data > 3_000_000_000 {
            "MEDIUM".to_string()
        } else {
            "LOW".to_string()
        }
    }
}
