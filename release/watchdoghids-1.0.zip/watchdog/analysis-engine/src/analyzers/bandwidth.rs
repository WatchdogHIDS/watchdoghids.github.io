//! Bandwidth Usage Analysis Module
//!
//! This module provides functionality for analyzing bandwidth usage per domain and detecting anomalies
//! by aggregating traffic data and comparing it against predefined thresholds. It operates over a
//! configurable time window and flags excessive bandwidth usage for further investigation or alerting.
//!
//! # Features
//!
//! - Aggregates domain data transfer by endpoint and IP.
//! - Detects anomalies based on bandwidth usage thresholds.
//! - Provides extensible methods for data analysis and user alerting.
//!
//!
//! # Constants
//!
//! - `WINDOW`: The analysis window duration in seconds (default: 24 hours).
//! - `BANDWIDTH_THRESHOLD_BYTES`: The threshold for bandwidth usage in bytes (default: 20GB).
//!
//! # Dependencies
//! - `sqlx` for database interactions.
//! - `time` for timestamp manipulation.

use crate::db;
use crate::models::UserAnomalyConfig;
use crate::models::{AggregatedBandwidth, NetworkAnomalyEvent};
use dashmap::DashMap;
use sqlx::MySqlPool;
use std::sync::Arc;
use time::OffsetDateTime;

// default values
const DEFAULT_WINDOW: u64 = 86400; // 24 hours
const DEFAULT_BANDWIDTH_THRESHOLD_BYTES: u64 = 20 * 1024 * 1024 * 1024; //20 GB

#[derive(Clone)]
pub struct BandwidthAnalyzer {
    config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>,
}

impl BandwidthAnalyzer {
    /// Creates a new instance of BandwithAnalyzer
    ///
    /// # Returns
    ///
    /// A new BandwithAnalyzer instance
    pub fn new(config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>) -> Self {
        Self { config_cache }
    }

    /// Executes the bandwidth analysis process.
    ///
    /// This method retrieves bandwidth data from the database, analyzes it for anomalies,
    /// and stores detected events.
    ///
    /// # Arguments
    ///
    /// * `pool` - A reference to the MySQL database connection pool.
    ///
    /// # Returns
    ///
    /// A `Result` indicating success or a database error.
    pub async fn run(&self, pool: &MySqlPool) -> Result<(), sqlx::Error> {
        // Process with custom configuration
        for entry in self.config_cache.iter() {
            let endpoint_id = *entry.key();
            let configs = entry.value();

            if let Some(config) = self.get_bandwidth_config(configs) {
                self.process_endpoint(
                    pool,
                    endpoint_id as u32,
                    config.sliding_window_minutes,
                    config.bandwidth_threshold,
                )
                .await?;
            }
        }

        // Process network-wide configuration
        self.process_endpoint(pool, 0, DEFAULT_WINDOW, DEFAULT_BANDWIDTH_THRESHOLD_BYTES)
            .await?;

        Ok(())
    }

    /// Analyzes bandwidth data to detect anomalies.
    ///
    /// This method checks if the total bytes for any connection exceed the threshold and
    /// generates events for those that do.
    ///
    /// # Arguments
    ///
    /// * `data` - A slice of `AggregatedBandwidth` records to analyze.
    ///
    /// # Returns
    ///
    /// A vector of `NetworkAnomalyEvent` objects representing detected anomalies.
    pub async fn analyze(
        &self,
        data: &[AggregatedBandwidth],
        bandwidth_limit: u64,
    ) -> Vec<NetworkAnomalyEvent> {
        let mut events = Vec::new();

        for record in data {
            if record.total_bytes > bandwidth_limit {
                let host = if record.endpoint_id == 0 {
                    "Network-Wide".to_string()
                } else {
                    format!("{}", record.external_ip)
                };

                events.push(NetworkAnomalyEvent {
                    event_id: 0,
                    endpoint_id: record.endpoint_id,
                    host_ip: host,
                    bandwidth_usage: record.total_bytes as u64,
                    time_window_start: OffsetDateTime::now_utc(),
                    time_window_end: OffsetDateTime::now_utc(),
                    alert_description: Some(format!(
                        "Bandwidth threshold exceeded: {}/{} bytes",
                        record.total_bytes, bandwidth_limit
                    )),
                    acknowledged: false,
                    severity_level: Some("HIGH".to_string()),
                    created_at: OffsetDateTime::now_utc(),
                    updated_at: OffsetDateTime::now_utc(),
                    resolved: false,
                    resolution_description: None,
                });
            }
        }
        events
    }

    /// Processes a specific endpoint's bandwidth data.
    ///
    /// This method retrieves recent bandwidth data for a given endpoint, analyzes it for anomalies,
    /// and inserts detected events into the database.
    ///
    /// # Arguments
    ///
    /// * `pool` - A reference to the MySQL database connection pool.
    /// * `endpoint_id` - The ID of the endpoint to process.
    /// * `time_window` - The time window in minutes for user configs (endpoint_id != 0) or seconds for default config (endpoint_id = 0).
    /// * `threshold` - The threshold for bandwidth usage in bytes.
    ///
    /// # Returns
    ///
    /// A `Result` indicating success or a database error.
    pub async fn process_endpoint(
        &self,
        pool: &MySqlPool,
        endpoint_id: u32,
        time_window: u64,
        threshold: u64,
    ) -> Result<(), sqlx::Error> {
        // Convert time_window from minutes to seconds if it's from user config
        // Default window is already in seconds
        let time_window_seconds = if endpoint_id != 0 {
            // User config is in minutes, convert to seconds
            time_window * 60
        } else {
            // Default window is already in seconds
            time_window
        };

        let bandwidth_data =
            db::get_recent_bandwidth(pool, endpoint_id, time_window_seconds).await?;
        let events = self.analyze(&bandwidth_data, threshold).await;

        for event in events {
            db::insert_network_anomaly_event_with_alert(pool, &event).await?;
        }

        Ok(())
    }

    /// Retrieves the bandwidth configuration from the given list of user anomaly configurations.
    ///
    /// # Arguments
    ///
    /// * `configs` - A slice of `UserAnomalyConfig` records to analyze.
    ///
    /// # Returns
    ///
    /// A `UserAnomalyConfig` record if found, otherwise `None`.
    fn get_bandwidth_config<'a>(
        &self,
        configs: &'a [UserAnomalyConfig],
    ) -> Option<&'a UserAnomalyConfig> {
        configs
            .iter()
            .find(|c| c.event_description.to_lowercase().contains("bandwidth"))
            .or_else(|| configs.first())
    }

    /// Sends an alert to the user for detected anomalies.
    ///
    /// Placeholder for a future implementation to notify users via external APIs or the UI.
    ///
    /// # Returns
    ///
    /// A `Result` indicating success or a database error
    pub async fn alert_user() -> Result<(), sqlx::Error> {
        // either external api notification or a new entry in the database for the ui to alert when alerts are implemented
        Ok(())
    }
}
