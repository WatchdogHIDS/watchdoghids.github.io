# Analysis Engine

## Overview

A Rust-based microservice for analyzing network traffic, system processes, and security events. The Analysis Engine detects anomalies, identifies potential security threats, and provides real-time alerts for suspicious activities.

## Features

- **Network Traffic Analysis**: Monitors bandwidth usage, protocol usage, and traffic patterns
- **Process Monitoring**: Tracks system processes for unusual behavior
- **Suspicious IP Detection**: Identifies connections to known malicious IP addresses through external APIs
- **User Login Analysis**: Detects unusual login patterns and potential account compromise
- **File Integrity Monitoring**: Tracks changes to critical system files
- **Resource Usage Analysis**: Monitors CPU and memory usage for anomalies
- **External API Integration**: Leverages threat intelligence from services like AbuseIPDB and VirusTotal
- **Webhook Support**: Provides real-time notifications for critical events

## Architecture

The Analysis Engine is built with a modular architecture consisting of:

- **Analyzers**: Specialized modules for different types of analysis
- **API Integrations**: Connections to external threat intelligence services
- **Database Layer**: Persistent storage for events and configuration
- **Webhook Server**: HTTP endpoints for configuration updates and notifications

## Environment Variables

- `DATABASE_URL`: MySQL connection string (required)
- `AGE_IDENTITY`: AGE encryption identity key for API key decryption
- `CACHE_DIR`: Directory for caching external API responses (default: `/var/cache/threat_intel`)
- `WEBHOOK_API_KEY`: API key for webhook authentication

## Getting Started

### Prerequisites

- Rust 1.56 or higher
- MySQL/MariaDB database
- AGE encryption tools (for API key management)

### Installation

1. Clone the repository
2. Set up the required environment variables
3. Build the project with `cargo build --release`
4. Run with `cargo run --release`

