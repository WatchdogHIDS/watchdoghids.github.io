use analysis_engine::{
    analyzers::bandwidth::BandwidthAnalyzer,
    models::{AggregatedBandwidth, UserAnomalyConfig},
};
use dashmap::DashMap;
use std::sync::Arc;

#[cfg(test)]
mod tests {
    use super::*;

    fn create_test_cache() -> Arc<DashMap<u64, Vec<UserAnomalyConfig>>> {
        Arc::new(DashMap::new())
    }

    #[tokio::test]
    async fn test_analyze_bandwidth() {
        let analyzer = BandwidthAnalyzer::new(create_test_cache());

        let data = vec![
            AggregatedBandwidth {
                endpoint_id: 1,
                internal_ip: "192.168.1.10".to_string(),
                external_ip: "123.45.67.89".to_string(),
                total_bytes: 35u64 * 1024 * 1024 * 1024, // 35GB
            },
            AggregatedBandwidth {
                endpoint_id: 2,
                internal_ip: "192.168.1.11".to_string(),
                external_ip: "98.76.54.32".to_string(),
                total_bytes: 15u64 * 1024 * 1024 * 1024, // 15GB
            },
        ];

        let events = analyzer.analyze(&data, 30u64 * 1024 * 1024 * 1024).await;
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].endpoint_id, 1);
        assert_eq!(events[0].host_ip, "123.45.67.89");
        assert_eq!(events[0].bandwidth_usage, 35u64 * 1024 * 1024 * 1024);
    }

    #[tokio::test]
    async fn test_analyze_bandwidth_network_wide() {
        let analyzer = BandwidthAnalyzer::new(create_test_cache());

        let data = vec![AggregatedBandwidth {
            endpoint_id: 0,
            internal_ip: "-1".to_string(),
            external_ip: "-1".to_string(),
            total_bytes: 35u64 * 1024 * 1024 * 1024, // 35GB
        }];
        let events = analyzer.analyze(&data, 30u64 * 1024 * 1024 * 1024).await;
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].endpoint_id, 0);
        assert_eq!(events[0].host_ip, "Network-Wide");
        assert_eq!(events[0].bandwidth_usage, 35u64 * 1024 * 1024 * 1024);
    }

    fn create_populated_cache() -> Arc<DashMap<u64, Vec<UserAnomalyConfig>>> {
        let cache = Arc::new(DashMap::new());
        cache.insert(
            1,
            vec![UserAnomalyConfig {
                endpoint_id: 1,
                user_id: 1,
                event_description: "Bandwidth threshold".to_string(),
                target_host: "example.com".to_string(),
                severity_level: "HIGH".to_string(),
                bandwidth_threshold: 10_000_000_000,
                sliding_window_minutes: 10,
            }],
        );
        cache
    }

    #[tokio::test]
    async fn test_process_endpoint() {
        let cache = create_populated_cache();
        let analyzer = BandwidthAnalyzer::new(cache);

        let data = vec![AggregatedBandwidth {
            endpoint_id: 1,
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "203.0.113.1".to_string(),
            total_bytes: 35u64 * 1024 * 1024 * 1024, // 35GB
        }];

        let threshold = 30u64 * 1024 * 1024 * 1024; // 30GB
        let events = analyzer.analyze(&data, threshold).await;

        assert_eq!(events.len(), 1);
        assert_eq!(events[0].endpoint_id, 1);
        assert_eq!(events[0].host_ip, "203.0.113.1");
        assert_eq!(
            events[0].alert_description,
            Some("Bandwidth threshold exceeded: 37580963840/32212254720 bytes".to_string())
        );
        assert_eq!(events[0].severity_level, Some("HIGH".to_string()));
        assert_eq!(
            events[0].bandwidth_usage,
            threshold + 5u64 * 1024 * 1024 * 1024
        );
    }

    #[tokio::test]
    async fn test_time_window_conversion() {
        // This test verifies that the time window is correctly converted from minutes to seconds
        // for user configs, but left as is for the default config

        struct MockBandwidthAnalyzer {}

        impl MockBandwidthAnalyzer {
            fn new(_config_cache: Arc<DashMap<u64, Vec<UserAnomalyConfig>>>) -> Self {
                Self {}
            }

            fn convert_time_window(&self, endpoint_id: u32, time_window: u64) -> u64 {
                if endpoint_id != 0 {
                    // User config is in minutes, convert to seconds
                    time_window * 60
                } else {
                    // Default window is already in seconds
                    time_window
                }
            }
        }

        let cache = create_populated_cache();
        let analyzer = MockBandwidthAnalyzer::new(cache);

        // Test user config (endpoint_id = 1) - should convert minutes to seconds
        let user_config_minutes = 30;
        let expected_seconds = user_config_minutes * 60;
        let actual_seconds = analyzer.convert_time_window(1, user_config_minutes);
        assert_eq!(actual_seconds, expected_seconds,
            "User config time window should be converted from minutes to seconds");

        // Test default config (endpoint_id = 0) - should not convert
        let default_config_seconds = 86400; // 24 hours in seconds
        let actual_seconds = analyzer.convert_time_window(0, default_config_seconds);
        assert_eq!(actual_seconds, default_config_seconds,
            "Default config time window should remain in seconds");
    }
}
