use analysis_engine::models::UserAnomalyConfig;
use analysis_engine::{analyzers::protocol::ProtocolAnalyzer, models::EndpointNetworkTraffic};
use dashmap::DashMap;
use std::sync::Arc;
use time::OffsetDateTime;

fn create_test_cache() -> Arc<DashMap<u64, Vec<UserAnomalyConfig>>> {
    Arc::new(DashMap::new())
}

#[tokio::test]
async fn test_high_risk_protocol_detection() {
    let analyzer = ProtocolAnalyzer::new(create_test_cache());

    let telnet_traffic = EndpointNetworkTraffic {
        endpoint_id: 1,
        record_timestamp: OffsetDateTime::now_utc(),
        internal_ip: "192.168.1.1".to_string(),
        external_ip: "8.8.8.8".to_string(),
        destination_port: 23,
        protocol: "TELNET".to_string(),
        connection_state: "ESTABLISHED".to_string(),
        packets: 100,
        bytes: 1500,
    };

    let events = analyzer.analyze(&[telnet_traffic]).await;

    assert_eq!(events.len(), 1);
    assert_eq!(events[0].severity_level, Some("HIGH".to_string()));
    assert!(events[0]
        .alert_description
        .as_ref()
        .unwrap()
        .contains("TELNET"));
}

#[tokio::test]
async fn test_medium_risk_protocol_detection() {
    let analyzer = ProtocolAnalyzer::new(create_test_cache());

    let ftp_traffic = EndpointNetworkTraffic {
        endpoint_id: 1,
        record_timestamp: OffsetDateTime::now_utc(),
        internal_ip: "192.168.1.1".to_string(),
        external_ip: "8.8.8.8".to_string(),
        destination_port: 21,
        protocol: "FTP".to_string(),
        connection_state: "ESTABLISHED".to_string(),
        packets: 100,
        bytes: 1500,
    };

    let events = analyzer.analyze(&[ftp_traffic]).await;

    assert_eq!(events.len(), 1);
    assert_eq!(events[0].severity_level, Some("MEDIUM".to_string()));
}

#[tokio::test]
async fn test_safe_protocol_generates_no_events() {
    let analyzer = ProtocolAnalyzer::new(create_test_cache());

    let safe_traffic = EndpointNetworkTraffic {
        endpoint_id: 1,
        record_timestamp: OffsetDateTime::now_utc(),
        internal_ip: "192.168.1.1".to_string(),
        external_ip: "8.8.8.8".to_string(),
        destination_port: 443,
        protocol: "HTTPS".to_string(),
        connection_state: "ESTABLISHED".to_string(),
        packets: 100,
        bytes: 1500,
    };

    let events = analyzer.analyze(&[safe_traffic]).await;
    assert_eq!(events.len(), 0);
}

#[tokio::test]
async fn test_multiple_protocols() {
    let analyzer = ProtocolAnalyzer::new(create_test_cache());

    let traffic = vec![
        EndpointNetworkTraffic {
            endpoint_id: 1,
            record_timestamp: OffsetDateTime::now_utc(),
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "8.8.8.8".to_string(),
            destination_port: 23,
            protocol: "telnet".to_string(),
            connection_state: "ESTABLISHED".to_string(),
            packets: 100,
            bytes: 1500,
        },
        EndpointNetworkTraffic {
            endpoint_id: 1,
            record_timestamp: OffsetDateTime::now_utc(),
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "8.8.8.8".to_string(),
            destination_port: 443,
            protocol: "HTTPS".to_string(),
            connection_state: "ESTABLISHED".to_string(),
            packets: 100,
            bytes: 1500,
        },
    ];

    let events = analyzer.analyze(&traffic).await;
    assert_eq!(events.len(), 1);
    assert_eq!(events[0].severity_level, Some("HIGH".to_string()));
}

#[tokio::test]
async fn test_protocol_case_insensitivity() {
    let analyzer = ProtocolAnalyzer::new(create_test_cache());

    let traffic = vec![
        EndpointNetworkTraffic {
            endpoint_id: 1,
            record_timestamp: OffsetDateTime::now_utc(),
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "8.8.8.8".to_string(),
            destination_port: 21,
            protocol: "ftp".to_string(),
            connection_state: "ESTABLISHED".to_string(),
            packets: 100,
            bytes: 1500,
        },
        EndpointNetworkTraffic {
            endpoint_id: 1,
            record_timestamp: OffsetDateTime::now_utc(),
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "8.8.8.8".to_string(),
            destination_port: 21,
            protocol: "FTP".to_string(),
            connection_state: "ESTABLISHED".to_string(),
            packets: 100,
            bytes: 1500,
        },
    ];

    let events = analyzer.analyze(&traffic).await;
    assert_eq!(events.len(), 2);
    assert!(events
        .iter()
        .all(|e| e.severity_level == Some("MEDIUM".to_string())));
}
