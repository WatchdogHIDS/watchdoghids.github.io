#[cfg(test)]
mod tests {
    use analysis_engine::{
        analyzers::traffic::TrafficAnalyzer,
        models::{EndpointNetworkTraffic, UserAnomalyConfig},
    };
    use dashmap::DashMap;
    use std::sync::Arc;
    use time::OffsetDateTime;

    fn create_test_cache() -> Arc<DashMap<u64, Vec<UserAnomalyConfig>>> {
        Arc::new(DashMap::new())
    }

    #[tokio::test]
    async fn test_traffic_analysis_logic() {
        // Create test data representing normal traffic
        let normal_traffic = EndpointNetworkTraffic {
            endpoint_id: 1,
            record_timestamp: OffsetDateTime::now_utc(),
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "8.8.8.8".to_string(),
            destination_port: 443,
            protocol: "TCP".to_string(),
            connection_state: "ESTABLISHED".to_string(),
            packets: 100,
            bytes: 1500,
        };

        // Create test data representing anomalous traffic (high volume)
        let anomalous_traffic = EndpointNetworkTraffic {
            endpoint_id: 1,
            record_timestamp: OffsetDateTime::now_utc(),
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "8.8.8.8".to_string(),
            destination_port: 443,
            protocol: "TCP".to_string(),
            connection_state: "ESTABLISHED".to_string(),
            packets: 10000,
            bytes: 150000,
        };

        let analyzer = TrafficAnalyzer::new(create_test_cache());

        // Test analysis function directly
        let events = analyzer
            .analyze(&[anomalous_traffic], &[normal_traffic])
            .await;

        // Verify analysis results
        assert!(!events.is_empty(), "Should detect anomaly");
        let event = &events[0];
        assert_eq!(event.endpoint_id, 1);
        assert_eq!(event.host_ip, "8.8.8.8");
        assert!(event.severity_level.as_ref().unwrap().contains("HIGH"));
    }

    #[tokio::test]
    async fn test_no_anomaly_for_normal_traffic() {
        let traffic1 = EndpointNetworkTraffic {
            endpoint_id: 1,
            record_timestamp: OffsetDateTime::now_utc(),
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "8.8.8.8".to_string(),
            destination_port: 443,
            protocol: "TCP".to_string(),
            connection_state: "ESTABLISHED".to_string(),
            packets: 100,
            bytes: 1500,
        };

        let traffic2 = EndpointNetworkTraffic {
            endpoint_id: 1,
            record_timestamp: OffsetDateTime::now_utc(),
            internal_ip: "192.168.1.1".to_string(),
            external_ip: "8.8.8.8".to_string(),
            destination_port: 443,
            protocol: "TCP".to_string(),
            connection_state: "ESTABLISHED".to_string(),
            packets: 105,
            bytes: 1550,
        };

        let analyzer = TrafficAnalyzer::new(create_test_cache());
        let events = analyzer.analyze(&[traffic2], &[traffic1]).await;

        assert!(
            events.is_empty(),
            "Should not detect anomaly for normal traffic variation"
        );
    }
}

/// Test a large file of network data, separate test since it's not a assert but more a visual thing ig
#[cfg(test)]
mod test_large_file {
    use analysis_engine::models::UserAnomalyConfig;
    use dashmap::DashMap;
    use rand::prelude::*;
    use rand::Rng;
    use serde::{Deserialize, Serialize};
    use std::collections::HashMap;
    use std::fs;
    use std::sync::Arc;

    fn create_test_cache() -> Arc<DashMap<u64, Vec<UserAnomalyConfig>>> {
        Arc::new(DashMap::new())
    }

    use analysis_engine::{analyzers::traffic::TrafficAnalyzer, models::EndpointNetworkTraffic};
    use time::OffsetDateTime;

    #[derive(Debug, Serialize, Deserialize)]
    struct NetworkEntry {
        proto: String,
        orig_pkts: String,
        resp_pkts: String,
        orig_bytes: String,
        resp_bytes: String,
    }

    #[derive(Debug, Serialize, Deserialize)]
    struct NetworkData {
        network_data: HashMap<String, NetworkEntry>,
    }

    #[tokio::test]
    #[ignore]
    async fn test_process_network_file() {
        let data = fs::read_to_string("tests/test_network_data.json").expect("Unable to read file");

        let network_data: NetworkData = serde_json::from_str(&data).expect("Unable to parse JSON");

        let current_traffic: Vec<EndpointNetworkTraffic> = network_data
            .network_data
            .iter()
            .enumerate()
            .map(|(_i, (ip_port, entry))| {
                let (ip, _) = ip_port.split_once(":").unwrap_or((ip_port, "0"));
                EndpointNetworkTraffic {
                    endpoint_id: 1,
                    record_timestamp: OffsetDateTime::now_utc(),
                    internal_ip: "192.168.1.1".to_string(),
                    external_ip: ip.to_string(),
                    destination_port: ip_port.parse().unwrap_or(0),
                    protocol: entry.proto.clone(),
                    connection_state: "ESTABLISHED".to_string(),
                    packets: (entry.orig_pkts.parse::<u64>().unwrap_or(0)
                        + entry.resp_pkts.parse::<u64>().unwrap_or(0)) as u32,
                    bytes: entry.orig_bytes.parse::<u64>().unwrap_or(0)
                        + entry.resp_bytes.parse::<u64>().unwrap_or(0),
                }
            })
            .collect();

        let previous_traffic: Vec<EndpointNetworkTraffic> = {
            let mut rng = rand::thread_rng();

            // Get random subset size between 10-90% of current records
            let subset_size =
                rng.gen_range((current_traffic.len() * 1 / 10)..(current_traffic.len() * 9 / 10));

            current_traffic
                .iter()
                .choose_multiple(&mut rng, subset_size)
                .into_iter()
                .map(|record| {
                    let random = rng.gen::<f64>();

                    let baseline_bytes = match random {
                        // high
                        x if x < 0.01 => record.bytes / 60,
                        // Medium
                        x if x < 0.03 => record.bytes / 2,
                        // Low
                        x if x < 0.1 => record.bytes / 1,
                        // Normal
                        _ => record.bytes,
                    };

                    EndpointNetworkTraffic {
                        bytes: baseline_bytes,
                        packets: (baseline_bytes / 100) as u32,
                        ..record.clone()
                    }
                })
                .collect()
        };

        let analyzer = TrafficAnalyzer::new(create_test_cache());
        let events = analyzer.analyze(&current_traffic, &previous_traffic).await;

        println!("\nTraffic Analysis Results:");
        println!("-------------------------");
        println!("Total records analyzed: {}", current_traffic.len());
        println!("Anomalies detected: {}", events.len());

        for event in events {
            println!(
                "Host: {}, Usage: {}, Severity: {}",
                event.host_ip,
                event.bandwidth_usage,
                event.severity_level.unwrap_or_default()
            );
        }
    }
}

#[cfg(test)]
mod test_db_connection {
    use analysis_engine::db::connect_to_db;
    use dotenv::dotenv;

    fn with_env_state<F, R>(test_fn: F) -> R
    where
        F: FnOnce() -> R,
    {
        let original_url = std::env::var("DATABASE_URL").ok();
        let result = test_fn();
        // Restore original state
        match original_url {
            Some(url) => std::env::set_var("DATABASE_URL", url),
            None => std::env::remove_var("DATABASE_URL"),
        }
        result
    }

    #[tokio::test]
    async fn test_db_connection() {
        with_env_state(|| async {
            dotenv().ok();
            let pool = connect_to_db().await;
            assert!(pool.is_ok(), "Should connect to database");

            let pool = pool.unwrap();
            assert!(
                sqlx::query("SELECT 1").execute(&pool).await.is_ok(),
                "Should be able to execute query"
            );
        })
        .await
    }

    #[tokio::test]
    async fn test_db_connection_invalid_url() {
        with_env_state(|| async {
            std::env::set_var(
                "DATABASE_URL",
                "mysql://invalid:invalid@localhost:3306/invalid",
            );
            let pool = connect_to_db().await;
            assert!(
                pool.is_err(),
                "Should fail to connect with invalid credentials"
            );
        })
        .await
    }

    #[tokio::test]
    async fn test_db_connection_no_url() {
        with_env_state(|| async {
            std::env::remove_var("DATABASE_URL");
            let pool = connect_to_db().await;
            assert!(pool.is_err(), "Should fail when DATABASE_URL is not set");
        })
        .await
    }
}
