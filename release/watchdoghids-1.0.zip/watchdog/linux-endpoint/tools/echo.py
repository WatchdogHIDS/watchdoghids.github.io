import socket

response = "THANKS\0"
response = response.encode()

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind(("0.0.0.0", 8081))

sock.listen(5)

while True:
    client_sock, client_addr = sock.accept()
    print("----START-MESSAGE----")

    while True:
        buf = client_sock.recv(1024)
        print(buf.decode())

        if len(buf) == 1024:
            continue
        else:
            break
    print("----END-MESSAGE----")

    client_sock.send(response)
    client_sock.close()
