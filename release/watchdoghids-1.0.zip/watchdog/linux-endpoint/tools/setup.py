import socket

ip = input("Enter endpoint ip: ")
port = int(input("Enter endpoint port: "))
key = input("Enter endpoint key: ")

msg = f"""
{{
    "key": "{key}",
    "port": 8081
}}
"""
print(msg)

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind(("0.0.0.0", 8081))
sock.connect((ip, port))
sock.sendall(msg.encode())

response = b""
response = sock.recv(1024)
response = response.decode()
print(f"Response: {response}")

sock.close()

exit()
