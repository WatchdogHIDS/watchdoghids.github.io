#include "comms.h"
#include "signal.h"
#include <arpa/inet.h>
#include <check.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

// int connect_server(char *ip, int port);
// int post_server(char *payload, char *ip, int port);

// Test connecting to a non-existing server
START_TEST(connect_fail) {
  FILE *trash = freopen("/dev/null", "w", stderr);
  int result = connect_server("127.0.0.1", 1);
  ck_assert_int_eq(result, -1);
  fclose(trash);
}
END_TEST

// Test posting to a non-existant server, then exiting while trying to reconnect
START_TEST(post_fail) {
  FILE *trash = freopen("/dev/null", "w", stderr);
  pid_t pid = fork();

  if (pid != 0) {
    sleep(5);
    kill(pid, SIGINT);
    int status;
    waitpid(pid, &status, 0);
    ck_assert(WIFEXITED(status));
    fclose(trash);
  } else {
    post_server("test", "127.0.0.1", 1);
  }
}
END_TEST

// Test connecting to an existing server
START_TEST(connect_pass) {
  FILE *trash = freopen("/dev/null", "w", stderr);
  struct sockaddr_in addr;
  addr.sin_addr.s_addr = INADDR_ANY;
  addr.sin_family = AF_INET;
  addr.sin_port = htons(8081);

  int listen_fd, connect_fd = 0;
  listen_fd = socket(AF_INET, SOCK_STREAM, 0);
  ck_assert_int_ge(listen_fd, 0);
  ck_assert_int_ge(bind(listen_fd, (struct sockaddr *)&addr, sizeof(addr)), 0);
  ck_assert_int_ge(listen(listen_fd, 1), 0);

  pid_t pid = fork();

  if (pid != 0) {
    while (1)
      if ((connect_fd = accept(listen_fd, NULL, NULL) != 0))
        break;
    close(listen_fd);
    close(connect_fd);
  } else {
    int result = connect_server("127.0.0.1", 8081);
    ck_assert_int_ne(result, -1);
    return;
    fclose(trash);
  }
}
END_TEST

// Test connecting to a non-running server, then starting
START_TEST(reconnect_pass) {
  FILE *trash = freopen("/dev/null", "w", stderr);
  pid_t pid = fork();

  if (pid == 0) {
    int result = connect_server("127.0.0.1", 8082);
    ck_assert_int_eq(result, -1);
    exit(0);
  } else {
    waitpid(pid, NULL, 0);
  }

  struct sockaddr_in addr;
  addr.sin_addr.s_addr = INADDR_ANY;
  addr.sin_family = AF_INET;
  addr.sin_port = htons(8082);

  int listen_fd, connect_fd = 0;
  listen_fd = socket(AF_INET, SOCK_STREAM, 0);
  ck_assert_int_ge(listen_fd, 0);
  ck_assert_int_ge(bind(listen_fd, (struct sockaddr *)&addr, sizeof(addr)), 0);
  ck_assert_int_ge(listen(listen_fd, 1), 0);

  pid = fork();

  if (pid != 0) {
    while (1)
      if ((connect_fd = accept(listen_fd, NULL, NULL) != 0))
        break;
    close(listen_fd);
    close(connect_fd);
  } else {
    int result = connect_server("127.0.0.1", 8082);
    ck_assert_int_ne(result, -1);
    return;
    fclose(trash);
  }
}
END_TEST

// Build test suite for comms
Suite *make_comms_suite() {
  Suite *s = suite_create("Comms tests");
  TCase *tc_good = tcase_create("Working");
  TCase *tc_bad = tcase_create("Failing");

  tcase_add_test(tc_bad, connect_fail);
  tcase_add_test(tc_bad, post_fail);
  tcase_set_timeout(tc_bad, 10);
  suite_add_tcase(s, tc_bad);

  tcase_add_test(tc_good, connect_pass);
  tcase_add_test(tc_good, reconnect_pass);
  tcase_set_timeout(tc_good, 10);
  suite_add_tcase(s, tc_good);

  return s;
}

// Run test suite for comms
int main() {
  int num_failed = 0;
  Suite *s = make_comms_suite();
  SRunner *sr = srunner_create(s);
  srunner_run_all(sr, CK_NORMAL);
  num_failed = srunner_ntests_failed(sr);
  srunner_free(sr);
  return (num_failed == 0) ? 0 : 1;
}
