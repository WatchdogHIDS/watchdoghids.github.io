# Linux Endpoint

## Overview

This is the endpoint service for watchdog. It is designed to collect relevant
data on endpoints.

## Building

### Dependencies

- libpcap
- cjson
- uthash
- openssl

Make sure to install the above before attempting to build. Should all be in your
distros package manager:\
`sudo pacman -S libpcap cjson uthash openssl`\
`sudo apt install libpcap-dev libcjson-dev uthash-dev libssl-dev`

### Compile

Build using `make`

## Installing

`make install` can be run to build, install, enable, and start the systemd
service.

## Running (without install)

`make run` will build and run the program.\
`make run -r` will remove all config and clean the cache\
`make run -s` will run the setup wizard to pair with the central server and
generate a config

## Deleting

`make remove` can be run to delete the systemd service as well as an referenced
files. `make clean` will delete all compile objects and binaries

## Config

The config file for the endpoint is stored at `/etc/watchdog-endpoint/config`.
On first run (or if you delete the config file) it will generate a config with
the default options. You can edit the options as you like, just remeber to
`systemctl restart watchdog-endpoint` to make sure the changes are applied.
