#ifndef HELPER_H
#define HELPER_H
#include <stdio.h>
#include <stdlib.h>

unsigned char *sha1_hash(char *file);
void *safe_alloc(size_t size);
char *safe_realloc_str(char *str, size_t len);
char *safe_strcat(char *lhs, const char *rhs);
char *bin2hex(const unsigned char *bin, size_t len);
char *read_file(char *filename);

#endif
