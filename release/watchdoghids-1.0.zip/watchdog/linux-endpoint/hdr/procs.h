#ifndef PROCS_H
#define PROCS_H
#include <cjson/cJSON.h>
#include <openssl/sha.h>
#include <uthash.h>

void proc_capture_setup(int *fds);
void *proc_capture(void *args);

struct proc {
  int pid;
  int uid;
  int gid;
  long vm_data;
  long vm_stk;
  int threads;
  char *state;
  char name[1024];
  UT_hash_handle hh;
};

struct status {
  int pid;
  unsigned char digest[SHA_DIGEST_LENGTH];
  UT_hash_handle hh;
};

struct cJSON *procs_to_json(struct proc *procs);
void sync_procs();

#endif
