#ifndef RESOURCE_H
#define RESOURCE_H
#include <cjson/cJSON.h>
#include <uthash.h>

void resource_capture_setup(int *fds);
void *resource_capture(void *args);

struct resource {
  int pid;
  char *cpu;
  char *mem;
  char *time;
  UT_hash_handle hh;
};

struct cJSON *rcrs_to_json(struct resource *rcrs);
void sync_rcrs(struct resource *rcrs);

#endif
