#ifndef USERS_H
#define USERS_H
#include <cjson/cJSON.h>
#include <openssl/sha.h>
#include <stdbool.h>
#include <unistd.h>
#include <uthash.h>

void users_capture_setup(int *fds);
void *users_capture(void *args);

struct user {
  int uid;
  char *name;
  UT_hash_handle hh;
};

struct group {
  int gid;
  char *name;
  int uids_size;
  int *uids;
  UT_hash_handle hh;
};

struct login {
  char *key;
  int uid;
  char *ip;
  char *date_start;
  char *time_start;
  char *date_end;
  char *time_end;
  UT_hash_handle hh;
};

void sync_users(char *json);

void user_to_json(cJSON *object, struct user *user);
void group_to_json(cJSON *object, struct group *group);
void login_to_json(cJSON *object, struct login *login);

struct user *load_users();
struct group *load_groups();
struct login *load_logins();

void cache_users(struct user *users, struct group *groups,
                 struct login *logins);
#endif
