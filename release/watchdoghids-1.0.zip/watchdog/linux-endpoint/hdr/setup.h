#ifndef SETUP_H
#define SETUP_H
#include <stdbool.h>
#include <stdlib.h>

struct server_info {
  char *ip;
  int port;
  int timer;
  char *key;
  size_t dirs_size;
  char *dirs[1024];
};

bool setup();
char *gen_key();
int write_http_response(int sockfd, const char *msg, int status);
int extract_port_from_request(const char *request);

#endif
