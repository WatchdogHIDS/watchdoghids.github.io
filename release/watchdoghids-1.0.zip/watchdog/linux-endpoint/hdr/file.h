#ifndef FILE_H
#define FILE_H
#include <cjson/cJSON.h>
#include <limits.h>
#include <openssl/sha.h>
#include <stdbool.h>
#include <stdio.h>
#include <sys/inotify.h>
#include <uthash.h>

#define _XOPEN_SOURCE
#include <ftw.h>

#define BUF_LEN (10 * (sizeof(struct inotify_event) + NAME_MAX + 1))

struct file {
  char *path;
  char *date_time;
  UT_hash_handle hh;
};

void sync_events();
void file_capture_setup(int *fds, char **dirs, size_t dirs_size);
void *file_capture(void *args);

struct file *load_files();
void cache_files();
int new_f(const char *fpath, const struct stat *sb, int typeflag);

#endif
