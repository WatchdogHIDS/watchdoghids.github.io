#ifndef NETWORK_H
#define NETWORK_H
#include <cjson/cJSON.h>
#include <pcap.h>
#include <uthash.h>

void packet_handler(u_char *args, const struct pcap_pkthdr *header,
                    const u_char *packet);
void *network_capture(void *arg);

struct host {
  char key[32];
  char ip[28];
  char proto[4];
  unsigned long long orig_pkts;
  unsigned long long resp_pkts;
  unsigned long long orig_bytes;
  unsigned long long resp_bytes;
  UT_hash_handle hh;
};

struct cJSON *hosts_to_json(struct host *hosts);
void *network_process(void *arg);
void sync_hosts();
void set_dev_addr(char *addr);
void *setup_network_capture(int *fds);

#endif
