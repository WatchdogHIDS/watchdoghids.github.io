#ifndef H_COMMS
#define H_COMMS
#include "setup.h"
#include <stdbool.h>
#include <stdio.h>

int connect_server(struct server_info *info);
bool post_server(char *payload, struct server_info *info);

#endif
