#include "file.h"
#include "cjson/cJSON.h"
#include "helper.h"
#include "uthash.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

struct file *files = NULL;
struct cJSON *events = NULL;
int *file_pipe = NULL;
char **watch_dirs = NULL;
size_t watch_dirs_size = 0;
bool init_scan = true;

void sync_events() {
  char *json_str = cJSON_Print(events);

  // Write to pipe
  int write_count = write(file_pipe[1], json_str, strlen(json_str));
  write_count += write(file_pipe[1], "\0", 1);

  if (write_count != strlen(json_str) + 1) {
    fprintf(stderr, "File Thread: Error writing to pipe\n");
    exit(EXIT_FAILURE);
  }

  // Clean up
  cJSON_free(events);
  events = NULL;
  free(json_str);

  return;
}

void file_capture_setup(int *fds, char **dirs, size_t dirs_size) {
  file_pipe = fds;
  watch_dirs = dirs;
  watch_dirs_size = dirs_size;
  for (int i = 0; i < dirs_size; i++) {
    printf("File Thread: adding watch on dir '%s'\n", dirs[i]);
  }

  files = load_files();
  printf("File Thread: taking initial system inventory...\n");
  fflush(stdout);
  for (int i = 0; i < watch_dirs_size; i++) {
    if (ftw(watch_dirs[i], new_f, FOPEN_MAX) != 0) {
      fprintf(stderr, "ERROR: %s\n", strerror(errno));
      fprintf(stderr, "File Thread: could not traverse dir '%s'\n",
              watch_dirs[i]);
      exit(EXIT_FAILURE);
    }
  }
  cache_files();

  init_scan = false;
  return;
}

void *file_capture(void *args) {
  // Setup
  files = load_files();
  events = cJSON_CreateObject();

  // Check for new files
  for (int i = 0; i < watch_dirs_size; i++) {
    printf("File Thread: scanning dir '%s'\n", watch_dirs[i]);
    fflush(stdout);
    if (ftw(watch_dirs[i], new_f, FOPEN_MAX) != 0) {
      fprintf(stderr, "File Thread: could not traverse dir '%s'\n",
              watch_dirs[i]);
    } else {

      // Check for modified / deleted files
      struct file *cur = NULL;
      for (cur = files; cur != NULL;) {
        struct stat cur_stat;
        if (stat(cur->path, &cur_stat) == 0) {
          char *new_date_time = safe_alloc(21);
          strftime(new_date_time, 20, "%Y-%m-%dT%H:%M:%S",
                   localtime((time_t *)&cur_stat.st_mtim));

          // Modified
          if (strncmp(new_date_time, cur->date_time, 20)) {
            free(cur->date_time);
            cur->date_time = new_date_time;

            struct cJSON *mod_event = cJSON_CreateObject();

            char *split_dt = safe_alloc(strlen(cur->date_time) + 1);
            memcpy(split_dt, cur->date_time, strlen(cur->date_time));
            char *tok = strtok(split_dt, "T");

            char *date = safe_alloc(strlen(tok) + 1);
            memcpy(date, tok, strlen(tok));
            cJSON_AddStringToObject(mod_event, "date", date);

            tok = strtok(NULL, "T");
            char *time = safe_alloc(strlen(tok) + 1);
            memcpy(time, tok, strlen(tok));
            cJSON_AddStringToObject(mod_event, "time", time);

            cJSON_AddStringToObject(mod_event, "type", "mod");
            cJSON_AddItemToObject(events, cur->path, mod_event);
          } else {
            free(new_date_time);
          }
          cur = cur->hh.next;
        }
        // Deleted
        else if (errno == ENOENT) {
          char *cur_date_time = safe_alloc(27);
          time_t cur_t = time(NULL);

          strftime(cur_date_time, 26, "%Y-%m-%dT%H:%M:%S", localtime(&cur_t));

          struct cJSON *del_event = cJSON_CreateObject();

          char *del_tok = strtok(cur_date_time, "T");
          char *cur_date = safe_alloc(strlen(del_tok) + 1);
          memcpy(cur_date, del_tok, strlen(del_tok));
          cJSON_AddStringToObject(del_event, "date", cur_date);

          del_tok = strtok(NULL, "T");
          char *cur_time = safe_alloc(strlen(del_tok) + 1);
          memcpy(cur_time, del_tok, strlen(del_tok));
          cJSON_AddStringToObject(del_event, "time", cur_time);

          char *old_path = safe_alloc(strlen(cur->path) + 1);
          memcpy(old_path, cur->path, strlen(cur->path));

          cJSON_AddStringToObject(del_event, "type", "delete");
          cJSON_AddItemToObject(events, old_path, del_event);

          struct file *tmp = cur;
          cur = cur->hh.next;

          free(cur_date_time);
          HASH_DEL(files, tmp);
          free(tmp->path);
          free(tmp->date_time);
          free(tmp);
        }
        // Error
        else {
          fprintf(stderr, "File Thread: Could not stat file '%s': %s\n",
                  cur->path, strerror(errno));
          cur = cur->hh.next;
        }
      }

      // Sync events
      sync_events();
      events = cJSON_CreateObject();
      cache_files();
    }
  }
  return NULL;
}

struct cJSON *files_to_json(struct file *files) {
  struct cJSON *result = cJSON_CreateObject();
  struct file *cur_file, *tmp;
  HASH_ITER(hh, files, cur_file, tmp) {
    struct cJSON *file = cJSON_CreateObject();
    cJSON_AddStringToObject(file, "date_time", cur_file->date_time);
    cJSON_AddItemToObject(result, cur_file->path, file);
  }
  return result;
}

struct file *json_to_files(struct cJSON *json) {
  struct file *result = NULL;
  struct cJSON *cur = json->child;

  while (cur != NULL) {
    struct file *cur_file = safe_alloc(sizeof(struct file));

    cur_file->path = safe_alloc(strlen(cur->string) + 1);
    strcpy(cur_file->path, cur->string);

    cur_file->date_time = safe_alloc(strlen(cur->child->valuestring) + 1);
    memcpy(cur_file->date_time, cur->child->valuestring,
           strlen(cur->child->valuestring));

    HASH_ADD_STR(result, path, cur_file);
    cur = cur->next;
  }
  return result;
}

void cache_files() {
  // users
  if (files != NULL) {
    FILE *files_cache = fopen("/etc/watchdog-endpoint/cache/files", "w");
    struct cJSON *files_json = files_to_json(files);
    char *json_str = cJSON_Print(files_json);
    fwrite(json_str, 1, strlen(json_str), files_cache);
    free(files_json);
    fclose(files_cache);
  }
}

struct file *load_files() {
  char *json = read_file("/etc/watchdog-endpoint/cache/files");
  if (json == NULL)
    return NULL;

  struct cJSON *parsed = cJSON_Parse(json);
  struct file *files = json_to_files(parsed);
  free(json);
  cJSON_free(parsed);

  return files;
}

int new_f(const char *fpath, const struct stat *sb, int typeflag) {
  if (typeflag == FTW_F) {
    struct stat fstat;
    if (stat(fpath, &fstat) != 0)
      return 0;

    struct file *file = NULL;
    HASH_FIND_STR(files, fpath, file);

    if (file == NULL) {
      file = safe_alloc(sizeof(struct file));
      file->path = safe_alloc(strlen(fpath) + 1);
      memcpy(file->path, fpath, strlen(fpath));
      file->date_time = safe_alloc(21);
      strftime(file->date_time, 20, "%Y-%m-%dT%H:%M:%S",
               localtime((time_t *)&fstat.st_mtim));

      HASH_ADD_STR(files, path, file);

      if (!init_scan) {
        struct cJSON *event = cJSON_CreateObject();
        char *date_time = safe_alloc(strlen(file->date_time) + 1);
        memcpy(date_time, file->date_time, strlen(file->date_time));
        char *tok = strtok(date_time, "T");
        char *date_str = safe_alloc(strlen(tok) + 1);
        memcpy(date_str, tok, strlen(tok));
        tok = strtok(NULL, "T");
        char *time_str = safe_alloc(strlen(tok) + 1);
        memcpy(time_str, tok, strlen(tok));
        free(date_time);

        cJSON_AddStringToObject(event, "date", date_str);
        cJSON_AddStringToObject(event, "time", time_str);
        cJSON_AddStringToObject(event, "type", "create");

        cJSON_AddItemToObject(events, file->path, event);
      }
    }
  }
  return 0;
}
