#include "procs.h"
#include "helper.h"
#include <dirent.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>

int *procs_pipe = NULL;
struct status *stats = NULL;
struct proc *procs = NULL;
DIR *proc_dir = NULL;

/**
 * @brief Converts procs hash table to cJSON
 * @details
 * @param[procs] the proc hashtable to be converted
 * @return Converted cJSON struct
 */
struct cJSON *procs_to_json(struct proc *procs) {
  cJSON *object = cJSON_CreateObject();
  cJSON *proc_data = cJSON_CreateObject();

  struct proc *cur_proc = procs;
  while (cur_proc != NULL) {
    cJSON *p = cJSON_CreateObject();

    cJSON_AddStringToObject(p, "name", cur_proc->name);
    cJSON_AddStringToObject(p, "state", cur_proc->state);
    cJSON_AddNumberToObject(p, "uid", cur_proc->uid);
    cJSON_AddNumberToObject(p, "gid", cur_proc->gid);
    cJSON_AddNumberToObject(p, "vm_data", cur_proc->vm_data);
    cJSON_AddNumberToObject(p, "vm_stk", cur_proc->vm_stk);
    cJSON_AddNumberToObject(p, "threads", cur_proc->threads);

    char pid_str[100];
    sprintf(pid_str, "%d", cur_proc->pid);
    cJSON_AddItemToObject(proc_data, pid_str, p);
    cur_proc = cur_proc->hh.next;
  }

  cJSON_AddItemToObject(object, "ProcsData", proc_data);
  return object;
}

/**
 * @brief Writes current procs hashtable to comm pipe
 * @details calls json convert
 * @return NA
 */
void sync_procs() {
  // Get json
  struct cJSON *json = procs_to_json(procs);
  char *json_str = cJSON_Print(json);

  // Write to pipe
  int write_count = write(procs_pipe[1], json_str, strlen(json_str));
  write_count += write(procs_pipe[1], "\0", 1);

  if (write_count != strlen(json_str) + 1) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Procs Thread: Error writing to pipe\n");
    exit(EXIT_FAILURE);
  }

  // Clean up
  free(json_str);
  cJSON_Delete(json);
  struct proc *cur, *tmp;
  HASH_ITER(hh, procs, cur, tmp) {
    HASH_DEL(procs, cur);
    free(cur);
  }

  procs = NULL;
  return;
}

/**
 * @brief Populates a proc struct based on its PID
 * @details required the PID be set
 * @param[p] The proc struct
 * @return Implicit return by populating passed in struct
 */
void read_proc(struct proc *p) {
  // Get exe name
  char *exe_link = safe_alloc(BUFSIZ);
  sprintf(exe_link, "/proc/%d/exe", p->pid);
  char *path = safe_alloc(PATH_MAX);
  memset(path, 0, PATH_MAX);

  int len = readlink(exe_link, path, PATH_MAX - 1);
  if (len == -1) {
    free(exe_link);
    free(path);
    HASH_DEL(procs, p);
    return;
  }
  free(exe_link);
  path[len] = '\0';

  int last = 0;
  for (int i = 0; i < len; i++) {
    if (path[i] == '/')
      last = i + 1;
  }
  int name_len = strlen(path) - last;
  char *name = safe_alloc(len + 1);
  strncpy(name, path + last, name_len);
  memcpy(p->name, name, strlen(name));
  free(name);
  free(path);

  // Read /proc/*/status
  char *filename = safe_alloc(BUFSIZ);
  sprintf(filename, "/proc/%d/status", p->pid);
  FILE *stat = fopen(filename, "r");
  if (stat == NULL) {
    free(filename);
    HASH_DEL(procs, p);
    return;
  }
  free(filename);

  char *data = safe_alloc(1);
  char *buf = safe_alloc(BUFSIZ);
  int read = 0;
  while ((read = fread(buf, 1, BUFSIZ, stat)) != 0) {
    int len = strlen(data) + read + 1;
    data = safe_realloc_str(data, len);
    strncat(data, buf, read);
    memset(buf, 0, BUFSIZ);
  }
  fclose(stat);
  free(buf);

  char *line = NULL;
  line = strtok(data, "\n");
  while (line != NULL) {
    if (!strncmp("State", line, 5)) {
      p->state = safe_alloc(2);
      p->state[0] = line[7];
    } else if (!strncmp("Uid", line, 3)) {
      p->uid = strtol(line + 5, NULL, 10);
    } else if (!strncmp("Gid", line, 3)) {
      p->gid = strtol(line + 5, NULL, 10);
    } else if (!strncmp("VmData", line, 6)) {
      int i = 8;
      while (line[i] == ' ' || line[i] == '\t')
        i += 1;
      p->vm_data = strtol(line + i, NULL, 10) * 1000;
    } else if (!strncmp("VmStk", line, 5)) {
      int i = 7;
      while (line[i] == ' ' || line[i] == '\t')
        i += 1;
      p->vm_stk = strtol(line + i, NULL, 10) * 1000;
    } else if (!strncmp("Threads", line, 7)) {
      p->threads = strtol(line + 9, NULL, 10);
    }
    line = strtok(NULL, "\n");
  }
}

/**
 * @brief Sets up the env for the proc thread
 * @details Assigns comm pipe and opens proc dir
 * @param[fds] The pipe to use to communicate
 * @return NA
 */
void proc_capture_setup(int *fds) {
  procs_pipe = fds;

  proc_dir = opendir("/proc");
  if (proc_dir == NULL) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Procs Thread: Could not open /proc\n");
    exit(EXIT_FAILURE);
  }
}

/**
 * @brief Captures all updated info about procs
 * @details Reads all folders in proc dir to determine PIDs,
 *          Opens and hashes all stat files for each PID,
 *          If the hash has changed (or file didn't exist) it
 *           makes a new entry in procs,
 *          pushes all new proc info onto pipe
 * @return NA
 */
void *proc_capture(void *arg) {
  // Iterate through entries looking for PID folders
  struct dirent *dent = NULL;
  while ((dent = readdir(proc_dir)) != NULL) {
    if (!strcmp(dent->d_name, ".") || !strcmp(dent->d_name, ".."))
      continue;

    struct stat st;
    if (fstatat(dirfd(proc_dir), dent->d_name, &st, 0) < 0) {
      fprintf(stderr, "ERROR: %s\n", strerror(errno));
      fprintf(stderr, "Procs Thread: Invalid file '%s' in proc dir\n",
              dent->d_name);
      return NULL;
    }

    if (S_ISDIR(st.st_mode)) {
      char *end_ptr = NULL;
      int pid = strtol(dent->d_name, &end_ptr, 10);

      if (pid == 0 || errno == ERANGE)
        continue;

      struct status *stat = NULL;
      HASH_FIND_INT(stats, &pid, stat);

      if (stat == NULL) {
        stat = safe_alloc(sizeof(struct status));
        stat->pid = pid;
        HASH_ADD_INT(stats, pid, stat);
      }
    }
  }

  // Hash and check all status files
  procs = NULL;
  for (struct status *s = stats; s != NULL; s = s->hh.next) {
    char filename[BUFSIZ];
    sprintf(filename, "/proc/%d/status", s->pid);
    unsigned char *new_digest = sha1_hash(filename);
    if (new_digest == NULL)
      continue;

    if (memcmp(s->digest, new_digest, SHA_DIGEST_LENGTH)) {
      memcpy(s->digest, new_digest, SHA_DIGEST_LENGTH);
      struct proc *p = safe_alloc(sizeof(struct proc));
      p->pid = s->pid;
      HASH_ADD_INT(procs, pid, p);
    }

    free(new_digest);
  }

  // Place new status files in procs hashtable
  for (struct proc *p = procs; p != NULL; p = p->hh.next)
    read_proc(p);

  sync_procs();
  return NULL;
}
