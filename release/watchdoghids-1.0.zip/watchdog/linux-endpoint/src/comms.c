#include "comms.h"
#include "helper.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

/**
 * @brief Connect to server @ info->ip:info->port
 * @details Opens a socket, connect to server, returns socket
 * @param[info->ip] IP of the server to connect to
 * @param[info->port] Port over which to connect to the server
 * @return socket file descrinfo->iptor for the server
 */
int connect_server(struct server_info *info) {
  // Connect to server
  struct sockaddr_in serv_addr;
  int sockfd = 0;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Comm Thread: Error opening socket\n");
    exit(EXIT_FAILURE);
  }

  memset(&serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(info->port);
  inet_pton(AF_INET, info->ip, &serv_addr.sin_addr);

  if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Comm Thread: Failed to connect to server @ %s:%d\n",
            info->ip, info->port);
    return -1;
  };

  return sockfd;
}

/**
 * @brief POSTs message to server
 * @details Calls connect_server,
 *          Formats HTTP POST request,
 *          Sends message to server,
 *          waits for response.
 * @param[payload] The payload of the HTTP POST request
 * @param[info->ip] IP of the server to send the message to
 * @param[info->port] The info->port over which to communicate with the server
 * @return true on success, false otherwise
 */
bool post_server(char *payload, struct server_info *info) {
  int sockfd = connect_server(info);

  while (sockfd == -1) {
    return false;
  }
  // POST
  char *message = safe_alloc(BUFSIZ + strlen(payload));
  sprintf(message,
          "POST /data/update HTTP/1.1\r\n"
          "Host: %s\r\n"
          "Authorization: Bearer %s\r\n"
          "Content-Type: application/json\r\n"
          "Content-Length: %lu\r\n\r\n%s",
          info->ip, info->key, strlen(payload), payload);

  int total = strlen(message);
  int sent = 0;
  while (sent < total) {
    int bytes = write(sockfd, message + sent, total - sent);
    if (bytes < 0) {
      fprintf(stderr, "ERROR: %s\n", strerror(errno));
      fprintf(stderr, "Comm Thread: Error writing to socket\n");
    }
    if (bytes == 0)
      break;
    sent += bytes;
  }
  free(message);

  // Read response
  char response_buf[BUFSIZ] = {0};
  char *response = safe_alloc(BUFSIZ);
  while (read(sockfd, response_buf, BUFSIZ) > 0) {
    int len = strlen(response_buf) + strlen(response);
    char *tmp = safe_alloc(len + 1);

    strcpy(tmp, response);
    free(response);
    strcat(tmp, response_buf);
    response = tmp;

    if (len == BUFSIZ)
      memset(response_buf, 0, BUFSIZ);
    else
      break;
  }

  if (strlen(response) == 0)
    fprintf(stderr, "Pinged server and got no response\n");
  else
    printf("Pinged server with %lu bytes\n", strlen(payload));

  close(sockfd);
  free(response);
  return true;
}
