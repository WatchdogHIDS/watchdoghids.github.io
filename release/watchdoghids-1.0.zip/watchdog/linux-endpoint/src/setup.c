#include "setup.h"
#include "helper.h"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/random.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <ctype.h>

bool setup()
{
  // Ask the user to specify a port or default to 0 to let host decide
  int port_num = 0;
  char port_input[10];

  printf("Enter port number (default is 0 to let the system choose): ");
  if (fgets(port_input, sizeof(port_input), stdin) != NULL)
  {
    if (port_input[0] != '\n')
    { // If user provides a port
      port_num = strtol(port_input, NULL, 10);
      if (port_num <= 0 || port_num > 65535)
      {
        printf("Invalid port number, defaulting to 0.\n");
        port_num = 0;
      }
    }
  }

  FILE *config_file = fopen("/etc/watchdog-endpoint/config", "w");
  if (config_file == NULL)
  {
    fprintf(stderr, "Could not write config file\n");
    return false;
  }

  // Generate and write random key
  char *key = gen_key();
  fwrite("key=", 1, 4, config_file);
  fwrite(key, 1, 64, config_file);
  fwrite("\n", 1, 1, config_file);

  // Setup listen for connection
  int sockfd = 0;
  struct sockaddr_in addr;
  socklen_t addr_len = sizeof(addr);

  if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Could not open socket\n");
    return false;
  }

  int opt = 1;
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

  addr.sin_family = AF_INET;
  addr.sin_port = htons(port_num); // auto port
  addr.sin_addr.s_addr = INADDR_ANY;

  if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
  {
    perror("bind");
    return false;
  }

  // Get IP:PORT for socket
  if (getsockname(sockfd, (struct sockaddr *)&addr, &addr_len) < 0)
  {
    fprintf(stderr, "getsockname failed\n");
    return false;
  }

  // Listen for incoming connection
  pcap_if_t *devs = NULL;
  int port = ntohs(addr.sin_port);
  char *ip = NULL;

  pcap_findalldevs(&devs, NULL);
  if (devs && devs->addresses)
  {
    for (pcap_addr_t *a = devs->addresses; a != NULL; a = a->next)
    {
      if (a->addr && a->addr->sa_family == AF_INET)
      {
        ip = inet_ntoa(((struct sockaddr_in *)a->addr)->sin_addr);
        break;
      }
    }
  }

  if (ip == NULL)
  {
    fprintf(stderr, "Could not find default network device IP\n");
    return false;
  }

  printf("Please register this endpoint on your central server using the "
         "web-interface:\n");
  printf("Address: %s:%d\n", ip, port);
  printf("Key: %s\n\n", key);

  listen(sockfd, 1);
  printf("Waiting for connection...\n");

  // Accept incoming connection
  struct sockaddr_in conn_addr;
  socklen_t conn_addr_len = sizeof(conn_addr);
  int connfd = accept(sockfd, (struct sockaddr *)&conn_addr, &conn_addr_len);
  close(sockfd);

  if (connfd < 0)
  {
    fprintf(stderr, "Could not accept connection.\n");
    return false;
  }

  // Wait to recieve key
  printf("Connection Accepted, verifying...\n");

  char response_buf[BUFSIZ];
  char *response = safe_alloc(BUFSIZ);
  memset(response, 0, BUFSIZ);
  while (read(connfd, response_buf, BUFSIZ) > 0)
  {
    int len = strlen(response_buf) + strlen(response);
    char *tmp = safe_alloc(len + 1);
    memset(tmp, 0, len + 1);

    strcpy(tmp, response);
    free(response);
    strcat(tmp, response_buf);
    response = tmp;

    if (len == BUFSIZ)
      memset(response_buf, 0, BUFSIZ);
    else
      break;
  }

  // Check key
  if (strstr(response, key))
  {
    int server_port_int = extract_port_from_request(response);
    if (server_port_int < 0)
    {
      fprintf(stderr, "No valid server port provided\n");
      if (write_http_response(connfd, "No valid server port provided\n", 400) < 0)
      {
        fprintf(stderr, "Error sending HTTP response\n");
        return false;
      }
      return false;
    }
    free(response);
    printf("Server verified successfully\n");

    // Get server info
    if (getpeername(connfd, (struct sockaddr *)&conn_addr, &conn_addr_len) !=
        0)
    {
      fprintf(stderr, "Could not get server information\n");
      if (write_http_response(connfd, "There was an error getting server info\n", 400) < 0)
      {
        fprintf(stderr, "Error sending HTTP response\n");
        return false;
      }
      return false;
    }

    if (write_http_response(connfd, "success\n", 200) < 0)
    {
      fprintf(stderr, "Error sending HTTP response\n");
      return false;
    }
    close(connfd);

    char *server_port = safe_alloc(BUFSIZ);
    sprintf(server_port, "%d", server_port_int);
    char *server_ip = inet_ntoa(conn_addr.sin_addr);
    printf("Server is at: %s:%s\n", server_ip, server_port);

    // Ask for additional config
    int timer = 10;
    char *watch_dirs = NULL;
    char *buf = safe_alloc(BUFSIZ);

    printf("Entering Configuration Wizard:\n");

    printf("Enter scan timer (10):");
    buf = fgets(buf, BUFSIZ, stdin);
    if (buf != NULL)
    {
      if (strcmp("\n", buf))
      {
        int new_time = strtol(buf, NULL, 10);
        if (new_time != 0)
          timer = new_time;
        memset(buf, 0, strlen(buf));
      }
    }

    printf("Enter directories to watch as a comma seperated list (defaults):");

    if (buf != NULL)
      free(buf);
    buf = safe_alloc(BUFSIZ);
    buf = fgets(buf, BUFSIZ, stdin);

    if (buf != NULL)
    {
      if (strcmp(buf, "\n"))
      {
        watch_dirs = safe_alloc(strlen(buf) + 1);
        memcpy(watch_dirs, buf, strlen(buf));
      }
    }

    // Write relevant info
    printf("Writing to config file...\n");

    fwrite("ip=", 1, 3, config_file);
    fwrite(server_ip, 1, strlen(server_ip), config_file);
    fwrite("\n", 1, 1, config_file);

    fwrite("port=", 1, 5, config_file);
    fwrite(server_port, 1, strlen(server_port), config_file);
    fwrite("\n", 1, 1, config_file);

    char *timer_str = safe_alloc(BUFSIZ);
    sprintf(timer_str, "%d", timer);
    fwrite("timer=", 1, 6, config_file);
    fwrite(timer_str, 1, strlen(timer_str), config_file);
    free(timer_str);
    fwrite("\n", 1, 1, config_file);

    fwrite("dirs=", 1, 5, config_file);
    if (watch_dirs != NULL)
    {
      fwrite(watch_dirs, 1, strlen(watch_dirs), config_file);
    }
    else
    {
      struct stat cur_dir;
      if (stat("/etc", &cur_dir) == 0)
        fwrite("/etc", 1, 4, config_file);
      if (stat("/home", &cur_dir))
        fwrite(",/home", 1, 6, config_file);
    }
    fwrite("\n", 1, 1, config_file);
    fclose(config_file);
  }
  else
  {
    if (write_http_response(connfd, "Key not found\n", 400) < 0)
    {
      fprintf(stderr, "Error sending HTTP response\n");
      return false;
    }
    close(connfd);
    fprintf(stderr, "Server failed to verify identity\nresponse:\n%s\n",
            response);
    return false;
  }

  return true;
}

char random_char(int index)
{
  char charset[] =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  return charset[index];
}

char *gen_key()
{
  printf("Generating random key...\n");

  srand(time(NULL));
  char *str = safe_alloc(65);
  for (int i = 0; i < 64; i++)
  {
    int index = rand() % 62;
    str[i] = random_char(index);
  }
  str[64] = '\0';

  printf("Key Generated\n\n");
  return str;
}

int write_http_response(int sockfd, const char *msg, int status)
{
  const char *status_msg;

  switch (status)
  {
  case 200:
    status_msg = "OK";
    break;
  case 400:
    status_msg = "Bad Request";
    break;
  }

  char response[2048];
  int num_bytes = snprintf(response, sizeof(response),
                           "HTTP/1.1 %d %s\r\n"
                           "Content-Type: text/plain\r\n"
                           "Content-Length: %zu\r\n"
                           "Connection: close\r\n"
                           "\r\n"
                           "%s",
                           status, status_msg,
                           strlen(msg), msg);

  if (num_bytes < 0)
  {
    return -1;
  }

  if (write(sockfd, response, num_bytes) < 0)
  {
    return -1;
  }

  return 0;
}

int extract_port_from_request(const char *request)
{
  char *start = strstr(request, "\"port\":");
  if (!start)
  {
    return -1;
  }

  start = strchr(start, ':');
  if (!start)
  {
    return -1; // Malformed JSON
  }

  start++;

  while (*start == ' ' || *start == '"')
  {
    start++;
  }

  char port_str[6];
  int i = 0;

  while(isdigit(start[i]) && i<sizeof(port_str) - 1){
    port_str[i] = start[i];
    i++;
  }
  port_str[i] = '\0';
  fprintf(stderr, port_str);
  int port = atoi(port_str);
  return port;
}