#include "resource.h"
#include "helper.h"
#include "uthash.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

static int *resource_pipe = NULL;

struct cJSON *rcrs_to_json(struct resource *rcrs) {
  cJSON *object = cJSON_CreateObject();
  cJSON *resource_data = cJSON_CreateObject();

  struct resource *cur_rcr = rcrs;
  while (cur_rcr != NULL) {
    cJSON *p = cJSON_CreateObject();

    cJSON_AddStringToObject(p, "cpu", cur_rcr->cpu);
    cJSON_AddStringToObject(p, "mem", cur_rcr->mem);
    cJSON_AddStringToObject(p, "time", cur_rcr->time);

    char pid_str[100];
    sprintf(pid_str, "%d", cur_rcr->pid);
    cJSON_AddItemToObject(resource_data, pid_str, p);
    cur_rcr = cur_rcr->hh.next;
  }

  cJSON_AddItemToObject(object, "ResourceData", resource_data);
  return object;
}

void sync_rcrs(struct resource *rcrs) {
  // Get json
  struct cJSON *json = rcrs_to_json(rcrs);
  char *json_str = cJSON_Print(json);

  // Write to pipe
  int write_count = write(resource_pipe[1], json_str, strlen(json_str));
  write_count += write(resource_pipe[1], "\0", 1);

  if (write_count != strlen(json_str) + 1) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Resource Thread: Error writing to pipe\n");
    exit(EXIT_FAILURE);
  }

  // Clean up
  free(json_str);
  cJSON_Delete(json);
  struct resource *cur, *tmp;
  HASH_ITER(hh, rcrs, cur, tmp) {
    HASH_DEL(rcrs, cur);
    free(cur->cpu);
    free(cur->mem);
    free(cur->time);
    free(cur);
  }

  return;
}

void resource_capture_setup(int *fds) { resource_pipe = fds; }

void *resource_capture(void *args) {
  struct resource *rcrs = NULL;

  // Run top
  pid_t pid = fork();
  if (pid == 0) {
    int top_pid =
        system("top -w 512 -b -n 1 > /etc/watchdog-endpoint/cache/top");
    waitpid(top_pid, NULL, 0);
    exit(EXIT_SUCCESS);
  }

  // Open top output
  waitpid(pid, NULL, 0);
  FILE *top = fopen("/etc/watchdog-endpoint/cache/top", "r");

  // Skip header lines and top line
  char *line = NULL;
  size_t size = 512;
  int read = 0;
  for (int i = 0; i < 8; i++) {
    read = getline(&line, &size, top);
    free(line);
    line = NULL;
  }

  // Read procs
  while ((read = getline(&line, &size, top)) > 0) {
    struct resource *cur = safe_alloc(sizeof(struct resource));
    memset(cur, 0, sizeof(struct resource));

    // PID
    char *token = strtok(line, " ");
    if (token == NULL) {
      free(line);
      line = NULL;
      continue;
    }
    int cur_pid = strtol(token, NULL, 10);
    cur->pid = cur_pid;

    // UID,PR,NI,VIRT,RES,SHR,S
    for (int i = 0; i < 7; i++)
      token = strtok(NULL, " ");

    // CPU
    token = strtok(NULL, " ");
    if (token == NULL) {
      free(line);
      line = NULL;
      continue;
    }
    cur->cpu = safe_alloc(strlen(token) + 1);
    memset(cur->cpu, 0, strlen(token) + 1);
    memcpy(cur->cpu, token, strlen(token));

    // MEM
    token = strtok(NULL, " ");
    if (token == NULL) {
      free(line);
      line = NULL;
      continue;
    }
    cur->mem = safe_alloc(strlen(token) + 1);
    memset(cur->mem, 0, strlen(token) + 1);
    memcpy(cur->mem, token, strlen(token));

    // TIME
    token = strtok(NULL, " ");
    if (token == NULL) {
      free(line);
      line = NULL;
      continue;
    }
    cur->time = safe_alloc(strlen(token) + 1);
    memset(cur->time, 0, strlen(token) + 1);
    memcpy(cur->time, token, strlen(token));

    // Add to hashmap
    if (strcmp(cur->time, "0:00.00") || strcmp(cur->cpu, "0.0") ||
        strcmp(cur->mem, "0.0"))
      HASH_ADD_INT(rcrs, pid, cur);
    else
      free(cur);

    // Clean up
    free(line);
    line = NULL;
  }
  fclose(top);

  sync_rcrs(rcrs);
  return NULL;
}
