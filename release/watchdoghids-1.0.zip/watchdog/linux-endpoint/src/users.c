#include "users.h"
#include "cjson/cJSON.h"
#include "helper.h"
#include "uthash.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <wait.h>

int *users_pipe = NULL;

void users_capture_setup(int *fds) { users_pipe = fds; }

void *users_capture(void *args) {
  // Get cache
  struct user *users = load_users();
  struct group *groups = load_groups();
  struct login *logins = load_logins();

  // Hashtables for sync
  struct user *new_users = NULL;
  struct group *new_groups = NULL;
  struct login *new_logins = NULL;

  // Files
  FILE *etc_passwd = fopen("/etc/passwd", "r");
  if (etc_passwd == NULL) {
    return NULL;
  }

  // users
  char *line = safe_alloc(BUFSIZ);
  while ((line = fgets(line, BUFSIZ, etc_passwd)) != NULL) {
    char *name = strtok(line, ":");
    char *exec = strtok(NULL, ":");
    char *uid = strtok(NULL, ":");

    if (name == NULL || exec == NULL || uid == NULL)
      continue;

    if (!strcmp(exec, "x")) {
      struct user *user;
      int uid_i = strtol(uid, NULL, 10);
      HASH_FIND_INT(users, &uid_i, user);
      if (user == NULL) {
        user = safe_alloc(sizeof(struct user));
        user->uid = uid_i;
        user->name = safe_alloc(strlen(name) + 1);
        memcpy(user->name, name, strlen(name));

        struct user *user_cpy = safe_alloc(sizeof(struct user));
        memcpy(user_cpy, user, sizeof(struct user));

        HASH_ADD_INT(users, uid, user);
        HASH_ADD_INT(new_users, uid, user_cpy);
      }
    }
  }
  fclose(etc_passwd);

  // groups
  FILE *etc_group = fopen("/etc/group", "r");
  if (etc_group != NULL) {
    free(line);
    line = safe_alloc(BUFSIZ);

    while ((line = fgets(line, BUFSIZ, etc_group)) != NULL) {
      char *name = strtok(line, ":");
      char *exec = strtok(NULL, ":");
      char *gid = strtok(NULL, ":");
      char *members = strtok(NULL, ":");

      if (name == NULL || exec == NULL || gid == NULL)
        continue;

      if (!strcmp(exec, "x")) {
        int gid_i = strtol(gid, NULL, 10);
        struct group *group;
        HASH_FIND_INT(groups, &gid_i, group);
        if (group == NULL) {
          group = safe_alloc(sizeof(struct group));
          group->gid = gid_i;
          group->name = safe_alloc(strlen(name) + 1);
          memcpy(group->name, name, strlen(name));

          if (members != NULL) {
            char *member = strtok(members, ",");
            int cur_member = 0;
            while (member != NULL && strcmp(member, "\n")) {
              struct user *cur_user, *tmp;
              HASH_ITER(hh, users, cur_user, tmp) {
                if (!strcmp(cur_user->name, member)) {
                  int *tmp = NULL;
                  while (tmp == NULL)
                    tmp = realloc(group->uids, sizeof(int) * (cur_member + 1));
                  group->uids = tmp;

                  group->uids[cur_member] = cur_user->uid;
                  cur_member += 1;
                }
              }
              member = strtok(NULL, ",");
            }
            group->uids_size = cur_member;
          } else {
            group->uids_size = 0;
          }

          struct group *group_cpy = safe_alloc(sizeof(struct group));
          memcpy(group_cpy, group, sizeof(struct group));

          HASH_ADD_INT(groups, gid, group);
          HASH_ADD_INT(new_groups, gid, group_cpy);
        }
      }
    }
    fclose(etc_group);
  }

  // logins
  // Run last
  pid_t pid = fork();
  if (pid == 0) {
    int last_pid = system(
        "last -d --time-format iso | tac > /etc/watchdog-endpoint/cache/last");
    waitpid(last_pid, NULL, 0);
    exit(EXIT_SUCCESS);
  }

  // Read last output
  waitpid(pid, NULL, 0);
  FILE *last = fopen("/etc/watchdog-endpoint/cache/last", "r");
  if (last != NULL) {
    free(line);
    line = safe_alloc(BUFSIZ);

    while ((line = fgets(line, BUFSIZ, last)) != NULL) {
      char *user = strtok(line, " \n");
      if (user == NULL || !strcmp(user, "reboot"))
        continue;

      char *tty = strtok(NULL, " ");
      char *ip = strtok(NULL, " ");
      char *start = strtok(NULL, " ");
      char *dash = strtok(NULL, " ");
      char *end = strtok(NULL, " ");

      if (tty == NULL || ip == NULL || start == NULL || end == NULL ||
          dash == NULL)
        continue;
      if (strcmp(dash, "-"))
        continue;

      struct login *login;
      HASH_FIND_STR(logins, start, login);
      if (login == NULL) {
        login = safe_alloc(sizeof(struct login));
        login->key = safe_alloc(strlen(start) + 1);
        memcpy(login->key, start, strlen(start));
        login->ip = safe_alloc(strlen(ip) + 1);
        memcpy(login->ip, ip, strlen(ip));

        struct user *cur, *tmp;
        HASH_ITER(hh, users, cur, tmp) {
          if (!strcmp(user, cur->name)) {
            login->uid = cur->uid;
            break;
          }
        }

        char *start_date = strtok(start, "T");
        char *start_time = strtok(NULL, "T");
        if (start_date == NULL || start_time == NULL) {
          free(login);
          continue;
        }
        login->date_start = safe_alloc(strlen(start_date) + 1);
        login->time_start = safe_alloc(strlen(start_time) + 1);
        memcpy(login->date_start, start_date, strlen(start_date));
        memcpy(login->time_start, start_time, strlen(start_time));

        if (!strcmp(end, "still")) {
          login->date_end = safe_alloc(3);
          login->time_end = safe_alloc(3);
          memcpy(login->date_end, "NA", 2);
          memcpy(login->time_end, "NA", 2);
        } else if (!strcmp(end, "crash")) {
          login->date_end = safe_alloc(6);
          login->time_end = safe_alloc(6);
          memcpy(login->date_end, "crash", 5);
          memcpy(login->time_end, "crash", 5);
        } else {
          char *end_date = strtok(end, "T");
          char *end_time = strtok(NULL, "T");
          if (end_date == NULL || end_time == NULL) {
            free(login);
            continue;
          }
          login->date_end = safe_alloc(strlen(end_date) + 1);
          login->time_end = safe_alloc(strlen(end_time) + 1);
          memcpy(login->date_end, end_date, strlen(end_date));
          memcpy(login->time_end, end_time, strlen(end_time));
        }
        struct login *login_cpy = safe_alloc(sizeof(struct login));
        memcpy(login_cpy, login, sizeof(struct login));

        HASH_ADD_STR(logins, key, login);
        HASH_ADD_STR(new_logins, key, login_cpy);
      }
    }
    fclose(last);
  }

  // sync
  if (new_users != NULL || new_groups != NULL || new_logins != NULL) {
    cJSON *obj = cJSON_CreateObject();
    if (new_users != NULL) {
      cJSON *user_data = cJSON_CreateObject();
      struct user *cur_user, *tmp;
      HASH_ITER(hh, new_users, cur_user, tmp) {
        user_to_json(user_data, cur_user);
        HASH_DEL(new_users, cur_user);
        free(cur_user);
      }
      cJSON_AddItemToObject(obj, "UserData", user_data);
    }
    if (new_groups != NULL) {
      cJSON *group_data = cJSON_CreateObject();
      struct group *cur_group, *tmp;
      HASH_ITER(hh, new_groups, cur_group, tmp) {
        group_to_json(group_data, cur_group);
        HASH_DEL(new_groups, cur_group);
        free(cur_group);
      }
      cJSON_AddItemToObject(obj, "GroupData", group_data);
    }
    if (new_logins != NULL) {
      cJSON *login_data = cJSON_CreateObject();
      struct login *cur_login, *tmp;
      HASH_ITER(hh, new_logins, cur_login, tmp) {
        login_to_json(login_data, cur_login);
        HASH_DEL(new_logins, cur_login);
        free(cur_login);
      }
      cJSON_AddItemToObject(obj, "LoginData", login_data);
    }
    char *json_str = cJSON_Print(obj);
    cJSON_Delete(obj);

    sync_users(json_str);
    free(json_str);
    cache_users(users, groups, logins);
  }

  return NULL;
}

void sync_users(char *json) {
  if (json == NULL)
    return;

  // Write to pipe
  int write_count = write(users_pipe[1], json, strlen(json));
  write_count += write(users_pipe[1], "\0", 1);

  if (write_count != strlen(json) + 1) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Users Thread: Error writing to pipe\n");
    exit(EXIT_FAILURE);
  }

  return;
}

void user_to_json(cJSON *object, struct user *user) {
  cJSON *user_object = cJSON_CreateObject();

  // name
  cJSON_AddStringToObject(user_object, "name", user->name);

  // uid
  char uid[100];
  sprintf(uid, "%d", user->uid);
  cJSON_AddItemToObject(object, uid, user_object);
}

void group_to_json(cJSON *object, struct group *group) {
  cJSON *group_object = cJSON_CreateObject();
  cJSON_AddStringToObject(group_object, "name", group->name);

  char gid[100];
  sprintf(gid, "%d", group->gid);

  // uids
  cJSON *uids = cJSON_AddArrayToObject(group_object, "members");
  for (int i = 0; i < group->uids_size; i++) {
    cJSON *uid = cJSON_CreateNumber(group->uids[i]);
    cJSON_AddItemToArray(uids, uid);
  }

  cJSON_AddItemToObject(object, gid, group_object);
}

void login_to_json(cJSON *object, struct login *login) {
  cJSON *login_object = cJSON_CreateObject();
  cJSON_AddNumberToObject(login_object, "uid", login->uid);
  cJSON_AddStringToObject(login_object, "ip", login->ip);
  cJSON_AddStringToObject(login_object, "date_start", login->date_start);
  cJSON_AddStringToObject(login_object, "time_start", login->time_start);
  cJSON_AddStringToObject(login_object, "date_end", login->date_end);
  cJSON_AddStringToObject(login_object, "time_end", login->time_end);

  cJSON_AddItemToObject(object, login->key, login_object);
}

struct user *json_to_users(struct cJSON *json) {
  struct user *users = NULL;

  struct cJSON *cur = json->child;
  while (cur != NULL) {
    struct user *user = safe_alloc(sizeof(struct user));
    user->uid = strtol(cur->string, NULL, 10);
    user->name = safe_alloc(strlen(cur->child->valuestring) + 1);
    strcpy(user->name, cur->child->valuestring);

    HASH_ADD_INT(users, uid, user);
    cur = cur->next;
  }
  return users;
}

struct group *json_to_groups(struct cJSON *json) {
  struct group *groups = NULL;

  struct cJSON *cur = json->child;
  while (cur != NULL) {
    struct group *group = safe_alloc(sizeof(struct group));
    group->gid = strtol(cur->string, NULL, 10);
    group->name = safe_alloc(strlen(cur->child->valuestring) + 1);
    strcpy(group->name, cur->child->valuestring);
    group->uids =
        safe_alloc(sizeof(int *) * cJSON_GetArraySize(cur->child->next));

    struct cJSON *elem = NULL;
    cJSON_ArrayForEach(elem, cur->child->next) {
      group->uids[group->uids_size] = cJSON_GetNumberValue(elem);
      group->uids_size += 1;
    }

    HASH_ADD_INT(groups, gid, group);
    cur = cur->next;
  }

  return groups;
}

struct login *json_to_logins(struct cJSON *json) {
  struct login *logins = NULL;

  struct cJSON *cur = json->child;
  while (cur != NULL) {
    struct login *login = safe_alloc(sizeof(struct login));
    struct cJSON *working = NULL;
    login->key = safe_alloc(strlen(cur->string) + 1);
    strcpy(login->key, cur->string);

    working = cur->child;
    login->uid = cJSON_GetNumberValue(working);

    working = working->next;
    login->ip = safe_alloc(strlen(working->valuestring) + 1);
    strcpy(login->ip, working->valuestring);

    working = working->next;
    login->date_start = safe_alloc(strlen(working->valuestring) + 1);
    strcpy(login->date_start, working->valuestring);

    working = working->next;
    login->time_start = safe_alloc(strlen(working->valuestring) + 1);
    strcpy(login->time_start, working->valuestring);

    working = working->next;
    login->date_end = safe_alloc(strlen(working->valuestring) + 1);
    strcpy(login->date_end, working->valuestring);

    working = working->next;
    login->time_end = safe_alloc(strlen(working->valuestring) + 1);
    strcpy(login->time_end, working->valuestring);

    HASH_ADD_STR(logins, key, login);
    cur = cur->next;
  }
  return logins;
}

struct user *load_users() {
  char *json_str = read_file("/etc/watchdog-endpoint/cache/users");
  if (json_str == NULL)
    return NULL;
  struct cJSON *json = cJSON_Parse(json_str);
  struct user *users = json_to_users(json);
  cJSON_free(json);
  free(json_str);
  return users;
}

struct group *load_groups() {
  char *json_str = read_file("/etc/watchdog-endpoint/cache/groups");
  if (json_str == NULL)
    return NULL;
  struct cJSON *json = cJSON_Parse(json_str);
  struct group *groups = json_to_groups(json);
  cJSON_free(json);
  free(json_str);
  return groups;
}

struct login *load_logins() {
  char *json_str = read_file("/etc/watchdog-endpoint/cache/logins");
  if (json_str == NULL)
    return NULL;
  struct cJSON *json = cJSON_Parse(json_str);
  struct login *logins = json_to_logins(json);
  cJSON_free(json);
  free(json_str);
  return logins;
}

void cache_users(struct user *users, struct group *groups,
                 struct login *logins) {
  // users
  if (users != NULL) {
    FILE *users_cache = fopen("/etc/watchdog-endpoint/cache/users", "w");

    struct cJSON *users_json = cJSON_CreateObject();
    struct user *cur_user, *tmp;

    HASH_ITER(hh, users, cur_user, tmp) { user_to_json(users_json, cur_user); }

    char *users_str = cJSON_Print(users_json);
    fwrite(users_str, 1, strlen(users_str), users_cache);
    fclose(users_cache);
  }

  // groups
  if (groups != NULL) {
    FILE *groups_cache = fopen("/etc/watchdog-endpoint/cache/groups", "w");

    struct cJSON *groups_json = cJSON_CreateObject();
    struct group *cur_group, *tmp;

    HASH_ITER(hh, groups, cur_group, tmp) {
      group_to_json(groups_json, cur_group);
    }

    char *groups_str = cJSON_Print(groups_json);
    fwrite(groups_str, 1, strlen(groups_str), groups_cache);
    fclose(groups_cache);
  }

  // logins
  if (logins != NULL) {
    FILE *logins_cache = fopen("/etc/watchdog-endpoint/cache/logins", "w");

    struct cJSON *logins_json = cJSON_CreateObject();
    struct login *cur_login, *tmp;

    HASH_ITER(hh, logins, cur_login, tmp) {
      login_to_json(logins_json, cur_login);
    }

    char *logins_str = cJSON_Print(logins_json);
    fwrite(logins_str, 1, strlen(logins_str), logins_cache);
    fclose(logins_cache);
  }
}
