#include "comms.h"
#include "file.h"
#include "helper.h"
#include "network.h"
#include "procs.h"
#include "resource.h"
#include "setup.h"
#include "users.h"
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#define NUM_THREADS 5

struct server_info server_info;

static int *fds[NUM_THREADS];
static pthread_t threads[NUM_THREADS];
static sig_atomic_t status = -1;

void comm_exit(char *);
bool comm_recover(FILE *);

void exit_handler(int signo) { status = 1; }

/**
 * @brief Work loop for the comm thread
 * @details Reads data on all pipes and calls post
 *          to server for each json object
 * @return NA
 */
void comm_loop() {
  for (;;) {
    for (int i = 0; i < NUM_THREADS; i++) {
      int fd = fds[i][0];
      fcntl(fd, F_SETFL, O_NONBLOCK);

      int num = 0;
      char *msg = safe_alloc(BUFSIZ);
      char *buf = safe_alloc(BUFSIZ);

      while ((num = read(fds[i][0], buf, BUFSIZ)) != 0) {
        if (num == -1 && errno == EAGAIN)
          break;

        int len = strlen(msg) + num + 1;
        msg = safe_realloc_str(msg, len);

        int i = 0;
        int start = 0;
        while (i < num) {
          if (buf[i] != '\0') {
            i += 1;
            continue;
          }

          strncat(msg, buf + start, i - start);
          start = i + 1;
          i += 2;
          if (!post_server(msg, &server_info)) {
            bool sent = false;
            while (!sent) {
              printf("Will try to reconnect in 10s\n");
              sleep(10);
              sent = post_server(msg, &server_info);
              if (status != -1 && !sent)
                comm_exit(msg);
            }
          }
          memset(msg, 0, strlen(msg));
        }
        if (start + 1 != i)
          strncat(msg, buf + start, i - start);

        memset(buf, 0, BUFSIZ);
      }

      free(buf);
      free(msg);
    }
  }
}

void comm_exit(char *missed_payload) {
  printf("Exiting and stashing...\n");
  FILE *comm_stash = fopen("/etc/watchdog-endpoint/cache/comm", "a");
  fwrite(missed_payload, 1, strlen(missed_payload), comm_stash);
  fwrite("|", 1, 1, comm_stash);

  for (int i = 0; i < NUM_THREADS; i++) {
    int fd = fds[i][0];
    fcntl(fd, F_SETFL, O_NONBLOCK);

    int num = 0;
    char *msg = safe_alloc(BUFSIZ);
    char *buf = safe_alloc(BUFSIZ);

    while ((num = read(fds[i][0], buf, BUFSIZ)) != 0) {
      if (num == -1 && errno == EAGAIN)
        break;

      int len = strlen(msg) + num + 1;
      msg = safe_realloc_str(msg, len);

      int i = 0;
      int start = 0;
      while (i < num) {
        if (buf[i] != '\0') {
          i += 1;
          continue;
        }

        strncat(msg, buf + start, i - start);
        start = i + 1;
        i += 2;

        fwrite(msg, 1, strlen(msg), comm_stash);
        fwrite("|", 1, 1, comm_stash);
        memset(msg, 0, strlen(msg));
      }
      if (start + 1 != i)
        strncat(msg, buf + start, i - start);

      memset(buf, 0, BUFSIZ);
    }

    free(buf);
    free(msg);
  }
  fclose(comm_stash);
  exit(EXIT_SUCCESS);
}

bool comm_recover(FILE *f) {
  int num = 0;
  char *msg = safe_alloc(BUFSIZ);
  char *buf = safe_alloc(BUFSIZ);

  while ((num = fread(buf, 1, BUFSIZ, f)) > 0) {
    int len = strlen(msg) + num + 1;
    msg = safe_realloc_str(msg, len);

    int i = 0;
    int start = 0;
    while (i < num) {
      if (buf[i] != '|') {
        i += 1;
        continue;
      }

      strncat(msg, buf + start, i - start);
      start = i + 1;
      i += 2;
      if (!post_server(msg, &server_info)) {
        fclose(f);
        return false;
      }
      memset(msg, 0, strlen(msg));
    }
    if (start + 1 != i)
      strncat(msg, buf + start, i - start);

    memset(buf, 0, BUFSIZ);
  }

  fclose(f);
  remove("/etc/watchdog-endpoint/cache/comm");

  free(buf);
  free(msg);
  return true;
}

/**
 * @brief Main method for endpoint
 * @details Creates and manages threads for each relevant service,
 *  Handles exiting and thread signals
 * @return Program exit status (0)
 */
int main(int argc, char *argv[]) {
  if (argc > 1) {
    for (int i = 1; i < argc; i++) {
      char *cur_arg = argv[i];
      if (strlen(cur_arg) < 2) {
        fprintf(stderr, "Unknown arg: '%s'\n", cur_arg);
        exit(EXIT_FAILURE);
      }

      if (!strncmp(cur_arg, "-s", 2) || !strncmp(cur_arg, "--setup", 7)) {
        if (setup()) {
          printf("Service setup succuess\n");
          exit(EXIT_SUCCESS);
        }
        fprintf(stderr, "Failed to setup service\n");
        exit(EXIT_FAILURE);
      } else if (!strncmp(cur_arg, "-r", 2) ||
                 !strncmp(cur_arg, "--reset", 7)) {
        printf("Deleting Config...\n");
        fflush(stdout);
        if (remove("/etc/watchdog-endpoint/config") == 0) {
          printf("Config file removed\n");
        } else {
          fprintf(stderr, "Could not remove config file\n");
        }

        printf("Deleting Cache...\n");
        fflush(stdout);
        if (system("sudo rm -rf /etc/watchdog-endpoint/cache/*") == 0) {
          printf("Cache was cleaned\n");
          exit(EXIT_SUCCESS);
        } else {
          fprintf(stderr, "Could not clean cache\n");
          exit(EXIT_FAILURE);
        }

      } else {
        printf("Unknown arg: '%s'\n", cur_arg);
        exit(EXIT_FAILURE);
      }
    }
  }
  struct stat st = {0};
  if (stat("/etc/watchdog-endpoint", &st) == -1) {
    mkdir("/etc/watchdog-endpoint", 0700);
  }
  if (stat("/etc/watchdog-endpoint/cache", &st) == -1) {
    mkdir("/etc/watchdog-endpoint/cache", 0700);
  }

  FILE *config_file = fopen("/etc/watchdog-endpoint/config", "r");
  if (config_file == NULL) {
    config_file = fopen("/etc/watchdog-endpoint/config", "w");
    if (config_file == NULL) {
      fprintf(stderr, "Could not write config file\n");
      exit(EXIT_FAILURE);
    }

    printf("No config detected: please run with '-s' or '--setup' to launch "
           "the setup wizard\n");
    exit(EXIT_FAILURE);
  } else {
    printf("Config detected: reading config\n");
    server_info.ip = NULL;
    server_info.port = 0;
    server_info.key = NULL;
    server_info.timer = 10;

    size_t len = BUFSIZ;
    char *line = safe_alloc(len);
    ssize_t read = 0;
    while ((read = getline(&line, &len, config_file)) != -1) {
      if (!strncmp(line, "ip=", 3)) {
        server_info.ip = safe_alloc(strlen(line) - 2);
        memset(server_info.ip, 0, strlen(line) - 2);
        memcpy(server_info.ip, line + 3, strlen(line) - 4);
      } else if (!strncmp(line, "port=", 5)) {
        server_info.port = strtol(line + 5, NULL, 10);
      } else if (!strncmp(line, "timer=", 6)) {
        server_info.timer = strtol(line + 6, NULL, 10);
      } else if (!strncmp(line, "key=", 4)) {
        server_info.key = safe_alloc(strlen(line) - 3);
        memset(server_info.key, 0, strlen(line) - 3);
        memcpy(server_info.key, line + 4, strlen(line) - 5);
      } else if (!strncmp(line, "dirs=", 5)) {
        char *cur_dir = strtok(line + 5, ",\n");
        while (cur_dir != NULL && !strncmp(cur_dir, "/", 1)) {
          server_info.dirs_size += 1;
          if (server_info.dirs_size == 1025) {
            fprintf(stderr, "Number of watch dirs is > 1024\n");
            exit(EXIT_FAILURE);
          }

          char *dir = safe_alloc(strlen(cur_dir) + 1);
          memcpy(dir, cur_dir, strlen(cur_dir));
          server_info.dirs[server_info.dirs_size - 1] = dir;

          cur_dir = strtok(NULL, ",\n");
        }
      } else if (!strncmp(line, "\n", 1)) {
        continue;
      } else {
        fprintf(stderr, "Unexpected line in config: %s", line);
        exit(EXIT_FAILURE);
      }
    }
    free(line);

    if (server_info.ip == NULL) {
      fprintf(stderr, "Config file missing ip\n");
      exit(EXIT_FAILURE);
    }
    if (server_info.port == 0) {
      fprintf(stderr, "Config file missing port\n");
      exit(EXIT_FAILURE);
    }
    if (server_info.key == NULL) {
      fprintf(stderr, "Config file missing key\n");
      exit(EXIT_FAILURE);
    }
    if (server_info.dirs_size == 0) {
      fprintf(stderr, "Config file missing dirs\n");
    }
  }

  printf("Configured to use server: %s:%d\n", server_info.ip, server_info.port);

  // Look for stashed changes
  FILE *comm_stash = fopen("/etc/watchdog-endpoint/cache/comm", "r");
  if (comm_stash != NULL) {
    printf("Found stashed records, attempting to transmit...\n");
    bool res = comm_recover(comm_stash);
    if (res)
      printf("Stashed records transmitted\n\n");
    else {
      printf("Failed to send stashed records, Please fix issues with server "
             "and restart\n");
      exit(EXIT_FAILURE);
    }
  }

  // Threads
  memset(threads, 0, sizeof(pthread_t) * NUM_THREADS);

  // Networking Thread
  int network_fds[2];
  if (pipe(network_fds)) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Error opening pipe.\n");
    exit(EXIT_FAILURE);
  }
  setup_network_capture(network_fds);
  printf("Network Thread: configured\n");
  fds[0] = network_fds;
  threads[0] = 0;

  // Procs thread
  int procs_fds[2];
  if (pipe(procs_fds)) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Error opening pipe.\n");
    exit(EXIT_FAILURE);
  }
  proc_capture_setup(procs_fds);
  printf("Procs Thread: configured\n");
  fds[1] = procs_fds;
  threads[1] = 0;

  // Resource thread
  int resource_fds[2];
  if (pipe(resource_fds)) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Error opening pipe.\n");
    exit(EXIT_FAILURE);
  }
  resource_capture_setup(resource_fds);
  printf("Resource Thread: configured\n");
  fds[2] = resource_fds;
  threads[2] = 0;

  // Users thread
  int users_fds[2];
  if (pipe(users_fds)) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Error opening pipe.\n");
    exit(EXIT_FAILURE);
  }
  users_capture_setup(users_fds);
  printf("Users Thread: configured\n");
  fds[3] = users_fds;
  threads[3] = 0;

  // File thread
  int file_fds[2];
  if (pipe(file_fds)) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Error opening pipe.\n");
    exit(EXIT_FAILURE);
  }
  file_capture_setup(file_fds, server_info.dirs, server_info.dirs_size);
  printf("File Thread: configured\n");
  fds[4] = file_fds;
  threads[4] = 0;

  // Work loop
  int pid = fork();
  if (pid == 0)
    comm_loop();

  while (1) {
    // Work
    printf("Starting system scan...\n");
    pthread_create(&threads[0], NULL, network_process, NULL);
    pthread_create(&threads[1], NULL, proc_capture, NULL);
    pthread_create(&threads[2], NULL, resource_capture, NULL);
    pthread_create(&threads[3], NULL, users_capture, NULL);
    pthread_create(&threads[4], NULL, file_capture, NULL);
    fflush(stdout);

    // Join
    pthread_join(threads[0], NULL);
    pthread_join(threads[1], NULL);
    pthread_join(threads[2], NULL);
    pthread_join(threads[3], NULL);
    pthread_join(threads[4], NULL);
    printf("Finished sytem scan.\n");

    // Sleep for timeout
    sleep(server_info.timer);

    // Check for exit (safe here all thread exited)
    if (status != -1) {
      printf("Exiting...\n");
      exit(EXIT_SUCCESS);
    }
  }
}
