#include "helper.h"
#include <dirent.h>
#include <fcntl.h>
#include <openssl/sha.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/**
 * @brief Calculates the SHA1 hash of a given filename
 * @details Opens file, reads the entire file, calculates the hash
 * @param[file] The filename of the file to be opened
 * @return SHA1 hash of the file
 */
unsigned char *sha1_hash(char *file) {
  FILE *stat = fopen(file, "r");
  if (stat == NULL) {
    return NULL;
  }

  unsigned char *digest = safe_alloc(SHA_DIGEST_LENGTH);
  memset(digest, 0, SHA_DIGEST_LENGTH);

  int read = 0;
  int size = 0;
  unsigned char buf[BUFSIZ];
  unsigned char *data = safe_alloc(1);
  memset(data, 0, 1);
  while ((read = fread(buf, 1, 1024, stat)) != 0) {
    int len = size + read;
    unsigned char *tmp = NULL;
    while (tmp == NULL)
      tmp = realloc(data, len);
    data = tmp;
    memcpy(data + size, buf, read);
    size = len;
    memset(buf, 0, BUFSIZ);
  }
  fclose(stat);

  SHA1(data, size, digest);
  free(data);
  return digest;
}

void *safe_alloc(size_t size) {
  void *ret = NULL;
  while (ret == NULL)
    ret = malloc(size);
  memset(ret, 0, size);
  return ret;
}

char *safe_realloc_str(char *ptr, size_t size) {
  char *tmp = NULL;
  while (tmp == NULL)
    tmp = realloc(ptr, size);
  return ptr = tmp;
}

char *safe_strcat(char *lhs, const char *rhs) {
  size_t new_len = strlen(lhs) + strlen(rhs) + 1;
  lhs = safe_realloc_str(lhs, new_len);
  return strcat(lhs, rhs);
}

char *bin2hex(const unsigned char *bin, size_t len) {
  char *out;
  size_t i;

  if (bin == NULL || len == 0)
    return NULL;

  out = safe_alloc(len * 2 + 1);
  for (i = 0; i < len; i++) {
    out[i * 2] =
        "0123456789ABCDEF"[bin[i] >> 4]; // Shift right to get the high part
    out[i * 2 + 1] =
        "0123456789ABCDEF"[bin[i] & 0x0F]; // Mask to get the low part
  }
  out[len * 2] = '\0';

  return out;
}

char *strip_ws(const char *str) {
  char *out = safe_alloc(strlen(str) + 1);
  size_t cur = 0;
  for (int i = 0; i < strlen(str); i++) {
    if (str[i] != ' ' && str[i] != '\n') {
      out[cur] = str[i];
      cur += 1;
    }
  }
  return out;
}

char *read_file(char *filename) {
  int fd = open(filename, O_RDONLY);

  if (fd == -1) {
    fprintf(stderr, "Error opening file: %s\n", filename);
    return NULL;
  }

  char *content = NULL;
  size_t content_size = 0;
  size_t buffer_size = 1024;
  char buffer[buffer_size];
  ssize_t bytes_read;

  while ((bytes_read = read(fd, buffer, buffer_size)) > 0) {
    // Resize the content buffer if necessary
    char *new_content = realloc(content, content_size + bytes_read + 1);
    if (new_content == NULL) {
      perror("Memory allocation failed");
      close(fd);
      free(content);
      return NULL;
    }
    content = new_content;

    // Copy the read data into the content buffer
    memcpy(content + content_size, buffer, bytes_read);
    content_size += bytes_read;
  }

  if (bytes_read == -1) {
    fprintf(stderr, "Error reading file: %s\n", filename);
    close(fd);
    free(content);
    return NULL;
  }

  // Null-terminate the string
  content[content_size] = '\0';
  close(fd);
  return content;
}
