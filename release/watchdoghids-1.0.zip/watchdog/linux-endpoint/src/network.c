#include "network.h"
#include "helper.h"
#include <errno.h>
#include <netinet/if_ether.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <uthash.h>

struct host *hosts = NULL;
int *network_pipe = NULL;
pcap_t *dev_handle = NULL;
char *dev_addr = NULL;

/**
 * @brief Converts hosts hash table to cJSON
 * @details Built the use host struct and uthash
 * @param[hosts] The uthash table head
 * @return Converted cJSON struct
 */
struct cJSON *hosts_to_json(struct host *hosts) {
  cJSON *object = cJSON_CreateObject();
  cJSON *net_data = cJSON_CreateObject();

  struct host *cur_host = hosts;
  while (cur_host != NULL) {
    cJSON *ip = cJSON_CreateObject();

    cJSON_AddStringToObject(ip, "proto", cur_host->proto);
    cJSON_AddNumberToObject(ip, "orig_pkts", cur_host->orig_pkts);
    cJSON_AddNumberToObject(ip, "resp_pkts", cur_host->resp_pkts);
    cJSON_AddNumberToObject(ip, "orig_bytes", cur_host->orig_bytes);
    cJSON_AddNumberToObject(ip, "resp_bytes", cur_host->resp_bytes);

    cJSON_AddItemToObject(net_data, cur_host->ip, ip);
    cur_host = cur_host->hh.next;
  }

  cJSON_AddItemToObject(object, "NetworkData", net_data);
  return object;
}

/**
 * @brief Syncs current hosts to main server
 * @details First converts to json then writes to pipe for main process to
 * handle
 * @return NA
 */
void sync_hosts() {
  // Get json
  struct cJSON *json = hosts_to_json(hosts);
  char *json_str = cJSON_Print(json);

  // Write to pipe
  int write_count = write(network_pipe[1], json_str, strlen(json_str));
  write_count += write(network_pipe[1], "\0", 1);

  if (write_count != strlen(json_str) + 1) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Network Thread: Error writing to pipe\n");
    exit(EXIT_FAILURE);
  }

  // Clean up
  free(json_str);
  cJSON_Delete(json);
  struct host *cur, *tmp;
  HASH_ITER(hh, hosts, cur, tmp) {
    HASH_DEL(hosts, cur);
    free(cur);
  }

  hosts = NULL;
  return;
}

/**
 * @brief Manually sets the dev_addr
 * @details For testing purposes
 * @param[addr] String containing the dev addr
 * @return NA
 */
void set_dev_addr(char *addr) { dev_addr = addr; }

/**
 * @brief Handles packets captured on network device
 * @details Updates hosts hashtable with relevant info
 * @param[args] Host device ip string passed through dispatch
 * @param[header] Pointer to packet header bytes
 * @param[packet]  Pointer to entire packet bytes
 * @return NA
 */
void packet_handler(u_char *args, const struct pcap_pkthdr *header,
                    const u_char *packet) {
  struct ether_header *eth_hdr = (struct ether_header *)packet;

  const struct iphdr *ip_hdr = NULL;
  const struct tcphdr *tcp_hdr = NULL;
  const struct udphdr *udp_hdr = NULL;
  uint payload_len = 0;

  // IP Header
  ip_hdr = (struct iphdr *)(packet + sizeof(*eth_hdr));

  // TCP Header
  if (ip_hdr->protocol == IPPROTO_TCP) {
    tcp_hdr = (struct tcphdr *)(packet + sizeof(*eth_hdr) + sizeof(*ip_hdr));
  }

  else if (ip_hdr->protocol == IPPROTO_UDP) {
    udp_hdr = (struct udphdr *)(packet + sizeof(*eth_hdr) + sizeof(*ip_hdr));
  } else
    return;

  // Payload
  if (tcp_hdr != NULL)
    payload_len = header->caplen -
                  (sizeof(*eth_hdr) + sizeof(*ip_hdr) + sizeof(*tcp_hdr));
  else if (udp_hdr != NULL)
    payload_len = header->caplen -
                  (sizeof(*eth_hdr) + sizeof(*ip_hdr) + sizeof(*udp_hdr));

  // Record Info
  char src[22] = {0};
  char dst[22] = {0};
  char ip[28] = {0};
  char key[32] = {0};

  inet_ntop(AF_INET, &((struct iphdr *)ip_hdr)->saddr, src, sizeof(src));
  inet_ntop(AF_INET, &((struct iphdr *)ip_hdr)->daddr, dst, sizeof(src));

  if (strcmp(src, dev_addr) == 0) {
    if (tcp_hdr != NULL) {
      sprintf(ip, "%s:%d", dst, ntohs(tcp_hdr->th_dport));
      sprintf(key, "%s:TCP", ip);
    } else if (udp_hdr != NULL) {
      sprintf(ip, "%s:%d", dst, ntohs(udp_hdr->uh_dport));
      sprintf(key, "%s:UDP", ip);
    }
    struct host *host_ptr = NULL;
    HASH_FIND_STR(hosts, key, host_ptr);

    if (host_ptr == NULL) {
      host_ptr = (struct host *)safe_alloc(sizeof(struct host));
      memset(host_ptr, 0, sizeof(struct host));

      strcpy(host_ptr->ip, ip);
      strcpy(host_ptr->key, key);

      if (tcp_hdr != NULL)
        strcpy(host_ptr->proto, "TCP");
      if (udp_hdr != NULL)
        strcpy(host_ptr->proto, "UDP");

      host_ptr->orig_bytes = (unsigned long long)payload_len;
      host_ptr->resp_bytes = 0;
      host_ptr->orig_pkts = 1;
      host_ptr->resp_pkts = 0;

      HASH_ADD_STR(hosts, key, host_ptr);
    } else {
      host_ptr->orig_bytes += (unsigned long long)payload_len;
      host_ptr->orig_pkts += 1;
    }
  } else if (strcmp(dst, dev_addr) == 0) {
    if (tcp_hdr != NULL) {
      sprintf(ip, "%s:%d", src, ntohs(tcp_hdr->th_sport));
      sprintf(key, "%s:TCP", ip);
    } else if (udp_hdr != NULL) {
      sprintf(ip, "%s:%d", src, ntohs(udp_hdr->uh_sport));
      sprintf(key, "%s:UDP", ip);
    }
    struct host *host_ptr = NULL;
    HASH_FIND_STR(hosts, key, host_ptr);

    if (host_ptr == NULL) {
      host_ptr = (struct host *)safe_alloc(sizeof(struct host));
      strcpy(host_ptr->ip, ip);
      strcpy(host_ptr->key, key);
      if (tcp_hdr != NULL)
        strcpy(host_ptr->proto, "TCP");
      else if (udp_hdr != NULL)
        strcpy(host_ptr->proto, "UDP");

      host_ptr->orig_bytes = 0;
      host_ptr->resp_bytes = (unsigned long long)payload_len;
      host_ptr->orig_pkts = 0;
      host_ptr->resp_pkts = 1;

      HASH_ADD_STR(hosts, key, host_ptr);
    } else {
      host_ptr->resp_bytes += (unsigned long long)payload_len;
      host_ptr->resp_pkts += 1;
    }
  }

  fflush(stdout);
  fflush(stderr);
  return;
}

/**
 * @brief Setup env for network thread
 * @details Setups sniffing on default network device, configure needed vars
 * @param[arg] Pointer to fds for dedicated pipe
 * @return NA
 */
void *setup_network_capture(int *fds) {
  // Unpack arg
  network_pipe = fds;

  char errbuf[PCAP_ERRBUF_SIZE] = {0};
  pcap_if_t *devs = NULL;
  char *dev = NULL;
  bpf_u_int32 mask = 0;
  bpf_u_int32 net = 0;

  struct bpf_program fp;

  // Find default device
  memset(errbuf, 0, PCAP_ERRBUF_SIZE);
  pcap_findalldevs(&devs, errbuf);
  if (devs == NULL) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr,
            "Network Thread: Failed to find default network device: %s\n",
            errbuf);
    return NULL;
  }
  dev = devs->name;

  // Find device IP
  for (pcap_addr_t *p_addr = devs->addresses; p_addr != NULL;
       p_addr = p_addr->next) {
    if (p_addr->addr->sa_family == AF_INET && p_addr->addr && p_addr->netmask) {
      dev_addr = inet_ntoa(((struct sockaddr_in *)p_addr->addr)->sin_addr);
      break;
    }
  }

  // Get netmask
  memset(errbuf, 0, PCAP_ERRBUF_SIZE);
  if (pcap_lookupnet(dev, &net, &mask, errbuf) == -1) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Network Thread: Can't get netmask for device %s: %s\n",
            dev, errbuf);
    return NULL;
  }

  // Open default device for sniffing
  memset(errbuf, 0, PCAP_ERRBUF_SIZE);
  dev_handle = pcap_open_live(dev, BUFSIZ, 0, 1000, errbuf);
  if (dev_handle == NULL) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Network Thread: Failed to open device %s: %s\n", dev,
            errbuf);
    return NULL;
  }

  // Ensure correct header support
  if (pcap_datalink(dev_handle) != DLT_EN10MB) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr,
            "Network Thread: Dev %s does not support ethernet headers - not "
            "supported\n",
            dev);
    return NULL;
  }

  // Filter traffic
  if (pcap_compile(dev_handle, &fp, "udp or tcp", 1, net) == -1) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Network Thread: Couldn't parse default filter: %s\n",
            pcap_geterr(dev_handle));
    return NULL;
  }
  if (pcap_setfilter(dev_handle, &fp) == -1) {
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    fprintf(stderr, "Network Thread: Couldn't install filter: %s\n",
            pcap_geterr(dev_handle));
    return NULL;
  }

  pcap_freecode(&fp);
  pcap_freealldevs(devs);

  return NULL;
}

/**
 * @brief Process a group of packets
 * @details Populates host hash table with packet info, then calls
 *          sync the handle writing to pipe
 * @return NA
 */
void *network_process(void *arg) {
  pcap_dispatch(dev_handle, -1, packet_handler, NULL);

  if (hosts != NULL)
    sync_hosts();

  return NULL;
}
