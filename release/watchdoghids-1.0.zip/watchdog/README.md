# Watchdog

To run the central server, first ensure you pull all of the watchdog submodules.

- `git submodule update --init --recursive`

Inside the `node-server` dir, copy the .env.example to .env and fill with appropriate values

Inside the `analysis-engine` dir, create a .env file

To run with a unified central server, change the DB_HOST to `mariadb` and the HAE_HOST to `rust-microservice`

If you would like email notifications, provide credentials for you desired mailserver

Then run
- `docker-compose up --build -d`

You can now register endpoints via the Watchdog UI Admin screen

To reset the DB, run either `db_reset.ps1` (on Windows) or `db_reset.sh` (On Linux).


### Troubleshooting
If running the unified setup and you find you can't connect to your server with your endpoints, ensure that the port your node-server is running on allows incoming TCP connections.

If you can't connect to an endpoint that is waiting to be registered, ensure that its host machine can accept incoming TCP connections on the specified port. This port can be closed after initial endpoint registration.