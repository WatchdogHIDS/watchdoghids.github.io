import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import NavBar from './components/NavBar.jsx';
import DashboardScreen from './Screens/DashboardScreen.jsx';
import AdminPanel from './Screens/AdminPanel.jsx';
import HeuristicExplorer from './Screens/HeuristicExplorer.jsx';
import ManageEndpointsScreen from './Screens/ManageEndpointsScreen.jsx';
import LoginScreen from './Screens/LoginScreen.jsx';
import ScreenManagement from './Screens/ScreenManagement.jsx';
import EventAlertsScreen from './Screens/EventAlertsScreen.jsx';
import { jwtDecode } from 'jwt-decode';


function App() {
  // Auth states
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');


  /** Check if the token exists and is valid */
  const checkToken = () => {
    const token = localStorage.getItem("jwtToken");
    if (!token) return false;

    try {
      const decoded = jwtDecode(token);
      const isExpired = decoded.exp * 1000 < Date.now(); // Convert exp to milliseconds
      if (isExpired) {
        localStorage.removeItem("jwtToken");
        return false;
      }
      return true;
    } catch (error) {
      return false; // Invalid token
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("jwtToken");
    if (token) {
      setIsLoggedIn(checkToken());
    }
  }, []);

  /** Handle login logic */
  const handleLogin = async (e) => {
    e.preventDefault();

    const formData = { email, password };
    try {

      const response = await fetch('http://localhost:8081/analytics/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Login failed');
      }
      const data = await response.json();
      const token = data.token;
      localStorage.setItem('jwtToken', token);

      setIsLoggedIn(true);

    } catch (err) {
      window.alert('Invalid Username or Password');
    }
  };

  /** Handle logout */
  const handleLogout = () => {
    localStorage.removeItem('jwtToken');
    setIsLoggedIn(false);
    setEmail('');
    setPassword('');
  };

  const DeviceScreens = [
    {
      path: 'Endpoints',
      label: 'Endpoints',
      component: ManageEndpointsScreen,
    },
    {
      path: 'add-alerts',
      label: 'Add Alerts',
      component: EventAlertsScreen,
    },

    {
      path: 'api',
      label: 'API Keys',
      component: AdminPanel,
    },
  ];


  return (
    <Router>
      {/* Only show NavBar if logged in */}
      {isLoggedIn && <NavBar handleLogout={handleLogout} />}

      <div className="content">
        <Routes>
          {/* Public login routes */}
          <Route
            path="/"
            element={
              !isLoggedIn ? <LoginScreen
                handleLogin={handleLogin}
                setEmail={setEmail}
                setPassword={setPassword}
                email={email}
                password={password}
              /> : <Navigate to="/dashboard" replace />
            }
          />
          <Route
            path="/login"
            element={
              !isLoggedIn ? <LoginScreen
                handleLogin={handleLogin}
                setEmail={setEmail}
                setPassword={setPassword}
                email={email}
                password={password}
              /> : <Navigate to="/dashboard" replace />
            }
          />

          {/* Protected routes */}
          <Route
            path="/dashboard"
            element={
              isLoggedIn ? (
                <DashboardScreen />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />
          <Route
            path="/explorer"
            element={
              isLoggedIn ? (
                <HeuristicExplorer />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />

          <Route
            path="/admin/*"
            element={
              <ScreenManagement
                title="Admin Panel"
                screens={DeviceScreens}
              />
            }
          />

          <Route
            path="/admin-panel"
            element={
              isLoggedIn ? (
                <AdminPanel />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
