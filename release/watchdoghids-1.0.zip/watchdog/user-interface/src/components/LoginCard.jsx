import React from 'react';


const defaultStyle = {
  position: 'relative', // Ensure it can contain absolutely positioned elements
  width: '599px',
  height: '836px',
  backgroundColor: '#a9a9a9',
  borderRadius: '12px',
  padding: '20px', // Add some padding for spacing
  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
};

const GenericCard = (props) => {
  // Merge defaultStyles with props.styles (if provided)
  const mergedStyles = { ...defaultStyle, ...props.styles };

  return (
    <div style = {mergedStyles} className={props.className}>
      {props.children}
    </div>
  );
};

export default GenericCard;