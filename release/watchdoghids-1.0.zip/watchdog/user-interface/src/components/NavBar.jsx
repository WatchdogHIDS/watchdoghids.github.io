import React from 'react';
import { Link } from 'react-router-dom';
import './NavBar.css';
import Logo from '../cache/LogoCutout.png';
import Styles from '../components/skeletons/styles.module.css'


/**
 * NavBar using React Router for navigation.
 *
 * @param {string} activeScreen - Determines which button is highlighted
 * @param {function} handleLogout - Logout callback.
 */
const NavBar = ({ activeScreen, handleLogout }) => {
  return (
    <header className="navbar">

      {/* Left Section */}
      <div className="navbar-left"
        style={{
          display: 'flex',
          alignItems: 'center',
          border: '3px solid #ccc',  // Thin border
          borderRadius: '10px',
          padding: '4px 8px',        // Small padding
          marginRight: '-40px',       // Space from center section if needed
        }}
      >
        <img src={Logo} alt="watchdog_logo" className={Styles.smallLogoStyle} />
        <h1>WatchDog</h1>
      </div>


      <div className="navbar-center">
        <Link
          to="/dashboard"
          className={`nav-button ${activeScreen === 'Dashboard' ? 'active' : ''}`}
        >
          Dashboard
        </Link>
        <Link
          to="/explorer"
          className={`nav-button ${activeScreen === 'HeuristicExplorer' ? 'active' : ''}`}
        >
          Heuristic Explorer
        </Link>

        <Link
          to="/admin/Endpoints"
          className={`nav-button ${activeScreen === 'ManageEndpointsScreen' ? 'active' : ''}`}
        >
          Admin
        </Link>

      </div>

      {/* Right Section */}
      <div className="navbar-right">
        <button className="logout-button" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </header>

    
  );
};

export default NavBar;
