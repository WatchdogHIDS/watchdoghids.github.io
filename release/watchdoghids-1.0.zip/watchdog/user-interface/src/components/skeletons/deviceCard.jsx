import React from 'react';

const styles = {
  Card: {
    top: '147px',
    left: '142px',
    width: '808px',
    height: '405px',
    backgroundColor: '#a9a9a9',
    borderRadius: '12px',
  },
};

const Card = (props) => {
  return (
    <div style={styles.Card}>
      {props.children}
    </div>
  );
};


export default Card;