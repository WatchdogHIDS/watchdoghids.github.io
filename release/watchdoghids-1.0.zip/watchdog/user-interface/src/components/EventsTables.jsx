import { useState, useEffect } from "react";
import axios from "axios";
import "./EventsTables.css";

const getToken = () => localStorage.getItem("jwtToken");

const fetchEventData = async function (status, page, setEvents, setTotalPages, setLoading) {
  const token = getToken();
  try {
    const response = await axios.get(`http://localhost:8081/analytics/events/${status}?page=${page}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (response.status !== 200) throw new Error('Failed to fetch events');
    let data = response.data["data"];
    data = data.concat(Array(20 - data.length).fill({}));
    setEvents(data);
    setTotalPages(response.data["totalPages"]);
  } catch (error) {
    console.error('Error fetching events:', error);
  } finally {
    setLoading(false);
  }

}

const acknowledgeEvent = async function (event_id, event_type, setRefreshTrigger) {
  const token = getToken();
  if (!token) {
    console.error("No authentication token found");
    return;
  }
  try {
    await axios.put(
      "http://localhost:8081/analytics/acknowledge_event",
      { event_id, event_type },
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    setRefreshTrigger((prev) => prev + 1);
  } catch (error) {
    console.error("Error acknowledging event:", error);
  }
}

const resolveEvent = async function (event_id, event_type, setRefreshTrigger) {
  const token = getToken();
  if (!token) {
    console.error("No authentication token found");
    return;
  }

  const resolution_message = window.prompt("Enter resolution description:");
  if (!resolution_message) return;

  try {
    await axios.put(
      "http://localhost:8081/analytics/resolve_event",
      { event_id, event_type, resolution_message},
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    setRefreshTrigger((prev) => prev + 1);
  } catch (error) {
    console.error("Error resolving event:", error);
  }
}

const EventTable = ({ status, title, refreshTrigger, setRefreshTrigger }) => {
  const [events, setEvents] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const table_status = status;


  useEffect(() => {
    setEvents([]);
    fetchEventData(table_status, page, setEvents, setTotalPages, setLoading);
  }, [refreshTrigger, page, table_status]);

  return (
    <div className="events-container">
      <h2>{title}</h2>
      {loading ? (
        <div>Loading...</div>
      ) : (
        <div className="scrollable-body">
          <table className="events-table">
            <thead>
              <tr>
                <th>Endpoint</th>
                <th>Alert Type</th>
                <th>Alert Description</th>
                <th>Severity Level</th>
                <th>Last Updated</th>
                {(status === "unacknowledged" || status === "acknowledged") && <th>Action</th>}
                {status === "resolved" && <th>Resolution Description</th>}
              </tr>
            </thead>
            <tbody>
              {events.map((item, index) => (
                <tr key={item.id || index}>
                  <td>{item.name || ''}</td>
                  <td>{item.event_type || ''}</td>
                  <td>{item.alert_description || ''}</td>
                  <td>{item.severity_level || ''}</td>
                  <td>{item.updated_at ? new Date(item.updated_at).toLocaleString() : ''}</td>
                  {(status === "unacknowledged" || status === "acknowledged") && !item.id && (
                    <td></td>
                  )}
                  {status === "unacknowledged" && item.id && (
                    <td>
                      <button
                        onClick={() => acknowledgeEvent(item.id, item.event_type_id, setRefreshTrigger)}
                        className="action-button"
                      >
                        Acknowledge
                      </button>
                    </td>
                  )}
                  {status === "acknowledged" && item.id && (
                    <td>
                      <button
                        onClick={() => resolveEvent(item.id, item.event_type_id, setRefreshTrigger)}
                        className="action-button"
                      >
                        Resolve
                      </button>
                    </td>
                  )}
                  {status === "resolved" && (
                    <td>{item.resolution_description || ''}</td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="pagination">
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>
          Previous
        </button>
        <span>
          Page {page} of {totalPages}
        </span>
        <button
          disabled={page === totalPages || totalPages === 0}
          onClick={() => setPage(page + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default function EventsPage() {
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  return (
    <div>
      <EventTable
        status="unacknowledged"
        title="Unacknowledged Events"
        refreshTrigger={refreshTrigger}
        setRefreshTrigger={setRefreshTrigger}
      />
      <EventTable
        status="acknowledged"
        title="Acknowledged Events"
        refreshTrigger={refreshTrigger}
        setRefreshTrigger={setRefreshTrigger}
      />
      <EventTable
        status="resolved"
        title="Resolved Events"
        refreshTrigger={refreshTrigger}
        setRefreshTrigger={setRefreshTrigger}
      />
    </div>
  );
}
