import React from 'react';

const styles = {
    button: {

        cursor: 'pointer',
        top: '102px',
        left: '138px',
        width: '116px',
        height: '32px',
        padding: '0px 8px',
        border: '0',
        boxSizing: 'border-box',
        borderRadius: '12px',
        backgroundColor: '#12d22c',
        color: '#ffffff',
        fontSize: '12px',
        fontFamily: 'Poppins',
        fontWeight: 700,
        lineHeight: '16px',
        outline: 'none',
    },
};


const handleClick = () => {
    console.log('HelloWorld');

}

const defaultProps = {
    label: 'Click Me',
};

const Button = (props) => {
    return (
        <div>

            <button
                onClick={handleClick}
                style={styles.button}
            >
                {props.label ?? defaultProps.label}
            </button>

        </div>
    );
};

export default Button;