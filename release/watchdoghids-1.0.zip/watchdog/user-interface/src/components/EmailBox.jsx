import React from 'react';

const styles = {
  Input: {
    top: '498px',
    left: '487px',
    height: '51px',
    padding: '0px 8px',
    border: '1px solid #393939',
    boxSizing: 'border-box',
    borderRadius: '12px',
    backgroundColor: '#161616',
    color: '#bebebe',
    fontSize: '14px',
    fontFamily: 'Poppins',
    fontWeight: 500,
    lineHeight: '18px',
    outline: 'none',
  },
};

const defaultProps = {
  text: 'Enter your email address',
};

const InputField = (props) => {
  const mergedStyles = { ...styles.Input, ...props.styles };

  return (
    <input style={mergedStyles} placeholder={props.text ?? defaultProps.text} className={props.className} onChange={props.onChange}/>
  );
};

export default InputField;