import React, { useState } from 'react'

function MultiProtocolSelector({ availableProtocols, onChange }) {
  const [selected, setSelected] = useState([])

  const handleCheck = (protocol) => {
    if (selected.includes(protocol)) {
      const updated = selected.filter((p) => p !== protocol)
      setSelected(updated)
      onChange(updated)
    } else {
      const updated = [...selected, protocol]
      setSelected(updated)
      onChange(updated)
    }
  }

  return (
    <div>
      {availableProtocols.map((proto) => (
        <label key={proto} style={{ display: 'inline-block', marginRight: '10px', marginTop:'10px' }}>
          <input
            type="checkbox"
            checked={selected.includes(proto)}
            onChange={() => handleCheck(proto)}
          />
          {proto}
        </label>
      ))}
    </div>
  )
}

export default MultiProtocolSelector
