import React from 'react';

const Container = (props) => {
  return (
    <div style={styles.container}>
      {props.children}
    </div>
  );
};

// Example styles for positioning components
const styles = {
  container: {
    display: 'flex', // You can switch to 'grid' if needed
    flexDirection: 'column', // Change to 'column' for vertical stacking
    justifyContent: 'center', // Adjust positioning (e.g., 'center', 'space-between', etc.)
    alignItems: 'center', // Center children vertically
    padding: '20px',
    gap: '10px', // Spacing between children
  },
};

export default Container;

