import React from 'react';
import Container from '../components/Container.jsx'; 
import GenericCard from '../components/LoginCard.jsx';
import EmailBox from '../components/EmailBox.jsx';
import PasswordField from '../components/PasswordField.jsx';
import Styles from '../components/skeletons/styles.module.css'
import Logo from '../cache/Watchdog.png';

function LoginScreen({ email, setEmail, password, setPassword, handleLogin }) {
  return (
    <Container>
      <GenericCard className={Styles.loginCard}>
        <span className={Styles.watchdogText}>Watchdog</span>
        <img src={Logo} alt="watchdog_logo" className={Styles.bigLogoStyle} />

        <EmailBox
          className={Styles.inputField}
          value={email}
          onChange={(e) => setEmail(() => e.target.value)}
        />
        <PasswordField
          className={Styles.inputField}
          value={password}
          onChange={(e) => setPassword(() => e.target.value)}
        />

        <button className={Styles.loginButton} onClick={handleLogin}>
          Log In
        </button>
      </GenericCard>
    </Container>
  );
}

export default LoginScreen;
