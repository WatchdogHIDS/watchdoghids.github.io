import React, { useState} from 'react';
import EventsPage from '../components/EventsTables';
import './DashboardScreen.css';

const DashboardScreen = ({ handleLogout, handleScreenChange }) => {
  const [error, ] = useState(null);

  if (error) {
    return <div>Error: {error}</div>;  // Show error message if fetching fails
  }

  return (
    <div className="dashboard-container">
      {/* Dashboard Header */}
      <div className="dashboard-header">
        <h1>Dashboard</h1>
        <p>Welcome to the WatchDog Dashboard</p>
      </div>

      

      {/* Devices and Security Risks Table */}
      <div className="devices-table">
        <h3>Security Events</h3>
        <EventsPage/>
      </div>
    </div>
  );
};

export default DashboardScreen;
