import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ManageEndpointsScreen.css';

/**
 * A screen dedicated to managing API Keys
 */
function AdminPanel() {

    // Local api-key list
    const [ApiKeys, setKeys] = useState([]);

    useEffect(() => {
        fetchKeys(setKeys);
    }, []);


    // States for managing keys
    const [keyID, setKeyID] = useState('');
    const [keyValue, setKeyValue] = useState('');

    const handleUpdateKey = async () => {
        if (!keyID.trim() || !keyValue.trim()) {
            alert('Please select a valid API key ID and provide a new value.');
            return;
        }

        const data = {
            "key_id": keyID,
            "api_key": keyValue
        }

        const result = await updateKey(data);

        if (!result) {
            return
        }
        setKeyValue("");
        setKeyID("");
        fetchKeys();
    }

    return (
        <div className="manage-container">
            <h2 className="manage-header">Manage API-Keys</h2>

            {/* Key List Card */}
            <div className="card">
                <h3>API Key List</h3>
                {ApiKeys.length === 0 ? (
                    <p>No keys available.</p>
                ) : (
                    <ul className="apikey-list">
                        {ApiKeys.map((key) => (
                            <li key={key.id} className="api_key" style={{ marginTop: "20px" }}>
                                <strong>{key.description}</strong> <br />
                                <div style={{ fontSize: '0.9rem', color: '#ccc', display: 'grid', gridTemplateColumns: "50px 1fr" }}>
                                    <div>ID: {key.id}</div>
                                    <div>Status: <strong>{key.status ? "VALID" : "INVALID"}</strong></div>
                                </div>
                            </li>
                        ))}
                    </ul>
                )}
            </div>

            {/* Add Key Card */}
            <div className="card">
                <h3>Update API Key</h3>

                <div className="form-group">
                    <label className="form-label">Key ID:</label>
                    <select
                        className="form-input"
                        value={keyID}
                        onChange={(e) => setKeyID(e.target.value)}
                    >
                        <option value="">Select a Key ID</option>
                        {ApiKeys.map(apiKey => (
                            <option key={apiKey.id} value={apiKey.id}>
                                {apiKey.id}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label className="form-label">Key Value:</label>
                    <input
                        type="text"
                        className="form-input"
                        value={keyValue}
                        onChange={(e) => setKeyValue(e.target.value)}
                        placeholder=""
                    />
                </div>
                <button onClick={handleUpdateKey} className="add-button">
                    Update
                </button>
            </div>
        </div>

    );
}

const fetchKeys = async function (setKeys) {
    const token = getToken();
    try {
        const response = await axios.get('http://localhost:8081/analytics/api_keys', {
            headers: {
                'Authorization': `Bearer ${token}`,
            },
        });
        if (response.status !== 200) throw new Error('Failed to fetch keys');
        setKeys(response.data);
    } catch (error) {
        console.error('Error fetching keys:', error);
    }
}


const updateKey = async function (data) {
    const token = getToken();

    try {
        const response = await axios.put(`http://localhost:8081/analytics/api_keys/update`, data, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        if (response.status !== 200) {
            const msg = response.body["message"];
            alert(msg);
            return false;
        }
        return true;
    } catch (err) {
        if (axios.isAxiosError(err)) {
            const msg = err.response.data?.message || "Failed to update key";
            alert(msg);
        }
    }

    return false;
}



const getToken = () => {
    return localStorage.getItem('jwtToken');
};


export default AdminPanel;
