import React, { useState, useEffect } from 'react'
import axios from 'axios';

function EventAlertsScreen() {

  const [devices, setDevices] = useState([]);
  const [bandwidthBytes, setBandwidthBytes] = useState('')

  const [selectedDevice, setSelectedDevice] = useState('');
  const [severityLevel, setSeverityLevel] = useState("MEDIUM")
  const [targetHost, setTargetHost] = useState('');
  const [description, setDescription] = useState('');

  // New state for time window range for Bandwidth alerts
  const [bandwidthWindow, setBandwidthWindow] = useState("");

  // All created alerts are displayed in a separate table
  const [allAlerts, setAllAlerts] = useState([]);

  // Re-check alerts whenever alertConfig changes
  useEffect(() => {
    fetchEndpoints(setDevices);
    fetchAlerts(setAllAlerts);
  }, [])

  // Add new alert
  const handleAddAlert = async (e) => {
    e.preventDefault();
    console.log(selectedDevice);

    if (!selectedDevice.trim() || !severityLevel.trim() || !bandwidthBytes.trim() || !bandwidthWindow.trim() || !description.trim() || !targetHost.trim()) {
      alert('Please provide valid alert details');
      return;
    }

    const alert_data = {
      "endpoint_id": selectedDevice,
      "user_id": 1,
      "event_description": description,
      "target_host": targetHost,
      "severity_level": severityLevel,
      "bandwidth_threshold": bandwidthBytes,
      "time_window": bandwidthWindow
  }

    const result = await createNewAlert(alert_data);

    if (!result) {
      return;
    };
    
    try {
      setSelectedDevice('');
      setBandwidthBytes('');
      setBandwidthWindow('');
      setDescription('');
      setSeverityLevel('MEDIUM');
      setTargetHost('');

      fetchAlerts(setAllAlerts);
    } catch (err) {
      alert(err.message)
    }
  }

  return (
    <div
      style={{
        padding: '20px',
        fontFamily: 'Arial, sans-serif',
        backgroundColor: '#1e1e1e',
        color: '#eaeaea',
        minHeight: '100vh',
      }}
    >
      <h2 style={{ color: '#4caf50' }}>Custom Alert Configuration</h2>
      <div
        style={{
          backgroundColor: '#292929',
          border: '1px solid #333',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 6px rgba(0,0,0,0.5)',
          marginBottom: '20px',
        }}
      >
        <form onSubmit={handleAddAlert}>
          <h2 style={{ marginTop: 0, color: '#4caf50', display: 'inline-block' }}>Bandwidth Limits</h2>

          {/* New Severity Level Dropdown (common to all alert types) */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'inline-block', width: '150px' }}>Severity Level</label>
            <select
              value={severityLevel}
              onChange={(e) => setSeverityLevel(e.target.value)}
              style={{
                padding: '6px',
                borderRadius: '4px',
                border: '1px solid #444',
                backgroundColor: '#1e1e1e',
                color: '#eaeaea',
                width: '200px'
              }}
            >
              <option value="LOW">LOW</option>
              <option value="MEDIUM">MEDIUM</option>
              <option value="HIGH">HIGH</option>
              <option value="CRITICAL">CRITICAL</option>
            </select>
          </div>

          <div style={{ marginBottom: 10 }}>
            <h3 style={{ marginTop: 10, display: 'inline-block' }}>Device:</h3>
            <select
              value={selectedDevice}
              onChange={(e) => setSelectedDevice(e.target.value)}
              style={{
                padding: '6px',
                borderRadius: '4px',
                border: '1px solid #444',
                backgroundColor: '#1e1e1e',
                color: '#eaeaea',
                width: '200px',
                marginLeft: '83px'
              }}
            >
              <option value={""} disabled selected>
              Select a device
              </option>
              {devices.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} - {d.ip}
                </option>
              ))}
            </select>
          </div>
          <div style={{ marginBottom: '10px' }}>
            <label style={{ display: 'inline-block', width: '150px' }}>Description</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              style={{
                padding: '6px',
                borderRadius: '4px',
                border: '1px solid #444',
                backgroundColor: '#1e1e1e',
                color: '#eaeaea',
                width: '200px',
              }}
            />
          <div style={{ marginBottom: '10px' }}>
            <label style={{ display: 'inline-block', width: '150px' }}>Target Host</label>
            <input
              type="text"
              value={targetHost}
              onChange={(e) => setTargetHost(e.target.value)}
              placeholder='127.0.0.1'
              style={{
                padding: '6px',
                borderRadius: '4px',
                border: '1px solid #444',
                backgroundColor: '#1e1e1e',
                color: '#eaeaea',
                width: '200px',
              }}
            />
          </div>
          </div>
          <div style={{ marginBottom: '10px' }}>
            <label style={{ display: 'inline-block', width: '150px' }}>Bandwidth Limit</label>
            <input
              type="number"
              value={bandwidthBytes}
              placeholder='In Bytes'
              onChange={(e) => setBandwidthBytes(e.target.value)}
              style={{
                padding: '6px',
                borderRadius: '4px',
                border: '1px solid #444',
                backgroundColor: '#1e1e1e',
                color: '#eaeaea',
                width: '200px',
              }}
            />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'inline-block', width: '150px' }}>Time Window</label>
            <input
              value={bandwidthWindow}
              type='number'
              placeholder='In Minutes'
              onChange={(e) => setBandwidthWindow(e.target.value)}
              style={{
                padding: '6px',
                borderRadius: '4px',
                border: '1px solid #444',
                backgroundColor: '#1e1e1e',
                color: '#eaeaea',
                width: '90px',
                marginRight: '10px'
              }}
            />
          </div>
          <button
            type="submit"
            style={{
              marginTop: '10px',
              padding: '8px 16px',
              backgroundColor: '#4caf50',
              color: '#fff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
            }}
          >
            Add Alert
          </button>
        </form>
      </div>

      <div
        style={{
          backgroundColor: '#292929',
          border: '1px solid #333',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 6px rgba(0,0,0,0.5)',
        }}
      >
        <h2 style={{ marginTop: 0, color: '#4caf50', marginBottom: 30 }}>Created Alerts</h2>

        {/*Bandwidth Table*/}
        <h3 style={{ marginTop: 20, color: '#4caf50' }}>Bandwidth Alerts</h3>
        {allAlerts.length === 0 ? (
          <p>No Bandwidth Alerts Created Yet.</p>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead style={{ backgroundColor: '#333' }}>
              <tr>
                <th style={{ padding: '8px', borderBottom: '1px solid #444' }}>Alert ID</th>
                <th style={{ padding: '8px', borderBottom: '1px solid #444' }}>Device</th>
                <th style={{ padding: '8px', borderBottom: '1px solid #444' }}>Description</th>
                <th style={{ padding: '8px', borderBottom: '1px solid #444' }}>Bandwidth</th>
                <th style={{ padding: '8px', borderBottom: '1px solid #444' }}>Time Window</th>
                <th style={{ padding: '8px', borderBottom: '1px solid #444' }}>Severity Level</th>
              </tr>
            </thead>
            <tbody>
              {allAlerts.map((alert) => (
                <tr key={alert.id} style={{ borderBottom: '1px solid #444' }}>
                  <td style={{ padding: '8px' }}>{alert.id}</td>
                  <td style={{ padding: '8px' }}>{alert.endpoint_name}</td>
                  <td style={{ padding: '8px' }}>{alert.event_description}</td>
                  <td style={{ padding: '8px' }}>{alert.bandwidth_threshold}</td>
                  <td style={{ padding: '8px' }}>
                    {alert.sliding_window_minutes} minutes
                  </td>
                  <td style={{ padding: '8px' }}>{alert.severity_level}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

const fetchEndpoints = async function (setEndpoints) {
  const token = getToken();
  try {
    const response = await axios.get('http://localhost:8081/analytics/endpoints', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
    if (response.status !== 200) throw new Error('Failed to fetch endpoints');
    setEndpoints(response.data);
  } catch (error) {
    console.error('Error fetching endpoints:', error);
  }
}

const fetchAlerts = async function (setAlerts) {
  const token = getToken();
  try {
    const response = await axios.get('http://localhost:8081/analytics/user_settings/events', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
    if (response.status !== 200) throw new Error('Failed to fetch endpoints');
    setAlerts(response.data);
  } catch (error) {
    console.error('Error fetching endpoints:', error);
  }
}

const createNewAlert = async function (alert_data) {
  const token = getToken();

  try {
    const response = await axios.post(`http://localhost:8081/analytics/user_settings/events/create`, alert_data, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.status !== 201) {
      const msg = response.body["message"];
      alert(msg);
      return false;
    }
    return true;
  } catch (err) {
    if (axios.isAxiosError(err)) {
      const msg = err.response.data?.message || "Failed to add endpoint";
      alert(msg);
    }
  }
  
  return false;
}

const getToken = () => {
  return localStorage.getItem('jwtToken');
};

export default EventAlertsScreen;
