import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  TimeScale,
} from 'chart.js';
import 'chartjs-adapter-date-fns';
import './HeuristicExplorer.css';
import axios from 'axios';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, TimeScale);

const HeuristicExplorer = () => {

  const [networkData, setNetworkData] = useState([]); //  network data
  const [resourceData, setResourceData] = useState([]); //  resource data

  useEffect(() => {
    fetchNetworkData(setNetworkData);
    fetchResourceData(setResourceData);
     }, [])

  const [loading] = useState(false); // Not loading for demo
  const [error] = useState(null);
  const [selectedEndpoints, setSelectedEndpoints] = useState([]); // For network data
  const [selectedResourceEndpoints, setSelectedResourceEndpoints] = useState([]); // For resource data
  const [selectedGraph, setSelectedGraph] = useState("network");

  // Initialize selectedEndpoints from network data
  useEffect(() => {
    const allIPs = new Set(networkData.map((item) => item.internal_ip));
    setSelectedEndpoints([...allIPs]);
  }, [networkData]);

  // Initialize selectedResourceEndpoints from resource data
  useEffect(() => {
    const allResourceEIDs = new Set(resourceData.map((item) => item.endpoint_id));
    setSelectedResourceEndpoints([...allResourceEIDs]);
  }, [resourceData]);

  // Toggle endpoint for network data
  const handleEndpointToggle = (ip) => {
    if (selectedEndpoints.includes(ip)) {
      setSelectedEndpoints((prev) => prev.filter((v) => v !== ip));
    } else {
      setSelectedEndpoints((prev) => [...prev, ip]);
    }
  };

  // Toggle endpoint for resource data
  const handleResourceEndpointToggle = (eid) => {
    if (selectedResourceEndpoints.includes(eid)) {
      setSelectedResourceEndpoints((prev) => prev.filter((v) => v !== eid));
    } else {
      setSelectedResourceEndpoints((prev) => [...prev, eid]);
    }
  };

  // Filter network and resource data based on selections
  const netData = networkData.filter((item) =>
    selectedEndpoints.includes(item.internal_ip)
  );
  const filteredResourceData = resourceData.filter((item) =>
    selectedResourceEndpoints.includes(item.endpoint_id)
  );

  // For network view, group data by endpoint and create datasets for bytes and packets.
  const groupedNetworkData = {};
  selectedEndpoints.forEach(ip => {
    groupedNetworkData[ip] = netData.filter(item => item.internal_ip === ip)
      .sort((a, b) => new Date(a.record_timestamp) - new Date(b.record_timestamp));
  });
  const networkDatasets = [];
  const colorPalette = ['#00b3ff', '#ff7300', '#0033cc', '#00cc66', '#cc3300'];
  Object.keys(groupedNetworkData).forEach((ip, idx) => {
    const dataForIp = groupedNetworkData[ip];
    const bytesDataPoints = dataForIp.map(item => ({
      x: new Date(item.record_timestamp),
      y: item.bytes
    }));
    const packetsDataPoints = dataForIp.map(item => ({
      x: new Date(item.record_timestamp),
      y: item.packets
    }));
    networkDatasets.push({
      label: `Endpoint ${ip} Bytes`,
      data: bytesDataPoints,
      borderColor: colorPalette[idx % colorPalette.length],
      backgroundColor: colorPalette[idx % colorPalette.length] + '33',
      pointRadius: 5,
      pointHoverRadius: 8,
      fill: false,
      tension: 0.1,
    });
    networkDatasets.push({
      label: `Endpoint ${ip} Packets`,
      data: packetsDataPoints,
      borderColor: colorPalette[idx % colorPalette.length],
      backgroundColor: colorPalette[idx % colorPalette.length] + '33',
      borderDash: [5, 5],
      pointRadius: 5,
      pointHoverRadius: 8,
      fill: false,
      tension: 0.1,
    });
  });
  const networkChartData = {
    datasets: networkDatasets,
  };

  // For the resource view, aggregate CPU and Memory per endpoint and create separate datasets per endpoint.
  const processorDatasets = [];
  const resourceEndpoints = Array.from(new Set(filteredResourceData.map(item => item.endpoint_id)));
  resourceEndpoints.forEach((eid, index) => {
    const dataForEndpoint = filteredResourceData.filter(item => item.endpoint_id === eid)
      .sort((a, b) => new Date(a.record_timestamp) - new Date(b.record_timestamp));
    const cpuDataPoints = dataForEndpoint.map(item => ({
      x: new Date(item.record_timestamp),
      y: Object.values(item.resource_info).reduce((sum, proc) => sum + parseFloat(proc.cpu), 0)
    }));
    const memDataPoints = dataForEndpoint.map(item => ({
      x: new Date(item.record_timestamp),
      y: Object.values(item.resource_info).reduce((sum, proc) => sum + parseFloat(proc.mem), 0)
    }));
    processorDatasets.push({
      label: `Endpoint ${eid} CPU`,
      data: cpuDataPoints,
      borderColor: colorPalette[index % colorPalette.length],
      backgroundColor: colorPalette[index % colorPalette.length] + '33',
      pointRadius: 5,
      pointHoverRadius: 8,
      fill: false,
      tension: 0.1,
    });
    processorDatasets.push({
      label: `Endpoint ${eid} Memory`,
      data: memDataPoints,
      borderColor: colorPalette[index % colorPalette.length],
      backgroundColor: colorPalette[index % colorPalette.length] + '33',
      borderDash: [5, 5],
      pointRadius: 5,
      pointHoverRadius: 8,
      fill: false,
      tension: 0.1,
    });
  });
  const processorChartData = {
    datasets: processorDatasets,
  };

  const chartData = selectedGraph === "network" ? networkChartData : processorChartData;

  // Prepare detailed rows for resource data table (processor view)
  const detailedResourceRows = [];
  filteredResourceData.forEach(item => {
    const timestamp = new Date(item.record_timestamp).toLocaleString();
    const endpoint_id = item.endpoint_id;
    Object.entries(item.resource_info).forEach(([pid, procStats]) => {
      detailedResourceRows.push({
        timestamp,
        endpoint_id,
        pid,
        cpu: procStats.cpu,
        mem: procStats.mem,
        time: procStats.time,
      });
    });
  });

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      tooltip: {
        callbacks: {
          label: function (tooltipItem) {
            // For network datasets, display bytes/packets; for resource, display usage %
            if (tooltipItem.dataset.label && tooltipItem.dataset.label.includes('Bytes')) {
              return `Bytes: ${tooltipItem.raw}`;
            } else if (tooltipItem.dataset.label && tooltipItem.dataset.label.includes('Packets')) {
              return `Packets: ${tooltipItem.raw}`;
            } else if (tooltipItem.dataset.label && (tooltipItem.dataset.label.includes('CPU') || tooltipItem.dataset.label.includes('Memory'))) {
              return `${tooltipItem.dataset.label}: ${tooltipItem.raw}%`;
            }
            return tooltipItem.raw;
          },
        },
      },
      legend: {
        display: true,
        position: 'top',
      },
    },
    scales: {
      x: {
        type: 'time',
        time: {
          tooltipFormat: 'MMM d, yyyy, h:mm:ss a',
          unit: 'minute',
        },
        title: {
          display: true,
          text: 'Timestamp',
        },
      },
      y: {
        type: 'linear',
        display: true,
        position: 'left',
        title: {
          display: true,
          text: selectedGraph === "network" ? 'Bytes / Packets' : 'Usage (%)',
        },
      },
    },
  };

  if (loading) {
    return <div>Loading...</div>;
  }
  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="heuristic-explorer-container">
      {/* Heuristic Explorer Main Content */}
      <div className="main-content">
        <div className="explorer-header">
          <h2 style={{ display: 'inline-block', marginRight: '20px' }}>Heuristic Explorer</h2>
          <select
            value={selectedGraph}
            onChange={(e) => setSelectedGraph(e.target.value)}
            className="custom-dropdown"
            style={{ display: 'inline-block' }}
          >
            <option value="network">Network Data</option>
            <option value="processor">Processor Data</option>
          </select>
        </div>

        {selectedGraph === "network" && (
          <div className="endpoint-container" style={{ marginBottom: '20px' }}>
            <h3>Select Endpoint To Display</h3>
            {[...new Set(networkData.map((item) => item.internal_ip))].map((ip) => (
              <label key={ip} className="endpoint-checkbox">
                <input
                  type="checkbox"
                  checked={selectedEndpoints.includes(ip)}
                  onChange={() => handleEndpointToggle(ip)}
                />
                {ip}
              </label>
            ))}
          </div>
        )}

        {selectedGraph === "processor" && (
          <div className="endpoint-container" style={{ marginBottom: '20px' }}>
            <h3>Select Endpoint To Display</h3>
            {[...new Set(resourceData.map((item) => item.endpoint_id))].map((eid) => (
              <label key={eid} className="endpoint-checkbox">
                <input
                  type="checkbox"
                  checked={selectedResourceEndpoints.includes(eid)}
                  onChange={() => handleResourceEndpointToggle(eid)}
                />
                {eid}
              </label>
            ))}
          </div>
        )}

        {/* Line Chart to Display Data */}
        <div className="graph-section" style={{ position: 'relative', height: '400px' }}>
          <Line data={chartData} options={options} />
        </div>

        {selectedGraph === "network" && (
          <>
            {/* Connection Data Table */}
            <div className="connection-data-section">
              <h3>Network Connections Breakdown</h3>
              <div className="scrollable-body">
                <table>
                  <thead>
                    <tr>
                      <th>Timestamp</th>
                      <th>Internal IP</th>
                      <th>External IP</th>
                      <th>Destination Port</th>
                      <th>Protocol</th>
                      <th>Connection State</th>
                      <th>Packets</th>
                      <th>Bytes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {netData.map((item, index) => (
                      <tr key={index}>
                        <td>{new Date(item.record_timestamp).toLocaleString()}</td>
                        <td>{item.internal_ip}</td>
                        <td>{item.external_ip}</td>
                        <td>{item.destination_port}</td>
                        <td>{item.protocol}</td>
                        <td>{item.connection_state}</td>
                        <td>{item.packets}</td>
                        <td>{item.bytes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {selectedGraph === "processor" && (
          <>
            {/* Resource Data Table */}
            <div className="connection-data-section">
              <h3>Resource Data Breakdown</h3>
              <div className="scrollable-body">
                <table>
                  <thead>
                    <tr>
                      <th>Timestamp</th>
                      <th>Endpoint ID</th>
                      <th>PID</th>
                      <th>CPU Usage (%)</th>
                      <th>Memory Usage (%)</th>
                      <th>Active Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detailedResourceRows.map((row, index) => (
                      <tr key={index}>
                        <td>{row.timestamp}</td>
                        <td>{row.endpoint_id}</td>
                        <td>{row.pid}</td>
                        <td>{row.cpu}%</td>
                        <td>{row.mem}%</td>
                        <td>{row.time}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

const fetchNetworkData = async (setNetworkData) => {
  const token = getToken();
  try {
    const response = await axios.get('http://localhost:8081/analytics/network_traffic', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
    if (response.status !== 200) throw new Error('Failed to fetch network traffic');
    setNetworkData(response.data);
  } catch (error) {
    console.error('Failed to fetch network data', error);
  }
}

const fetchResourceData = async (setResourceData) => {
  const token = getToken();
  try {
    const response = await axios.get('http://localhost:8081/analytics/resource_data', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
    if (response.status !== 200) throw new Error('Failed to fetch network traffic');
    setResourceData(response.data);
  } catch (error) {
    console.error('Failed to fetch network data', error);
  }
}

const getToken = () => {
  return localStorage.getItem('jwtToken');
};

export default HeuristicExplorer;
