import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Styles from '../components/skeletons/styles.module.css'
import '../components/NavBar.css';

// A parent screen that manages sub-routes for various screens.
function ScreenManagement({ title, screens }) {
    return (
      
      <div className="screen-management">
        <nav className="subnavbar-left">
          {screens.map((scr) => (
            <Link
              key={scr.path}
              to={`/admin/${scr.path}`} 
              className={Styles.SubheaderButton}
            >
              {scr.label}
            </Link>
          ))}
        </nav>
        
        <Routes>
          {screens.map((scr) => (
            <Route
              key={scr.path}
              path={scr.path}
              element={<scr.component />}
            />
          ))}

        </Routes>

      </div>
    );
  }
  
  export default ScreenManagement;
