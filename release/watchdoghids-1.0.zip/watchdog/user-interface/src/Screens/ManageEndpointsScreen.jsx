import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "./ManageEndpointsScreen.css";

/**
 * A screen dedicated to managing (adding, listing, removing) endpoints.
 * Adds an IP address field to each endpoint.
 */
function ManageEndpointsScreen() {
  // Local endpoint list
  const [endpoints, setEndpoints] = useState([]);

  useEffect(() => {
    fetchEndpoints(setEndpoints);
  }, []);

  // States for adding a new endpoint
  const [newEndpointName, setNewEndpointName] = useState('');
  const [newEndpointIP, setNewEndpointIP] = useState('');
  const [newEndpointKey, setNewEndpointKey] = useState('');

  // Add endpoint
  const handleAddEndpoint = async () => {
    if (!newEndpointName.trim() || !newEndpointIP.trim() || !newEndpointKey.trim()) {
      alert('Please provide a valid endpoint Name, Host address, and Key.');
      return;
    }

    const reg_data = {
      "endpoint_name": newEndpointName,
      "endpoint_host": newEndpointIP,
      "endpoint_key": newEndpointKey
    }

    const result = await registerNewEndpoint(reg_data);

    if (!result) {
      return;
    };

    setNewEndpointName('');
    setNewEndpointIP('');
    setNewEndpointKey('');

    fetchEndpoints(setEndpoints);
  };

  return (
    <div className="manage-container">
      <h2 className="manage-header">Manage Endpoints</h2>

      {/* Endpoints List Card */}
      <div className="card">
        <h3>Endpoints List</h3>
        {endpoints.length === 0 ? (
          <p>No endpoints available.</p>
        ) : (
          <ul className="endpoint-list">
            {endpoints.map((ep) => (
              <li key={ep.id} className="endpoint-item">
                <span>
                  <strong>{ep.name}</strong> <br />
                  <span style={{ fontSize: '0.9rem', color: '#ccc' }}>
                    IP: {ep.ip}
                  </span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Add Endpoint Card */}
      <div className="card">
        <h3>Actions</h3>
        <p>Register New endpoints to your Watchdog server</p>

        <div className="form-group">
          <label className="form-label">Endpoint Name:</label>
          <input
            type="text"
            className="form-input"
            value={newEndpointName}
            onChange={(e) => setNewEndpointName(e.target.value)}
            placeholder="New Endpoint"
          />
        </div>

        <div className="form-group">
          <label className="form-label">Host:</label>
          <input
            type="text"
            className="form-input"
            value={newEndpointIP}
            onChange={(e) => setNewEndpointIP(e.target.value)}
            placeholder="127.0.0.1:55555"
          />
        </div>

        <div className="form-group">
          <label className="form-label">Endpoint Key:</label>
          <input
            type="text"
            className="form-input"
            value={newEndpointKey}
            onChange={(e) => setNewEndpointKey(e.target.value)}
            placeholder="ABCDEFG"
          />
        </div>

        <button onClick={handleAddEndpoint} className="add-button">
          Add New Endpoint
        </button>
      </div>
    </div>

  );
}

const fetchEndpoints = async function (setEndpoints) {
  const token = getToken();
  try {
    const response = await axios.get('http://localhost:8081/analytics/endpoints', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
    if (response.status !== 200) throw new Error('Failed to fetch endpoints');
    setEndpoints(response.data);
  } catch (error) {
    console.error('Error fetching endpoints:', error);
  }
}

const registerNewEndpoint = async function (reg_data) {
  const token = getToken();

  try {
    const response = await axios.post(`http://localhost:8081/analytics/endpoints/register`, reg_data, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.status !== 200) {
      const msg = response.body["message"];
      alert(msg);
      return false;
    }
    return true;
  } catch (err) {
    if (axios.isAxiosError(err)) {
      const msg = err.response.data?.message || "Failed to add endpoint";
      alert(msg);
    }
  }
  
  return false;
}

const getToken = () => {
  return localStorage.getItem('jwtToken');
};

export default ManageEndpointsScreen;
