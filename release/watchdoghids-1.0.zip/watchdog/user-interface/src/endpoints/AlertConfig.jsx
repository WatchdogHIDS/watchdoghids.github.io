// This class stores user-defined alerts, handles adding/removing them, and checks
// heuristic data to see if any alerts are triggered.

export class AlertConfig {
    // Stores all alerts in an in-memory array. Each alert is an object with multiple fields.
    constructor() {
      this.alerts = [];
    }
  
    // Adds a new alert to the system.
    // Returns the new alert object.
    addAlert(alert) {
      // Defensive checks.
      if (!alert) {
        throw new Error('Alert object is missing required fields.');
      }
  
      // Generate a unique ID.
      const newAlert = {
        id: Date.now(),
        ...alert,
      };
  
      this.alerts.push(newAlert);
      return newAlert;
    }
  
    // Removes an alert by its ID.
    removeAlert(alertId) {
      const index = this.alerts.findIndex((a) => a.id === alertId);
      if (index !== -1) {
        this.alerts.splice(index, 1);
        return true;
      }
      return false;
    }
  
    // Returns an array of all alerts.
    listAlerts() {
      return this.alerts;
    }
  

    checkAlerts(heuristicData) {
      const triggeredEvents = [];
  
      for (const alert of this.alerts) {
        // Filter data for matching device & metric.
        const relevantData = heuristicData.filter(
          (hd) => hd.device === alert.device && hd.metric === alert.metric
        );
  
        if (relevantData.length === 0) continue;
  
        // Summation logic.
        // For a time window approach, filter by timestamps.
        const totalUsage = relevantData.reduce((acc, item) => acc + (item.usage || 0), 0);
  
        // Compare totalUsage to threshold.
        let isTriggered = false;
  
        if (isTriggered) {
          triggeredEvents.push({
            event_id: Date.now() + Math.random(),
            device: alert.device,
            description: alert.description ||
              `${alert.metric} usage exceeded threshold of ${alert.threshold}`,
            severity_level: alert.severity || 'MEDIUM',
            acknowledged: false,
            resolved: false,
          });
        }
      }
  
      return triggeredEvents;
    }
  }
  