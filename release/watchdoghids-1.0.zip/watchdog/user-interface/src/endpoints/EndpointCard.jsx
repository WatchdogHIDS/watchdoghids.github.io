import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';

function EndpointCard({ endpoint, onRemove }) {
  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch data when the component changes
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await fetch(endpoint.url);
        if (!response.ok) {
          throw new Error('Failed to fetch endpoint data');
        }
        const data = await response.json();
        // Convert data to chart-friendly format
        // Example: data = [{ timestamp: <ISO string>, bytes: <number>, packets: <number> }, ...]
        const labels = data.map((item) => new Date(item.timestamp).toLocaleString());
        const bytes = data.map((item) => item.bytes);
        const packets = data.map((item) => item.packets);

        setChartData({
          labels,
          datasets: [
            {
              label: `${endpoint.name} - Bytes`,
              data: bytes,
              borderColor: '#4caf50',
              backgroundColor: 'rgba(76,175,80,0.2)',
            },
            {
              label: `${endpoint.name} - Packets`,
              data: packets,
              borderColor: '#ff7300',
              backgroundColor: 'rgba(255,115,0,0.2)',
            },
          ],
        });
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [endpoint]);

  if (loading) return <div>Loading data for {endpoint.name}...</div>;

  return (
    <div className="endpoint-card">
      <h2>{endpoint.name}</h2>
      {chartData ? (
        <Line
          data={chartData}
          options={{
            responsive: true,
            scales: {
              x: { title: { display: true, text: 'Timestamp' } },
              y: { title: { display: true, text: 'Bytes / Packets' } },
            },
          }}
        />
      ) : (
        <p>No data available</p>
      )}
      <button className="remove-endpoint" onClick={onRemove}>Remove Endpoint</button>
    </div>
  );
}

export default EndpointCard;
