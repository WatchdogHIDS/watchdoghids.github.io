$DataFolder = ".\database\data"

$ServiceName = "mariadb"

$ComposeFile = ".\docker-compose.yml"

# Delete the folder
if (Test-Path $DataFolder) {
    Write-Host "Deleting folder: $DataFolder"
    Remove-Item -Recurse -Force $DataFolder
    Write-Host "Folder deleted successfully."
} else {
    Write-Host "Folder $DataFolder does not exist. Skipping deletion."
}

# Restart the service
Write-Host "Restarting Docker Compose service: $ServiceName"
docker-compose -f $ComposeFile up -d --force-recreate $ServiceName

# Check the status
if ($LASTEXITCODE -eq 0) {
    Write-Host "Service $ServiceName restarted successfully."
} else {
    Write-Host "Failed to restart service $ServiceName."
    exit 1
}