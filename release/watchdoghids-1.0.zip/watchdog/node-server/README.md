# Watchdog API Server

This Node express server contains two main APIs:
1. The API for the Watchdog WebUI, with a root URL of `/analytics`
2. The API for Endpoint Agents to send metrics for storage in the DB, with a root URL of `/data`

Documentation on the provided routes for each can be found TBD

---

### How to run
1. Clone the repo
2. Ensure nodejs is installed: https://nodejs.org/en
3. In the project directory, run `npm install`
4. Copy the `.env.example` file to `.env` and make any needed changes to the variable values
5. Start the server by running `node index.js`