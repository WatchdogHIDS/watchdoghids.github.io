const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config()

// Import controllers
require('./controllers/types');
require('./controllers/auth');
const pool = require('./controllers/database');
const router = require('./controllers/router');
require('./controllers/mailer');

app = express();
const PORT = process.env.PORT || 8080;

app.use(cors({
    origin: 'http://localhost:3000',
    credentials:true
}));
app.use(bodyParser.json());
app.use(router);


// TODO: HANDLE ROOT URL ACCESS
app.get('/', (req, res) => {
    const data = { message: "You've reached the watchdog server" };
    res.json(data);
});

// Interrupt Handler
process.on('SIGINT', () => {
    console.log("Gracefully shutting down...");
    pool.end().then(() => {
        process.exit();
    });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
