const express = require("express");
const webUIRoutes = require("./routes/webUIRoutes");
const endpointRoutes = require("./routes/endpointRoutes");

const router = express.Router();

router.use('/analytics', webUIRoutes);
router.use('/data', endpointRoutes);

module.exports = router;
