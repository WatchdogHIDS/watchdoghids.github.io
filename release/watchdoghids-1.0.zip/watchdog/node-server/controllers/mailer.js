const nodemailer = require('nodemailer');
let transporter = null;

if (process.env.USE_MAIL == "true") {
    let tls_config = true;
    let use_ssl = true;

    if (process.env.MAIL_ALLOW_SELF_SIGN == "true") {
        tls_config = false;
    }
    if (process.env.MAIL_USE_SSL == "false") {
        use_ssl = false;
    }

    transporter = nodemailer.createTransport({
        host: process.env.MAIL_HOST,
        port: process.env.MAIL_PORT || 587,
        secure: use_ssl,
        auth: {
            user: process.env.MAIL_USERNAME,
            pass: process.env.MAIL_PASSWORD
        },
        tls: {
            rejectUnauthorized: tls_config
        }
    });
}

const sendMailWithRetry = function(transporter, mail, maxRetries = 5, delayMs = 1000) {
    let attempts = 0;

    function attempt() {
        transporter.sendMail(mail, function (err, info) {
            if (err) {
                console.log(`Attempt ${attempts + 1} failed:`, err);
                attempts++;

                if (attempts < maxRetries) {
                    console.log(`Retrying in ${delayMs}ms...`);
                    setTimeout(attempt, delayMs);
                } else {
                    console.log("All retry attempts failed.");
                    transporter.close();
                }
            } else {
                console.log("info.messageId: " + info.messageId);
                console.log("info.envelope: " + JSON.stringify(info.envelope));
                console.log("info.accepted: " + info.accepted);
                console.log("info.rejected: " + info.rejected);
                console.log("info.pending: " + info.pending);
                console.log("info.response: " + info.response);
                transporter.close();
            }
        });
    }

    attempt();
}

module.exports = {
    transporter,
    sendMailWithRetry,
  };