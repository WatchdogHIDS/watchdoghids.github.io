const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 'secretkey';

function authenticate(req, res, next) {
    const authHeader = req.headers['authorization'];
    if (!authHeader) {
        return res.status(401).json({ message: 'Authentication required' });
    }

    const token = authHeader.split(' ')[1]; // This assumes the Bearer <token> format

    try {
        const decoded = jwt.verify(token, SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        res.status(403).json({ message: 'Forbidden: Invalid token' });
    }
}

function getToken(user_id, username) {
    const token = jwt.sign(
        { id: user_id, username: username },
        SECRET,
        { expiresIn: '8h' }
    );
    return token;
}

function getUser(token) {
    try {
        const decoded = jwt.verify(token, SECRET);
        return decoded?.id;
    } catch (err) {
        return null;
    }
}

module.exports = { authenticate, getToken, getUser };