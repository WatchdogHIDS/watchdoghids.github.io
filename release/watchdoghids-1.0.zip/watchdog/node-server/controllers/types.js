/**
 * This files is to help setup various type-related helpers
 * 
 * Not sure if best practice, but just using this as a catch-al for now
 */


/**
 * Helper to serialize BigInt data from maridb into JSON
 */
BigInt.prototype.toJSON = function () { return this.toString() }