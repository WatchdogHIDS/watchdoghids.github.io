const mariadb = require('mariadb');

// Setup DB connection pool to pass to routes
const pool = mariadb.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || 'password',
    database: process.env.DB_NAME || 'main',
    connectionLimit: 5
})

module.exports = pool;