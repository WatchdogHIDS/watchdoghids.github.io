const express = require('express');
const router = express.Router();
const pool = require("../database");
const auth = require('../auth');
const axios = require('axios');
const { transporter, sendMailWithRetry } = require('../mailer');
const endpoint_cache = require('../cache');
const age = import("age-encryption");

router.get('/endpoints', auth.authenticate, async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const rows = await conn.query('SELECT * FROM endpoints');
        conn.release();

        res.status(200).json(rows);
    } catch (err) {
        conn.release();
        console.error('Error fetching data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.post('/endpoints/register', auth.authenticate, async (req, res) => {
    const { endpoint_name, endpoint_host, endpoint_key } = req.body;

    if ([endpoint_name, endpoint_host, endpoint_key].some(value => value == null)) {
        return res.status(400).json({ message: "Missing required fields for endpoint registration" });
    }

    let conn;
    // Check endpoint is not cached
    if (endpoint_cache.hasOwnProperty(endpoint_key)) {
        return res.status(409).json({ message: "Endpoint already registered" });
    }
    // Check endpoint isn't in database
    else {
        try {
            conn = await pool.getConnection();
            const result = await conn.query("SELECT * FROM endpoints WHERE endpoint_key=?", [endpoint_key]);
            if (result.length > 0) {
                const id = result[0].id;
                endpoint_cache[endpoint_key] = id;
                conn.release();
                return res.status(409).json({ message: "Endpoint already registered" });
            }
        }
        catch (err) {
            conn.release();
            return res.status(500).json({ message: "There was an error connecting to the db" });
        }
    }
    // If not attempt to validate the endpoint
    try {
        const reg_response = await axios.post(`http://${endpoint_host}/`, { key: endpoint_key, port: process.env.PORT });
        if (reg_response.status != 200) {
            conn.release();
            return res.status(400).json({ message: "There was an error validating the endpoint" });
        }
    } catch (err) {
        conn.release();
        return res.status(400).json({ message: "There was an error connecting to the endpoint" });
    }

    // Insert the new endpoint
    const eip = endpoint_host.split(":")[0];
    try {
        if (!conn) {
            conn = await pool.getConnection();
        }
        const result = await conn.query("INSERT INTO endpoints (name, endpoint_key, ip) VALUES (?, ?, ?)", [endpoint_name, endpoint_key, eip]);

        const eid = Number(result.insertId);
        endpoint_cache[endpoint_key] = eid;
        console.log(endpoint_cache);
        conn.release();
    } catch (err) {
        conn.release();
        return res.status(500).json({ message: "There was an error inserting the endpoint into the db" });
    }

    return res.status(200).json({ message: "Success" });
});

router.get('/events/:status', auth.authenticate, async (req, res) => {
    try {
        const conn = await pool.getConnection();

        const { status } = req.params;
        let page = Math.abs(parseInt(req.query.page)) || 1;
        const limit = 20;

        let whereClause = '';
        if (status === 'unacknowledged') {
            whereClause = 'acknowledged=0 AND resolved=0';
        } else if (status === 'acknowledged') {
            whereClause = 'acknowledged=1 AND resolved=0';
        } else if (status === 'resolved') {
            whereClause = 'resolved=1';
        } else {
            return res.status(400).json({ error: 'Invalid status. Use unacknowledged, acknowledged, or resolved.' });
        }

        const [{ total }] = await conn.query(
            `SELECT COUNT(*) AS total
            FROM (
                SELECT id FROM network_anomaly_events WHERE ${whereClause}
                UNION ALL
                SELECT id FROM file_info_anomaly_events WHERE ${whereClause}
                UNION ALL
                SELECT id FROM login_info_anomaly_events WHERE ${whereClause}
                UNION ALL
                SELECT id FROM proc_info_anomaly_events WHERE ${whereClause}
                UNION ALL
                SELECT id FROM resource_info_anomaly_events WHERE ${whereClause}
            ) AS temp`
        );

        const totalPages = Math.max(Math.ceil(Number(total) / limit), 1);
        if (page > totalPages) {
            page = totalPages;
        }
        const offset = (page - 1) * limit;

        const rows = await conn.query(
            `SELECT
                ne.id,
                ne.endpoint_id,
                e.name,
                ne.alert_description,
                ne.severity_level,
                ne.updated_at,
                ne.resolution_description,
                'Network' AS event_type,
                0 AS event_type_id
            FROM network_anomaly_events AS ne
            JOIN endpoints AS e ON endpoint_id=e.id
            WHERE ${whereClause}
            UNION ALL
            SELECT
                pe.id,
                endpoint_id,
                name,
                alert_description,
                severity_level,
                updated_at,
                resolution_description,
                'Process' AS event_type,
                1 AS event_type_id
            FROM proc_info_anomaly_events AS pe
            JOIN endpoints AS e ON endpoint_id=e.id
            WHERE ${whereClause}
            UNION ALL
            SELECT
                re.id,
                endpoint_id,
                name,
                alert_description,
                severity_level,
                updated_at,
                resolution_description,
                'System Resource' AS event_type,
                2 AS event_type_id
            FROM resource_info_anomaly_events AS re
            JOIN endpoints AS e ON endpoint_id=e.id
            WHERE ${whereClause}
            UNION ALL
            SELECT
                le.id,
                endpoint_id,
                name,
                alert_description,
                severity_level,
                updated_at,
                resolution_description,
                'Login' AS event_type,
                3 AS event_type_id
            FROM login_info_anomaly_events AS le
            JOIN endpoints AS e ON endpoint_id=e.id
            WHERE ${whereClause}
            UNION ALL
            SELECT
                fe.id,
                endpoint_id,
                name,
                alert_description,
                severity_level,
                updated_at,
                resolution_description,
                'File Integrity' AS event_type,
                4 AS event_type_id
            FROM file_info_anomaly_events AS fe
            JOIN endpoints AS e ON endpoint_id=e.id
            WHERE ${whereClause}
            ORDER BY updated_at
            LIMIT ${limit} OFFSET ${offset}
            `
        );

        conn.release();

        res.status(200).json({
            data: rows,
            currentPage: page,
            totalPages: totalPages,
            totalRecords: Number(total),
        });
    } catch (err) {
        console.error('Error fetching data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.get('/user_settings/events', auth.authenticate, async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const rows = await conn.query(`SELECT 
            na.id,
            e.name AS endpoint_name,
            na.bandwidth_threshold,
            na.severity_level,
            na.event_description,
            na.sliding_window_minutes,
            na.target_host
            FROM user_network_anomaly_events AS na
            JOIN endpoints AS e ON endpoint_id=e.id`);
        conn.release();

        res.status(200).json(rows);
    } catch (err) {
        console.error('Error fetching data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.post('/user_settings/events/create', auth.authenticate, async (req, res) => {

    const { endpoint_id, user_id, event_description, target_host, severity_level, bandwidth_threshold, time_window } = req.body;

    if (!endpoint_id || !user_id || !event_description || !target_host || !severity_level || !bandwidth_threshold || !time_window) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const conn = await pool.getConnection();

        const result = await conn.query(
            `INSERT INTO user_network_anomaly_events (endpoint_id, user_id, event_description, target_host, severity_level, bandwidth_threshold, sliding_window_minutes) 
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [endpoint_id, user_id, event_description, target_host, severity_level, bandwidth_threshold, time_window]
        );
        conn.release();

        try {
            const webhookResponse = await axios.post(
                `http://${process.env.HAE_HOST||'localhost'}:${process.env.HAE_PORT||8080}/webhook/config-update`,
                { endpoint_id: Number(result.insertId) },
                {
                    headers: {
                        'x-api-key': 'secret-key',
                    },
                }
            );

            console.log('Webhook response:', webhookResponse.data);

        } catch (err) {
            console.error('Error triggering webhook:', err);
        }

        res.status(201).json({
            message: 'New user network event created successfully',
            event_id: result.insertId,
        });

    } catch (err) {
        console.error('Error creating event:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.post('/alerts/new', async (req, res) => {
    console.log(req.body);
    const eid = req.body["event_id"];
    const event_type = req.body["event_type"];

    if (eid == null || event_type == null) {
        res.status(400).json({ error: 'Please provide a valid event id and type' });
        return;
    }

    if (process.env.USE_MAIL != "true" || transporter==null) return res.status(200).json({ message: 'Server not configured to send mail alerts' });

    const email = process.env.ALERT_EMAIL || null;
    if(!email) return res.status(200).json({ message: 'Server not configured to send mail alerts' });

    let table;
    switch (parseInt(event_type)) {
        case 0:
            table = "network_anomaly_events";
            break;
        case 1:
            table = "proc_info_anomaly_events";
            break;
        case 2:
            table = "resource_info_anomaly_events";
            break;
        case 3:
            table = "login_info_anomaly_events";
            break;
        case 4:
            table = "file_info_anomaly_events";
            break;
        default:
            return res.status(400).json({ error: 'Provided event_type is not valid.' });
    }

    let rows;
    try {
        const conn = await pool.getConnection();
        rows = await conn.query(`SELECT * FROM ${table} WHERE id=${eid}`);
        conn.release();
    
        if (rows.length != 1) {
            res.status(400).json({ error: 'Invalid Event ID' });
            return;
        }
    } catch (err) {
        res.status(500).json({ error: 'There was an error finding the event' });
    }
    

    const mail = {
        from: `Watchdog Alerts <${process.env.MAIL_USERNAME}>`,
        to: `${email}`,
        subject: "Watchdog Alert",
        html: `<html>
            <body>
                <h2>Alert Details</h2>
                <p><strong>Endpoint ID:</strong> ${rows[0].endpoint_id}</p>
                <p><strong>Time Window:</strong> ${new Date(rows[0].time_window_start).toLocaleString()} to ${new Date(rows[0].time_window_end).toLocaleString()}</p>
                <p><strong>Alert Description:</strong> ${rows[0].alert_description}</p>
                <p><strong>Severity Level:</strong> ${rows[0].severity_level}</p>
                <p><strong>Created At:</strong> ${new Date(rows[0].created_at).toLocaleString()}</p>
                <hr>
                <p>Please login to the Watchdog Dashboard to handle this event.</p>
            </body>
            </html>
        `
    }

    sendMailWithRetry(transporter, mail);

    res.status(200).json({ message: 'Alert sent successfully.' });
});

router.get('/network_traffic', auth.authenticate, async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const rows = await conn.query('SELECT * FROM endpoint_network_traffic');
        conn.release();

        res.status(200).json(rows);
    } catch (err) {
        console.error('Error fetching data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.get('/resource_data', auth.authenticate, async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const rows = await conn.query('SELECT * FROM endpoint_resource_data');
        conn.release();

        res.status(200).json(rows);
    } catch (err) {
        console.error('Error fetching data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.get('/proc_info', auth.authenticate, async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const rows = await conn.query('SELECT * FROM endpoint_proc_info');
        conn.release();

        res.status(200).json(rows);
    } catch (err) {
        console.error('Error fetching data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.get('/resource_data', auth.authenticate, async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const rows = await conn.query('SELECT * FROM endpoint_resource_data');
        conn.release();

        res.status(200).json(rows);
    } catch (err) {
        console.error('Error fetching data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.put('/acknowledge_event', auth.authenticate, async (req, res) => {
    const { event_id, event_type } = req.body;

    if (!event_id || event_type==null) {
        return res.status(400).json({ error: 'Event ID and type is required.' });
    }

    let table_name;
    switch (parseInt(event_type)) {
        case 0:
            table_name = "network_anomaly_events";
            break;
        case 1:
            table_name = "proc_info_anomaly_events";
            break;
        case 2:
            table_name = "resource_info_anomaly_events";
            break;
        case 3:
            table_name = "login_info_anomaly_events";
            break;
        case 4:
            table_name = "file_info_anomaly_events";
            break;
        default:
            return res.status(400).json({ error: 'Provided event_type is not valid.' });
    }

    try {
        const conn = await pool.getConnection();

        const result = await conn.query(
            `UPDATE ${table_name} SET acknowledged = TRUE, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
            [event_id]
        );

        conn.release();
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Event not found.' });
        }

        res.status(200).json({ message: 'Event acknowledged successfully.' });
    } catch (err) {
        console.error('Error updating event:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.put('/resolve_event', auth.authenticate, async (req, res) => {
    const { event_id, event_type, resolution_message } = req.body;

    if (!event_id || event_type==null || !resolution_message) {
        return res.status(400).json({ error: 'Event ID, type, and resolution message are required.' });
    }

    let table_name;
    switch (parseInt(event_type)) {
        case 0:
            table_name = "network_anomaly_events";
            break;
        case 1:
            table_name = "proc_info_anomaly_events";
            break;
        case 2:
            table_name = "resource_info_anomaly_events";
            break;
        case 3:
            table_name = "login_info_anomaly_events";
            break;
        case 4:
            table_name = "file_info_anomaly_events";
            break;
        default:
            return res.status(400).json({ error: 'Provided event_type is not valid.' });
    }

    try {
        const conn = await pool.getConnection();

        const result = await conn.query(
            `UPDATE ${table_name} 
             SET resolved = TRUE, 
                 resolution_description = ?, 
                 updated_at = CURRENT_TIMESTAMP 
             WHERE id = ?`,
            [resolution_message, event_id]
        );

        conn.release();

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Event not found.' });
        }

        res.status(200).json({ message: 'Event resolved successfully.' });
    } catch (err) {
        console.error('Error resolving event:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required' });
    }

    const conn = await pool.getConnection();
    const rows = await conn.query('SELECT id, username, user_password FROM users WHERE email = ?', [email]);
    conn.release();

    if (rows.length === 0) {
        return res.status(401).json({ message: 'Invalid email or password' });
    }

    const user = rows[0];

    if (password != user.user_password) {
        return res.status(401).json({ message: 'Invalid email or password' });
    }

    const token = auth.getToken(user.id, user.name);

    res.json({ token });
});

router.put('/api_keys/update', auth.authenticate, async (req, res) => {
    const { key_id, api_key } = req.body;

    if ([key_id, api_key].some(value => value == null)) {
        return res.status(400).json({ message: "Missing required fields for updating api key" });
    }
    if (!process.env.AGE_RECIPIENT) {
        return res.status(500).json({ message: "Server not configured to encrypt keys" });
    }

    const e = new (await age).Encrypter();
    e.addRecipient(process.env.AGE_RECIPIENT);
    const cipher_text = await e.encrypt(api_key);
    const armored = (await age).armor.encode(cipher_text);

    // Update key
    try {
        const conn = await pool.getConnection();
        const result = await conn.query(
            `UPDATE external_keys
             SET enc_key = ?,
                 status = TRUE
             WHERE id = ?`,
            [armored, key_id]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Key not found' });
        }
        conn.release();
    } catch (err) {
        conn.release();
        return res.status(500).json({ message: 'Error updating key' });
    }

    // Notify HAE of change
    try {
        const webhookResponse = await axios.post(
            `http://${process.env.HAE_HOST||'localhost'}:${process.env.HAE_PORT||8080}/webhook/api-key-update`,
            { key_id: Number(key_id) },
            {
                headers: {
                    'x-api-key': process.env.HAE_SECRET || null
                },
            }
        );

        console.log('Webhook response:', webhookResponse.data);

    } catch (err) {
        console.error('Error triggering webhook:', err);
    }

    return res.status(200).json({ message: 'Key updated successfully.' })
});

router.get('/api_keys', auth.authenticate, async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const rows = await conn.query('SELECT id, description, status FROM external_keys');
        conn.release();
        res.status(200).json(rows);
    } catch (err) {
        console.error('Error fetching data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

module.exports = router;