const express = require('express');
const router = express.Router();
const pool = require("../database");
const endpoint_cache = require("../cache");


router.post('/update', async (req, res) => {
  const authHeader = req.headers['authorization'];
  let token = null;
  // Check if the Authorization header is proper and extract endpoint_key
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  } else {
    return res.status(401).json({ error: "No authorization provided" });
  }

  // Identify the endpoint
  let conn;
  let endpoint_id;
  if (endpoint_cache.hasOwnProperty(token)) {
    endpoint_id = endpoint_cache[token];
  } else {
    try {
      conn = await pool.getConnection();
      const result = await conn.query("SELECT * FROM endpoints WHERE endpoint_key=?", [token]);
      if (result.length > 0) {
        const id = result[0].id;
        endpoint_cache[token] = id;
        endpoint_id = id;
      } else {
        conn.release();
        return res.status(403).json({ error: "This endpoint is not registered" });
      }
    }
    catch (err) {
      return res.status(500).json({ error: "There was an error connecting to the db" });
    }
  }


  let data
  let toUpdate = [];
  let count = 0;
  let placeholders;
  let values;
  let insertStatement = "";

  if ('NetworkData' in req.body) {
    data = req.body['NetworkData'];
    Object.keys(data).forEach(i => {
      row = [endpoint_id, new Date().toISOString().slice(0, 19).replace('T', ' '), "192.111.111.111"];
      const [ip, port] = i.split(":");
      row.push(ip);
      row.push(port);
      if (data[i]["proto"] == "EthernetPacket") {
        row.push("ETH");
      }
      else {
        row.push(data[i]["proto"]);
      }
      row.push("CLOSED");
      row.push(data[i]["resp_pkts"]);
      row.push(data[i]["resp_bytes"]);
      toUpdate.push(row);
      count++;
    });

    // Flatten the array of arrays for bulk insert
    values = toUpdate.flat();

    // Build the placeholders for the bulk insert
    placeholders = toUpdate.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?)').join(',');
    insertStatement = "endpoint_network_traffic (endpoint_id, record_timestamp, internal_ip, external_ip, destination_port, protocol, connection_state, packets, bytes)"
  }
  else if ('ProcsData' in req.body) {
    data = req.body['ProcsData'];
    row = [endpoint_id, new Date().toISOString().slice(0, 19).replace('T', ' ')];
    row.push(JSON.stringify(data));
    toUpdate.push(row);
    count++;

    values = toUpdate.flat();

    // Build the placeholders for the bulk insert
    placeholders = toUpdate.map(() => '(?, ?, ?)').join(',');
    insertStatement = "endpoint_proc_info (endpoint_id, record_timestamp, proc_info)";
  }
  else if ('ResourceData' in req.body) {
    data = req.body['ResourceData'];
    row = [endpoint_id, new Date().toISOString().slice(0, 19).replace('T', ' ')];
    row.push(JSON.stringify(data));
    toUpdate.push(row);
    count++;

    values = toUpdate.flat();

    // Build the placeholders for the bulk insert
    placeholders = toUpdate.map(() => '(?, ?, ?)').join(',');
    insertStatement = "endpoint_resource_data (endpoint_id, record_timestamp, resource_info)";
  }
  else if ('LoginData' in req.body) {
    data = req.body['LoginData'];
    row = [endpoint_id, new Date().toISOString().slice(0, 19).replace('T', ' ')];
    row.push(JSON.stringify(data));
    toUpdate.push(row);
    count++;

    values = toUpdate.flat();

    // Build the placeholders for the bulk insert
    placeholders = toUpdate.map(() => '(?, ?, ?)').join(',');
    insertStatement = "endpoint_login_info (endpoint_id, record_timestamp, login_info)";
  }

  if (!insertStatement) {
    console.log("Nothing to update");
    if (conn) {
      conn.release();
    }
    res.send({ 'message': "Nothing to Update!" })
    return
  }

  try {

    // Construct the final SQL query
    const bulkInsertSql = `INSERT INTO ${insertStatement} VALUES ${placeholders}`;

    // Execute the query
    if (!conn) {
      conn = await pool.getConnection();
    }
    await conn.query(bulkInsertSql, values);
    conn.release();
    console.log(`Inserted ${count} rows successfully.`);

  } catch (err) {
    console.error('Error inserting rows:', err);
  } finally {
    // Release the pool
  }

  res.send({ 'message': "Success!" })

})

module.exports = router;