// Used to cache some info about the endpoints to avoid unnecessary lookups
// Acceptable due to a relatively low device count for our typical users
// Needs to be reworked with a ttl and max_size if scaled up to very large networks
const endpoint_cache = {};

module.exports = endpoint_cache;