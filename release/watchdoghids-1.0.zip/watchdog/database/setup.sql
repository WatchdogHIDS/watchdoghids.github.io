CREATE TABLE
    IF NOT EXISTS endpoints (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL UNIQUE, -- User-defined name for each endpoint
        endpoint_key VARCHAR(1000) NOT NULL,
        ip VARCHAR(45) DEFAULT NULL
    );

CREATE TABLE
    IF NOT EXISTS endpoint_network_traffic (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL,
        record_timestamp DATETIME NOT NULL, -- The time of the record
        internal_ip VARCHAR(45) NOT NULL, -- Internal IP address (supports both IPv4 and IPv6)
        external_ip VARCHAR(45) NOT NULL, -- External IP address (supports both IPv4 and IPv6)
        destination_port INT UNSIGNED NOT NULL CHECK (destination_port BETWEEN 0 AND 65535), -- Destination port number
        protocol VARCHAR(10) NOT NULL, -- Protocol (e.g., TCP, UDP)
        connection_state VARCHAR(20) NOT NULL, -- State of the connection (e.g., ESTABLISHED, CLOSED)
        packets INT UNSIGNED NOT NULL, -- Number of packets transferred
        bytes BIGINT UNSIGNED NOT NULL,
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id) -- Number of bytes transferred
    );

CREATE TABLE
    IF NOT EXISTS network_anomaly_events (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL, -- The endpoint affected by the anomaly
        host_ip VARCHAR(45) NOT NULL, -- The host where the anomaly was detected
        bandwidth_usage BIGINT UNSIGNED NOT NULL, -- Usage (e.g., bandwidth, CPU, etc.) during the anomaly
        time_window_start DATETIME, -- Time range during which the anomaly occurred
        time_window_end DATETIME,
        alert_description TEXT, -- Description of the anomaly or alert
        acknowledged BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been acknowledged
        severity_level VARCHAR(50), -- Severity level of the anomaly (e.g., LOW, MEDIUM, HIGH)
        created_at DATETIME DEFAULT NOW(), -- Timestamp when the event was created
        updated_at DATETIME DEFAULT NOW(), -- Timestamp when the event was last updated
        resolved BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been resolved
        resolution_description TEXT, -- Optional description for how the event was resolved
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );

CREATE TABLE
    IF NOT EXISTS users (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        user_password VARCHAR(255) NOT NULL
    );

CREATE TABLE
    IF NOT EXISTS endpoint_proc_info (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL,
        record_timestamp DATETIME NOT NULL,
        proc_info JSON NOT NULL DEFAULT '{}',
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );

CREATE TABLE
    IF NOT EXISTS proc_info_anomaly_events (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL, -- The endpoint affected by the anomaly
        proc_name VARCHAR(100) NOT NULL,
        proc_info JSON NOT NULL DEFAULT '{}',
        time_window_start DATETIME, -- Time range during which the anomaly occurred
        time_window_end DATETIME,
        alert_description TEXT, -- Description of the anomaly or alert
        acknowledged BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been acknowledged
        severity_level VARCHAR(50), -- Severity level of the anomaly (e.g., LOW, MEDIUM, HIGH)
        created_at DATETIME DEFAULT NOW(), -- Timestamp when the event was created
        updated_at DATETIME DEFAULT NOW(), -- Timestamp when the event was last updated
        resolved BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been resolved
        resolution_description TEXT, -- Optional description for how the event was resolved
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );

CREATE TABLE
    IF NOT EXISTS user_network_anomaly_events (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        event_description VARCHAR(100) NOT NULL DEFAULT "",
        target_host VARCHAR(45) NOT NULL,
        severity_level VARCHAR(50) NOT NULL,
        bandwidth_threshold BIGINT UNSIGNED NOT NULL,
        sliding_window_minutes INT UNSIGNED NOT NULL,
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id),
        FOREIGN KEY (user_id) REFERENCES users (id)
    );

CREATE TABLE
    IF NOT EXISTS endpoint_resource_data (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL,
        record_timestamp DATETIME NOT NULL,
        resource_info JSON NOT NULL DEFAULT '{}',
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );

CREATE TABLE
    IF NOT EXISTS resource_info_anomaly_events (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL, -- The endpoint affected by the anomaly
        resource_info JSON NOT NULL DEFAULT '{}',
        time_window_start DATETIME, -- Time range during which the anomaly occurred
        time_window_end DATETIME,
        alert_description TEXT, -- Description of the anomaly or alert
        acknowledged BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been acknowledged
        severity_level VARCHAR(50), -- Severity level of the anomaly (e.g., LOW, MEDIUM, HIGH)
        created_at DATETIME DEFAULT NOW(), -- Timestamp when the event was created
        updated_at DATETIME DEFAULT NOW(), -- Timestamp when the event was last updated
        resolved BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been resolved
        resolution_description TEXT, -- Optional description for how the event was resolved
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );

CREATE TABLE
    IF NOT EXISTS external_keys (
        id INT PRIMARY KEY,
        description VARCHAR(255) NOT NULL,
        enc_key VARCHAR(1000) NOT NULL,
        status BOOLEAN NOT NULL
    );

CREATE TABLE
    IF NOT EXISTS endpoint_login_info (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL,
        record_timestamp DATETIME NOT NULL,
        login_info JSON NOT NULL DEFAULT '{}',
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );

CREATE TABLE
    IF NOT EXISTS login_info_anomaly_events (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL, -- The endpoint affected by the anomaly
        login_info JSON NOT NULL DEFAULT '{}',
        time_window_start DATETIME, -- Time range during which the anomaly occurred
        time_window_end DATETIME,
        alert_description TEXT, -- Description of the anomaly or alert
        acknowledged BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been acknowledged
        severity_level VARCHAR(50), -- Severity level of the anomaly (e.g., LOW, MEDIUM, HIGH)
        created_at DATETIME DEFAULT NOW(), -- Timestamp when the event was created
        updated_at DATETIME DEFAULT NOW(), -- Timestamp when the event was last updated
        resolved BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been resolved
        resolution_description TEXT, -- Optional description for how the event was resolved
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );

CREATE TABLE
    IF NOT EXISTS endpoint_file_info (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL,
        record_timestamp DATETIME NOT NULL,
        file_info JSON NOT NULL DEFAULT '{}',
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );

CREATE TABLE
    IF NOT EXISTS file_info_anomaly_events (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        endpoint_id INT UNSIGNED NOT NULL, -- The endpoint affected by the anomaly
        file_info JSON NOT NULL DEFAULT '{}',
        time_window_start DATETIME, -- Time range during which the anomaly occurred
        time_window_end DATETIME,
        alert_description TEXT, -- Description of the anomaly or alert
        acknowledged BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been acknowledged
        severity_level VARCHAR(50), -- Severity level of the anomaly (e.g., LOW, MEDIUM, HIGH)
        created_at DATETIME DEFAULT NOW(), -- Timestamp when the event was created
        updated_at DATETIME DEFAULT NOW(), -- Timestamp when the event was last updated
        resolved BOOLEAN DEFAULT FALSE, -- Flag indicating if the event has been resolved
        resolution_description TEXT, -- Optional description for how the event was resolved
        FOREIGN KEY (endpoint_id) REFERENCES endpoints (id)
    );


-- Initial watchdog data
INSERT INTO
    external_keys (id, description, enc_key, status)
VALUES
    (1, "AbuseIPDB", "", 0),
    (2, "VirusTotal", "", 0);

INSERT INTO
    users (username, email, user_password)
VALUES
    ("root", "root", "rootpassword");