# Watchdog Database

### Creating the DB
To setup the database for local development:
1. Clone the repo locally
2. Ensure Docker Compose is installed: https://docs.docker.com/compose/install/
3. cd into the project directory and run `docker-compose up -d`

---

### Browsing the DB
To browse the data currently in the DB through web UI after starting the containers:
1. Go to http://localhost:3307
2. Log in using the credentials defined in the compose file

---

### Resetting the DB
To clear out the local persistent DB data, such as when making changes to setup.sql, to the following:
1. Stop the containers (if running) using `docker-compose down`
2. Delete the contents of the `./data/` folder in the project directory
3. Re-run `docker-compose up -d` to rebuild the tables and inject any defined test data
