#!/bin/bash

DATA_FOLDER="./database/data"


SERVICE_NAME="mariadb"

# Path to the docker-compose.yml file
COMPOSE_FILE="docker-compose.yml"

# Delete the folder
if [ -d "$DATA_FOLDER" ]; then
  echo "Deleting folder: $DATA_FOLDER"
  rm -rf "$DATA_FOLDER"
  echo "Folder deleted successfully."
else
  echo "Folder $DATA_FOLDER does not exist. Skipping deletion."
fi

# Restart the service
echo "Restarting Docker Compose service: $SERVICE_NAME"
docker-compose -f "$COMPOSE_FILE" up -d --force-recreate "$SERVICE_NAME"

# Check the status
if [ $? -eq 0 ]; then
  echo "Service $SERVICE_NAME restarted successfully."
else
  echo "Failed to restart service $SERVICE_NAME."
  exit 1
fi